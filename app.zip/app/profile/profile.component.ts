import { Component, OnInit } from '@angular/core';
import { OauthAdapterService } from '../auth/oauth-adapter.service';

@Component({
    selector: 'app-profile',
    templateUrl: './profile.component.html',
    styleUrls: ['./profile.component.scss'],
    standalone: false
})
export class ProfileComponent implements OnInit {
  member: any;

  constructor(private authService: OauthAdapterService) {}

  ngOnInit(): void {
    this.member = this.authService.getIdentityClaims();
  }
}
