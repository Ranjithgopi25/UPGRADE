import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { ProfileRoutingModule } from './profile-routing.module';
import { ProfileComponent } from './profile.component';
import { PanelModule } from '@appkit4/angular-components/panel';
import { TabsModule } from '@appkit4/angular-components/tabs';

@NgModule({
  imports: [CommonModule, ProfileRoutingModule, PanelModule, TabsModule],
  declarations: [ProfileComponent],
})
export class ProfileModule {}
