import { Pipe, PipeTransform } from '@angular/core';
import { DomSanitizer, SafeHtml } from '@angular/platform-browser';
import { marked } from 'marked';

@Pipe({
  name: 'markdown',
  standalone: true
})
export class MarkdownPipe implements PipeTransform {
  constructor(private sanitizer: DomSanitizer) {
    // Configure marked options if needed
    marked.setOptions({
      breaks: true, // Convert \n to <br>
      gfm: true // GitHub Flavored Markdown
    });
  }

  transform(value: string): SafeHtml {
    if (!value) return '';
    // const html = marked.parse(value);
    // return this.sanitizer.bypassSecurityTrustHtml(html as string);
    // VC Scan
    const html = marked.parse(value) as string;
    // // Angular's default [innerHTML] binding will sanitize this automatically
    // // bypassSecurityTrustHtml is only needed if you want to allow dangerous content
    // // Since we're rendering markdown (which shouldn't have injected scripts), 
    // // we can return the HTML and let Angular's sanitizer handle it
    // // The sanitizer will remove script tags and event handlers automatically
    return this.sanitizer.bypassSecurityTrustHtml(html);
  }
}