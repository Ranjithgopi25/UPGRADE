export type JourneyType = 'thought-leadership' | 'ddc' | 'market-intelligence';

export interface WorkflowCard {
  id: string;
  icon: string;
  title: string;
  subtitle?: string;
  description: string;
  disabled?: boolean;
}

export interface GuidedJourneyConfig {
  type: JourneyType;
  title: string;
  workflows: WorkflowCard[];
}

// Intro text shown above workflows in Guided Journey dialogs
export const DDC_INTRO_TEXT = '';
export const DDC_SUB_INTRO_TEXT = '';
export const TL_INTRO_TEXT = 'Where all firm intelligence is created, curated, and deployed';

export const TL_WORKFLOWS: WorkflowCard[] = [
  {
    id: 'draft-content',
    icon: '✍️',
    title: 'Draft Content',
    description: 'Create articles, blogs, white papers, and podcasts'
  },
  {
    id: 'conduct-research',
    icon: '🔍',
    title: 'Conduct Research',
    description: 'Synthesize insights from multiple documents'
  },
  {
    id: 'edit-content',
    icon: '✏️',
    title: 'Edit Content',
    description: 'Align with PwC brand and style'
  },
  {
    id: 'refine-content',
    icon: '💎',
    title: 'Refine Content',
    description: 'Expand, compress, or adjust tone'
  },
  {
    id: 'format-translator',
    icon: '🔄',
    title: 'Format Translator',
    description: 'Convert between content formats'
  }
];

export const DDC_WORKFLOWS: WorkflowCard[] = [
  {
    id: 'slide-creation-prompt',
    icon: '<svg width="48pt" height="48pt" viewBox="0 0 96.000000 96.000000" preserveAspectRatio="xMidYMid meet"><defs><linearGradient x1="0" y1="1" x2="1" y2="0" gradientUnits="objectBoundingBox" id="fill0"><stop offset="0" stop-color="#FF9F00"/><stop offset="0.05089" stop-color="#FE9900"/><stop offset="0.466323" stop-color="#FD7204"/><stop offset="0.797112" stop-color="#FD5907"/><stop offset="1" stop-color="#FD5108"/></linearGradient></defs><g transform="translate(0.000000,96.000000) scale(0.100000,-0.100000)" fill="url(#fill0)" stroke="none"><path d="M90 785 c0 -102 2 -117 20 -135 11 -11 25 -20 30 -20 6 0 10 -27 10 -61 l0 -60 56 60 56 61 148 0 c122 0 149 3 154 15 5 13 -16 15 -151 15 l-157 0 -38 -37 -38 -37 0 36 c0 33 -3 37 -27 40 l-28 3 -3 103 -3 102 205 0 c234 0 216 8 216 -101 0 -55 3 -69 15 -69 12 0 15 16 15 80 0 124 8 120 -260 120 l-220 0 0 -115z"/><path d="M150 805 c0 -13 27 -15 180 -15 153 0 180 2 180 15 0 13 -27 15 -180 15 -153 0 -180 -2 -180 -15z"/><path d="M150 725 c0 -12 20 -15 120 -15 100 0 120 3 120 15 0 13 -20 15 -120 15 -100 0 -120 -2 -120 -15z"/><path d="M470 582 c-43 -14 -50 -32 -50 -137 l0 -103 219 2 c274 1 261 -6 261 143 l0 104 -207 -2 c-115 -1 -215 -4 -223 -7z m400 -107 c0 -57 -4 -86 -13 -94 -9 -7 -78 -10 -210 -8 l-197 2 0 82 c0 67 3 84 18 92 10 7 92 10 210 10 l192 -1 0 -83z"/><path d="M480 503 c0 -17 15 -18 180 -18 165 0 180 1 180 18 0 16 -15 17 -180 17 -165 0 -180 -1 -180 -17z"/><path d="M600 425 c0 -12 20 -15 120 -15 100 0 120 3 120 15 0 13 -20 15 -120 15 -100 0 -120 -2 -120 -15z"/><path d="M60 200 c0 -147 -12 -140 254 -140 181 0 215 2 220 15 5 13 -23 15 -213 15 -190 0 -220 2 -225 16 -3 9 -6 49 -6 90 l0 74 208 -2 207 -3 3 -67 c2 -52 6 -68 17 -68 12 0 15 15 15 65 0 106 3 105 -260 105 l-220 0 0 -100z"/><path d="M120 215 c0 -13 27 -15 180 -15 153 0 180 2 180 15 0 13 -27 15 -180 15 -153 0 -180 -2 -180 -15z"/><path d="M120 146 c0 -12 24 -15 120 -18 109 -3 120 -1 120 15 0 15 -12 17 -120 17 -98 0 -120 -3 -120 -14z"/></g></svg>',
    // title: 'New Deck Development',
    title: 'Statement of Work (SOW)',
    //description: 'Quickly turn an objective or idea into a starter PowerPoint deck​'
    description: ''
  },
  {
    id: 'slide-creation',
    icon: '<svg width="48pt" height="48pt" viewBox="0 0 96.000000 96.000000"  preserveAspectRatio="xMidYMid meet"><defs><linearGradient x1="0" y1="1" x2="1" y2="0" gradientUnits="objectBoundingBox" id="fill0"><stop offset="0" stop-color="#FF9F00"/><stop offset="0.05089" stop-color="#FE9900"/><stop offset="0.466323" stop-color="#FD7204"/><stop offset="0.797112" stop-color="#FD5907"/><stop offset="1" stop-color="#FD5108"/></linearGradient></defs> <g transform="translate(0.000000,96.000000) scale(0.100000,-0.100000)" fill="url(#fill0)" stroke="none"> <path d="M250 815 l0 -55 -57 0 -58 0 0 -335 0 -335 281 0 c241 0 283 2 288 15 5 13 -29 15 -267 15 l-272 0 0 305 0 305 43 0 42 0 0 -265 0 -265 215 0 c208 0 215 -1 215 -20 0 -12 7 -20 16 -20 11 0 15 6 11 20 -5 18 0 20 48 20 34 0 57 5 65 15 11 13 -19 15 -264 15 l-276 0 0 305 0 305 258 0 257 0 0 -282 c0 -229 3 -283 13 -283 11 0 14 57 15 297 l2 298 -287 0 -288 0 0 -55z"/> <path d="M360 680 l0 -110 85 0 85 0 0 110 0 110 -85 0 -85 0 0 -110z m140 0 l0 -80 -55 0 -55 0 0 80 0 80 55 0 55 0 0 -80z"/> <path d="M560 775 c0 -12 15 -15 78 -15 63 0 79 3 79 15 0 12 -16 15 -79 15 -63 0 -78 -3 -78 -15z"/> <path d="M560 680 c0 -19 5 -20 78 -18 61 2 77 6 77 18 0 12 -16 16 -77 18 -73 2 -78 1 -78 -18z"/> <path d="M560 585 c0 -12 15 -15 78 -15 63 0 79 3 79 15 0 12 -16 15 -79 15 -63 0 -78 -3 -78 -15z"/> <path d="M360 485 c0 -13 24 -15 177 -13 130 2 177 6 181 16 3 9 -37 12 -177 12 -155 0 -181 -2 -181 -15z"/> <path d="M360 395 c0 -12 16 -15 80 -15 64 0 80 3 80 15 0 12 -16 15 -80 15 -64 0 -80 -3 -80 -15z"/> <path d="M550 350 l0 -60 75 0 c41 0 78 0 81 0 3 0 7 27 8 60 l1 60 -82 0 -83 0 0 -60z m134 0 c0 -17 -4 -30 -7 -30 -4 0 -27 0 -52 0 -43 0 -45 1 -45 30 0 30 1 30 53 30 51 0 52 0 51 -30z"/> <path d="M364 311 c-2 -2 -4 -10 -4 -18 0 -10 20 -13 80 -13 70 0 80 2 80 18 0 15 -10 17 -76 17 -41 0 -77 -2 -80 -4z"/> </g> </svg>',
    // title: 'New Deck Development',
    title: 'Engagement Letter (EL)',
    //description: 'Transform a detailed Word/PDF outline into a PowerPoint presentation'
    description: ''
  },
  {
    id: 'sanitization',
    //icon: '🔒',
    icon:'<svg width="48.000000pt" height="48.000000pt" viewBox="0 0 96.000000 96.000000"  preserveAspectRatio="xMidYMid meet"><defs><linearGradient x1="0" y1="1" x2="1" y2="0" gradientUnits="objectBoundingBox" id="fill0"><stop offset="0" stop-color="#FF9F00"/><stop offset="0.05089" stop-color="#FE9900"/><stop offset="0.466323" stop-color="#FD7204"/><stop offset="0.797112" stop-color="#FD5907"/><stop offset="1" stop-color="#FD5108"/></linearGradient></defs> <g transform="translate(0.000000,96.000000) scale(0.100000,-0.100000)" fill="url(#fill0)" stroke="none"> <path d="M361 790 c-17 -28 -31 -52 -31 -55 0 -3 14 -27 31 -55 l31 -50 61 0 62 0 28 54 28 54 -31 51 -32 51 -58 0 -58 0 -31 -50z m155 -18 l22 -37 -22 -37 c-19 -35 -24 -38 -67 -38 -44 0 -47 2 -64 40 -18 39 -17 41 1 75 17 32 22 35 64 35 41 0 47 -3 66 -38z"/> <path d="M780 765 c0 -60 3 -75 15 -75 12 0 15 15 15 75 0 60 -3 75 -15 75 -12 0 -15 -15 -15 -75z"/> <path d="M60 735 c0 -13 17 -15 117 -13 82 2 118 7 121 16 3 9 -25 12 -117 12 -102 0 -121 -2 -121 -15z"/> <path d="M703 607 l-29 -54 29 -51 29 -52 62 0 62 0 30 53 30 52 -30 53 -30 52 -62 0 -62 0 -29 -53z m157 -14 l22 -37 -21 -35 c-18 -33 -24 -36 -66 -36 -43 0 -49 3 -68 36 l-21 36 23 36 c20 33 27 37 66 37 39 0 45 -3 65 -37z"/> <path d="M60 555 c0 -23 561 -23 580 0 11 13 -22 15 -284 15 -256 0 -296 -2 -296 -15z"/> <path d="M478 428 l-28 -52 29 -50 28 -51 60 -3 59 -3 33 53 33 52 -29 53 -28 53 -65 0 -65 0 -27 -52z m158 -15 l21 -36 -21 -38 c-19 -36 -25 -39 -63 -39 -38 0 -45 4 -67 38 l-24 37 21 38 c19 34 24 37 66 37 42 0 48 -3 67 -37z"/> <path d="M780 270 c0 -127 2 -150 15 -150 13 0 15 23 15 150 0 127 -2 150 -15 150 -13 0 -15 -23 -15 -150z"/> <path d="M60 378 c0 -16 15 -18 174 -18 143 0 175 3 179 15 5 12 -21 15 -173 17 -166 3 -180 2 -180 -14z"/> <path d="M263 288 c-5 -7 -20 -31 -32 -54 l-23 -40 29 -50 29 -49 65 -3 64 -3 28 54 29 53 -29 49 -29 50 -61 3 c-40 2 -63 -1 -70 -10z m133 -57 l21 -38 -21 -36 c-19 -34 -25 -37 -66 -37 -42 0 -47 3 -64 35 -18 34 -19 36 -1 75 17 38 20 40 64 40 43 0 47 -3 67 -39z"/> <path d="M60 195 c0 -13 11 -15 57 -13 81 4 85 28 4 28 -48 0 -61 -3 -61 -15z"/> </g> </svg>',
    // title: 'Sanitization',
    title: 'Master Services Agreement (MSA)',
    description: 'Remove sensitive data to create shareable PowerPoint presentations'
  },
  // {
  //   id: 'brand-format',
  //   icon: '🎨',
  //   title: 'Template Conversion',
  //   description: 'Apply PwC brand guidelines and professional polish',
  //   disabled: true
  // },
  // {
  //   id: 'professional-polish',
  //   icon: '✨',
  //   title: 'Professional Polish',
  //   description: 'Enhance visuals and language quality'
  // },
  {
    id: 'refine-drafts',
    icon: '<svg width="48.000000pt" height="48.000000pt" viewBox="0 0 96.000000 96.000000"  preserveAspectRatio="xMidYMid meet"><defs><linearGradient x1="0" y1="1" x2="1" y2="0" gradientUnits="objectBoundingBox" id="fill0"><stop offset="0" stop-color="#FF9F00"/><stop offset="0.05089" stop-color="#FE9900"/><stop offset="0.466323" stop-color="#FD7204"/><stop offset="0.797112" stop-color="#FD5907"/><stop offset="1" stop-color="#FD5108"/></linearGradient></defs> <g transform="translate(0.000000,96.000000) scale(0.100000,-0.100000)" fill="url(#fill0)" stroke="none"> <path d="M50 648 l0 -243 130 3 130 3 0 -30 c0 -31 -1 -31 -53 -31 -52 0 -54 -1 -72 -37 -11 -21 -21 -41 -23 -44 -1 -3 55 -6 124 -5 l128 1 -3 -68 -2 -68 27 3 c29 3 47 28 20 28 -15 0 -16 29 -14 276 l3 276 103 1 102 2 0 -87 0 -88 85 0 c69 0 85 -3 85 -15 0 -8 7 -15 15 -15 10 0 15 10 15 28 0 21 -15 43 -60 87 l-60 59 0 103 0 103 -302 -2 c-230 -2 -302 -6 -306 -15 -3 -10 59 -13 286 -13 l290 0 4 -75 c2 -41 1 -75 -1 -75 -2 0 -9 7 -15 15 -9 11 -40 15 -141 16 l-130 1 0 -196 0 -196 -42 0 c-40 0 -43 2 -41 27 2 15 10 28 20 31 10 2 18 11 18 18 0 11 -28 14 -145 14 l-145 0 0 40 0 40 145 0 c122 0 145 2 145 15 0 13 -23 15 -145 15 l-145 0 0 170 c0 144 -2 170 -15 170 -13 0 -15 -34 -15 -242z m721 -50 l33 -28 -62 0 -62 0 0 63 1 62 29 -35 c15 -19 43 -47 61 -62z m-353 -290 c-5 -15 -208 -24 -208 -10 0 19 17 22 113 22 74 0 98 -3 95 -12z"/> <path d="M480 445 c0 -12 13 -15 60 -15 47 0 60 3 60 15 0 12 -13 15 -60 15 -47 0 -60 -3 -60 -15z"/> <path d="M640 295 l0 -165 129 0 c105 0 130 3 135 15 5 13 -12 15 -114 15 l-120 0 0 135 0 135 105 0 105 0 0 -115 c0 -96 3 -115 15 -115 13 0 15 21 15 130 l0 130 -135 0 -135 0 0 -165z"/> <path d="M480 385 c0 -12 13 -15 60 -15 47 0 60 3 60 15 0 12 -13 15 -60 15 -47 0 -60 -3 -60 -15z"/> <path d="M710 385 c0 -12 14 -15 65 -15 51 0 65 3 65 15 0 12 -14 15 -65 15 -51 0 -65 -3 -65 -15z"/> <path d="M773 333 c-47 -3 -63 -8 -63 -18 0 -12 15 -15 65 -15 58 0 65 2 65 20 0 11 -1 19 -2 18 -2 -1 -31 -3 -65 -5z"/> <path d="M480 315 c0 -12 13 -15 60 -15 47 0 60 3 60 15 0 12 -13 15 -60 15 -47 0 -60 -3 -60 -15z"/> <path d="M710 255 c0 -12 14 -15 65 -15 51 0 65 3 65 15 0 12 -14 15 -65 15 -51 0 -65 -3 -65 -15z"/> <path d="M530 225 c-19 -7 -37 -21 -39 -30 -2 -13 1 -16 13 -11 9 3 24 9 33 13 17 7 10 -7 -44 -93 -12 -18 -12 -22 1 -27 10 -4 23 9 40 38 14 24 26 48 26 54 0 6 5 11 10 11 6 0 10 -11 10 -25 0 -16 6 -25 16 -25 13 0 15 7 10 38 -15 80 -14 79 -76 57z"/> </g> </svg>',
    // title: 'Existing Deck Refinement',
    title: 'Non-Disclosure Agreement (NDA)',
    description: 'Edit existing documents with a few clicks​'
  },
  {
    id: 'event-branding',
    icon: '<svg width="48.000000pt" height="48.000000pt" viewBox="0 0 96.000000 96.000000"  preserveAspectRatio="xMidYMid meet"><defs><linearGradient x1="0" y1="1" x2="1" y2="0" gradientUnits="objectBoundingBox" id="fill0"><stop offset="0" stop-color="#FF9F00"/><stop offset="0.0509" stop-color="#FE9900"/><stop offset="0.4663" stop-color="#FD7204"/><stop offset="0.7971" stop-color="#FD5907"/><stop offset="1" stop-color="#FD5108"/></linearGradient></defs> <g transform="translate(0.000000,96.000000) scale(0.100000,-0.100000)" fill="url(#fill0)" stroke="none"> <path d="M450 690 l0 -210 -195 0 c-167 0 -195 -2 -195 -15 0 -13 28 -15 195 -15 l195 0 0 -195 c0 -167 2 -195 15 -195 13 0 15 28 15 195 l0 195 210 0 c180 0 210 2 210 15 0 13 -30 15 -210 15 l-210 0 0 210 c0 180 -2 210 -15 210 -13 0 -15 -30 -15 -210z"/> <path d="M710 880 c-11 -11 -20 -29 -20 -40 0 -11 9 -29 20 -40 11 -11 29 -20 40 -20 11 0 29 9 40 20 11 11 20 29 20 40 0 11 -9 29 -20 40 -11 11 -29 20 -40 20 -11 0 -29 -9 -40 -20z m65 -40 c0 -18 -6 -26 -23 -28 -24 -4 -38 18 -28 44 3 9 15 14 28 12 17 -2 23 -10 23 -28z"/> <path d="M150 825 c0 -12 20 -15 120 -15 100 0 120 3 120 15 0 13 -20 15 -120 15 -100 0 -120 -2 -120 -15z"/> <path d="M602 734 c-17 -27 -47 -74 -66 -104 -28 -43 -32 -56 -20 -58 9 -2 17 -2 18 0 2 1 28 43 59 91 43 66 55 92 48 104 -7 14 -14 8 -39 -33z"/> <path d="M150 705 c0 -12 20 -15 120 -15 100 0 120 3 120 15 0 13 -20 15 -120 15 -100 0 -120 -2 -120 -15z"/> <path d="M658 698 c-7 -20 65 -127 85 -128 15 0 16 3 7 20 -8 16 -7 26 7 45 10 13 20 25 23 25 3 0 18 -20 33 -45 18 -28 36 -45 48 -45 16 0 12 11 -27 70 -26 39 -50 70 -54 70 -5 0 -17 -16 -29 -35 -11 -19 -24 -35 -28 -35 -5 0 -17 16 -27 35 -20 37 -32 43 -38 23z"/> <path d="M150 585 c0 -12 20 -15 120 -15 100 0 120 3 120 15 0 13 -20 15 -120 15 -100 0 -120 -2 -120 -15z"/> <path d="M692 369 c-7 -29 -20 -78 -29 -108 l-17 -56 -21 89 -21 88 -21 -53 c-17 -45 -25 -55 -47 -57 -41 -5 -33 -32 9 -32 28 0 37 5 44 22 7 18 13 3 30 -75 13 -53 24 -97 26 -97 1 0 13 42 25 92 13 51 26 97 30 101 5 5 16 -36 26 -92 17 -94 33 -131 34 -78 1 12 9 56 19 97 15 59 21 70 26 53 6 -19 14 -23 51 -23 32 0 44 4 44 15 0 10 -10 15 -33 15 -33 0 -35 2 -52 61 -21 70 -27 64 -46 -39 -7 -40 -15 -69 -19 -65 -4 4 -13 42 -20 83 -19 113 -24 120 -38 59z"/> <path d="M150 257 l0 -136 63 38 c34 21 86 50 116 65 60 31 63 27 -41 84 -43 24 -59 28 -66 19 -8 -9 3 -20 44 -41 47 -25 63 -46 34 -46 -5 0 -32 -13 -60 -30 -28 -17 -53 -30 -55 -30 -3 0 -5 42 -5 94 0 71 -4 97 -15 106 -13 11 -15 -4 -15 -123z"/> </g> </svg>',
    title: 'Product License Agreement',
    description: 'Tailor name tags, table tent cards, and banners​',
    // disabled: true
  },
  // {
  //   id: 'rfp-response',
  //   icon: '📋',
  //   title: 'RFP Response',
  //   description: 'Customize presentations for RFPs'
  // },
  // {
  //   id: 'ddc-format-translator',
  //   icon: '🔄',
  //   title: 'Format Translator',
  //   description: 'Convert PPTX to case studies or podcasts',
  //   disabled: true
  // }
  // {
  //   id: 'slide-creation',
  //   icon: '➕',
  //   title: 'New Slide Creation',
  //   description: 'Generate slides from images or content'
  // }
];

export const MI_WORKFLOWS: WorkflowCard[] = [
  {
    id: 'market-intelligence',
    icon: '🔍',
    title: 'Market Intelligence & Insights',
    description: 'Analyze market and prepare insights'
  },
  {
    id: 'conduct-research',
    icon: '🔍',
    title: 'Conduct Research',
    description: 'Analyze and synthesize research'
  },
  {
    id: 'target-industry-insights',
    icon: '📋',
    title: 'Generate Industry Insights',
    description: 'Target Industry Insights'
  },
  {
    id: 'prepare-client-meeting',
    icon: '📋',
    title: 'Prepare for Client Meeting',
    description: 'Prepare for a Client Meeting'
  },
  {
    id: 'create-pov',
    icon: '✏️',
    title: 'Create Point of View',
    description: 'Create a Point of View'
  },
  {
    id: 'gather-proposal-insights',
    icon: '📋',
    title: 'Gather Proposal Inputs',
    description: 'Gather Proposal Insights'
  },
];
