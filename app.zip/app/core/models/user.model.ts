export interface User {
  id?: string;
  name?: string;
  email?: string;
  firstName?: string;
  // add other fields you need
}

export interface UserProfile {
  firstName: string;
  lastName: string;
  imageURL: string;
  userPrincipalName: string;
  jobTitle: string;
  type: string;
  costCenter: {
    code: string;
    description: string;
  };
  globalLOS1: string;
  workCity: string;
  pwcGlobalNetworkCompetencyName: string;
  subLos1Desc: string;
  subLos2Desc: string;
  subLos3Desc: string;
  subLos4Desc: string | null;
  subLos5Desc: string | null;
  location: string;
}