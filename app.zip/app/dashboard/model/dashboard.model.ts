export interface BarChartData {
  name: string;
  y: number;
}

export interface PieChartData {
  name: string;
  y: number;
  color: string;
  sliced?: boolean;
}