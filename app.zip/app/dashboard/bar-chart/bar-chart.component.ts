import { Component, Input, OnInit } from '@angular/core';
import { Chart } from 'chart.js';
import { BarChartData } from '../model/dashboard.model';

@Component({
    selector: 'app-bar-chart',
    templateUrl: './bar-chart.component.html',
    styleUrls: ['./bar-chart.component.scss'],
    standalone: false
})
export class BarChartComponent implements OnInit {
  @Input() data: BarChartData[] = [];
  columnchart: any;

  ngOnInit() {
    this.createBarChart();
  }

  createBarChart() {
    this.columnchart = new Chart('barChart', {
      type: 'bar',
      data: {
        labels: this.data.map(obj => obj.name),
        datasets: [
          {
            label: 'Data',
            data: this.data.map(obj => obj.y),
            backgroundColor: '#EE5502',
          },
        ],
      },
      options: {
        scales: {
          y: {
            beginAtZero: true,
            ticks: {
              stepSize: 10,
            },
          },
        },
        plugins: {
          tooltip: {
            callbacks: {
              label: (context): string => {
                const label = context.dataset.label ?? '';
                return `${label}: ${context.formattedValue}%`;
              },
            },
          },
        },
      },
    });
  }
}  
