import { TestBed } from '@angular/core/testing';
import { BarChartComponent } from './bar-chart.component';
import { Chart } from 'chart.js';

jest.mock('chart.js', () => ({
  Chart: jest.fn().mockImplementation(() => ({
    data: {},
    options: {},
    update: jest.fn(),
  })),
}));

describe('BarChartComponent', () => {
  let component: BarChartComponent;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [BarChartComponent],
    });
    const fixture = TestBed.createComponent(BarChartComponent);
    component = fixture.componentInstance;
  });

  it('should create', () => {
    expect(component).toBeDefined();
  });

  it('should call createBarChart on init', () => {
    const spy = jest.spyOn(component, 'createBarChart');
    component.ngOnInit();
    expect(spy).toHaveBeenCalled();
  });

  it('should create a bar chart with the correct data', () => {
    const mockData = [
      { name: 'Data 1', y: 50 },
      { name: 'Data 2', y: 75 },
    ];

    component.data = mockData;
    component.ngOnInit();

    expect(Chart).toHaveBeenCalledWith('barChart', {
      type: 'bar',
      data: {
        labels: ['Data 1', 'Data 2'],
        datasets: [{
          label: 'Data',
          data: [50, 75],
          backgroundColor: '#EE5502',
        }],
      },
      options: expect.any(Object),
    });
  });

  it('should create a bar chart with default options', () => {
    component.data = [{ name: 'Data 1', y: 50 }];
    component.ngOnInit();

    const options = {
      scales: {
        y: {
          beginAtZero: true,
          ticks: {
            stepSize: 10,
          },
        },
      },
      plugins: {
        tooltip: {
          callbacks: {
            label: expect.any(Function),
          },
        },
      },
    };

    expect(Chart).toHaveBeenCalledWith(expect.any(String), expect.objectContaining({ options }));
  });
});
