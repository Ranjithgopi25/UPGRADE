import { Component } from '@angular/core';

@Component({
    selector: 'app-dashboard',
    templateUrl: './dashboard.component.html',
    styleUrls: ['./dashboard.component.scss'],
    standalone: false
})
export class DashboardComponent {
  barChartData: any[] = [];
  pieChartData: any[] = [];
  constructor() {
    this.barChartData = [
      {
        name: 'Advisory',
        y: 50,
      },
      {
        name: 'Audit',
        y: 24,
      },
      {
        name: 'Tax',
        y: 10,
      },
      {
        name: 'IFS',
        y: 4,
      },
    ];

    this.pieChartData = [
      {
        name: 'Advisory',
        y: 50,
        color: 'rgb(238,85,2)',
        sliced: true,
      },
      {
        name: 'IFS',
        y: 24,
        color: 'rgb(163,32,32)',
      },
      {
        name: 'Audit',
        y: 10,
        color: 'rgb(174, 104, 0)',
      },
      {
        name: 'Tax',
        y: 4,
        color: 'rgb(147,52,1)',
      },
    ];
  }
}
