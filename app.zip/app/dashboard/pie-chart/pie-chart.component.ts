import { Component, Input, OnInit, ViewEncapsulation } from '@angular/core';
import { Chart } from 'chart.js';
import { PieChartData } from '../model/dashboard.model';

@Component({
    selector: 'app-pie-chart',
    templateUrl: './pie-chart.component.html',
    styleUrls: ['./pie-chart.component.scss'],
    encapsulation: ViewEncapsulation.None,
    standalone: false
})
export class PieChartComponent implements OnInit {
  @Input() data!: PieChartData[];
  piechart!: any;

  ngOnInit() {
    this.piechart = new Chart("pieChart", {
      type: 'pie',

      data: {
        labels: this.data.map(obj => obj.name),
        datasets: [
          {
            data: this.data.map(obj => obj.y),
            backgroundColor: this.data.map(obj => obj.color),
          },
        ]
      },
    });
  }
}