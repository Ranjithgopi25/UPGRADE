import { TestBed, ComponentFixture } from '@angular/core/testing';
import { PieChartComponent } from './pie-chart.component';
import { PieChartData } from '../model/dashboard.model';
import { Chart } from 'chart.js';

jest.mock('chart.js');

describe('PieChartComponent', () => {
  let component: PieChartComponent;
  let fixture: ComponentFixture<PieChartComponent>;
  let mockPieChartData: PieChartData[];

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [PieChartComponent]
    }).compileComponents();
    fixture = TestBed.createComponent(PieChartComponent);
    component = fixture.componentInstance;
    mockPieChartData = [
      { name: 'A', y: 10, color: 'red', sliced: true },
      { name: 'B', y: 20, color: 'green' },
      { name: 'C', y: 30, color: 'blue' }
    ];
    component.data = mockPieChartData;
    fixture.detectChanges();
  });

  it('should create component instance', () => {
    expect(component).toBeDefined();
  });

  it('should initialize pie chart with input data', () => {
    expect(Chart).toHaveBeenCalledWith('pieChart', expect.any(Object));

    const chartCallArgs = (Chart as unknown as jest.Mock).mock.calls[0][1];
    expect(chartCallArgs.type).toEqual('pie');
    expect(chartCallArgs.data.labels).toEqual(mockPieChartData.map(obj => obj.name));
    expect(chartCallArgs.data.datasets[0].data).toEqual(mockPieChartData.map(obj => obj.y));
    expect(chartCallArgs.data.datasets[0].backgroundColor).toEqual(mockPieChartData.map(obj => obj.color));
  });


  it('should update chart data when ngOnChanges is triggered with new input data', () => {
    component.ngOnInit();

    const chartCallArgs = (Chart as unknown as jest.Mock).mock.calls[1][1];
    expect(chartCallArgs.data.labels).toEqual(mockPieChartData.map(obj => obj.name));
    expect(chartCallArgs.data.datasets[0].data).toEqual(mockPieChartData.map(obj => obj.y));
    expect(chartCallArgs.data.datasets[0].backgroundColor).toEqual(mockPieChartData.map(obj => obj.color));
  });
});
