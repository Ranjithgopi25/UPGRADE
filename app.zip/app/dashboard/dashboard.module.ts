import { NgModule } from '@angular/core';
import { BarChartComponent } from './bar-chart/bar-chart.component';
import { DashboardRoutingModule } from './dashboard-routing.module';
import { DashboardComponent } from './dashboard.component';
import { PieChartComponent } from './pie-chart/pie-chart.component';
import { PanelModule } from '@appkit4/angular-components/panel';

@NgModule({
  imports: [DashboardRoutingModule, PanelModule],
  declarations: [DashboardComponent, BarChartComponent, PieChartComponent],
})
export class DashboardModule {}
