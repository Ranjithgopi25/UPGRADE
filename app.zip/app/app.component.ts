import { ChangeDetectorRef, Component, inject, OnDestroy, OnInit } from '@angular/core';
import { Router, RouterOutlet } from '@angular/router';
//import { OauthAdapterService } from './auth/oauth-adapter.service';
import { ChatComponent } from './components/chat/chat.component';
import { ToastContainerComponent } from './shared/components/toast-container/toast-container.component';
import { CanvasEditorComponent } from './features/thought-leadership/canvas-editor/canvas-editor.component';
import { NoAccessComponent } from './auth/no-access/no-access.component';
import { MsalBroadcastService } from '@azure/msal-angular';
import { AuthService } from './auth/auth.service';
import { filter, Subject, Subscription, take, takeUntil, tap, firstValueFrom } from 'rxjs';
import { InteractionStatus } from '@azure/msal-browser';
import { environment } from '../environments/environment';
import { CurrentUserService } from './core/services/current-user.service';
import { User, UserProfile} from './core/models/user.model';
import { ChatService } from './core/services/chat.service';
import { AuthFetchService } from './core/services/auth-fetch.service';



const ENABLE_AUTH = environment.useAuth;
@Component({
    selector: 'app-root',
    imports: [RouterOutlet, ChatComponent, ToastContainerComponent, CanvasEditorComponent, NoAccessComponent],
    templateUrl: './app.component.html',
    styleUrl: './app.component.scss'
})
/*
export class AppComponent {
  title = 'MCX AI - PwC Presentation Assistant';
 
}
*/


  export class AppComponent implements OnInit, OnDestroy {
    title = 'MCX AI - PwC Presentation Assistant';
  

  // Inject services
  private router = inject(Router);
  private cdr = inject(ChangeDetectorRef);
  private msalBroadcastService = ENABLE_AUTH ? inject(MsalBroadcastService) : null;//change when login implemented
  private authService = inject(AuthService);
  private currentUserService = inject(CurrentUserService);
  private authFetchService = inject(AuthFetchService);

  //public loadingService = inject(LoadingService);
  authInitialized = false;  
  currentUrl: string = '';
 // chatOpen = false;
 // chatOpenTimeEntry = false;
  currentUser: any = { name: 'Test' }; //change when login implemented
  isLoading = true;
  loginComplete = false; //change when login implemented
  loginprogress=false;
  showNoAccessPage = false; //change when login implemented
 // private routerSubscription: Subscription;
  private readonly _destroying$ = new Subject<void>();

  
  constructor(private chatService: ChatService) {
    /*
    this.currentUrl = this.router.url;
    this.routerSubscription = this.router.events
      .pipe(filter(event => event instanceof NavigationEnd))
      .subscribe((event: NavigationEnd) => {
        this.currentUrl = event.url;
      });
      */
  }

 ngOnInit() {
  
  // Check if returning from redirect
  const urlParams = new URLSearchParams(window.location.search);
  const hasCode = urlParams.has('code');
  const hasError = urlParams.has('error');
  const hasState = urlParams.has('state');
  

 // this.loadingService.setLoading(true);
  
  if (ENABLE_AUTH && this.msalBroadcastService) {
    let subscriptionId = Math.random().toString(36).substr(2, 9);
    
    let emissionCount = 0;
    
    this.msalBroadcastService.inProgress$
      .pipe(
        tap((status) => {
          emissionCount++;
        }),
        filter((status: InteractionStatus) => {
          const isNone = status === InteractionStatus.None;
          return isNone;
        }),
        take(1),
        takeUntil(this._destroying$)
      )
      .subscribe({
        next: () => {

          this.handleMsalCallback(subscriptionId);
        },
        error: (error) => {

        },
        complete: () => {

        }
      });
  }
}

private async handleMsalCallback(subscriptionId: string) {
  
  this.authInitialized = true;
  this.isLoading = true;
  
  if (this.authService.isLoggedIn()) {
    try {
      // Get user info and set in shared service
      this.currentUser = this.authService.getUserInfo();
      console.log('[AppComponent] User info:', this.currentUser);
      this.currentUserService.setUser(this.currentUser as User);
      
      // Get access token
      const token = await this.authService.getAccessToken();
      
      // Initialize token refresh cycle
      this.authFetchService.initializeTokenRefresh();
      
      // STEP 1: Fetch user profile (called once, then reused)
      console.log('[AppComponent] 📥 Fetching user profile...');
      const userProfile: any = await this.authService.getUserProfile();
      console.log('[AppComponent] ✅ User Profile retrieved:', userProfile);
      
      // STEP 2: Check if user is accepted (from API response)
      const acceptedUsers = userProfile?.acceptedUsers ?? false;
      if (!acceptedUsers) {
        console.log('[AppComponent] ❌ User not accepted - showing no access page');
        this.showNoAccessPage = true;
        this.loginComplete = false;
        this.isLoading = false;
        this.cdr.detectChanges();
        return;
      }
      
      // STEP 3: Extract module access from same profile (no additional API calls)
      const docStudioAccess = userProfile?.doc_studio ?? false;
      const miAccess = userProfile?.mi ?? false;
      const cortexAccess = userProfile?.cortex ?? false;
      
      console.log('[AppComponent] ✅ User accepted - setting module visibility', {
        doc_studio: docStudioAccess,
        mi: miAccess,
        cortex: cortexAccess
      });
      
      // STEP 4: Store module access in AuthService so chat component can read it
      this.authService.setModuleAccess({
        docStudio: docStudioAccess,
        marketIntelligence: miAccess,
        cortex: cortexAccess
      });
      
      // STEP 5: Show app and hide loading screen
      console.log('[AppComponent] 🎉 Rendering chat component...');
      this.loginComplete = true;
      this.isLoading = false;
      this.cdr.detectChanges();
      
    } catch (error) {
      console.error('[AppComponent] ❌ Error during auth callback:', error);
      this.isLoading = false;
      this.cdr.detectChanges();
    }
  } else if (!this.loginprogress) {
    this.loginprogress = true;
    setTimeout(() => {
      this.authService.login();
    }, 500);
  }
}

  ngOnDestroy() {
    console.log('[AppComponent] 🧹 Component destroyed, stopping token refresh');
    this.authFetchService.stopTokenRefresh();
    this._destroying$.next(undefined);
    this._destroying$.complete();
    /*
    if (this.routerSubscription) {
      this.routerSubscription.unsubscribe();
    }
      */
  }

  logout() {
    console.log('[AppComponent] 👋 Logout initiated, stopping token refresh');
    this.authFetchService.stopTokenRefresh();
    this.authService.logout();
    this.currentUserService.clearUser();
  }

  shouldShowChatWidget(): boolean {
    return this.currentUrl === '/calendar-management' && this.loginComplete;
  }

  shouldShowTimeEntryWidget(): boolean {
    return (this.currentUrl === '/' || this.currentUrl === '/time-entry') && this.loginComplete;
  }
}