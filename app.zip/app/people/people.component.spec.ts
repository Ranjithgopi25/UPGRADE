import { CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA } from '@angular/core';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { Router } from '@angular/router';
import { Subject, of } from 'rxjs';

import { PeopleDataService } from './people-data.service';
import { PeopleComponent } from './people.component';
import { Person } from './person-model';

describe('PeopleComponent', () => {
  let component: PeopleComponent;
  let fixture: ComponentFixture<PeopleComponent>;
  let peopleDataService: PeopleDataService;
  const mockData = {
    id: '1',
  };
  let router: Router;
  let ngUnsubscribe: Subject<any>;

  const peopleSvcMock = {
    delete: () => of(),
    peopleSubjectSub: of({ id: '' }),
    getById: () => of({ id: '', name: '', address: '', country: '' }),
    create: () => of(mockData),
    getAll: () => of([mockData]),
    update: () => of(mockData),
  };

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [PeopleComponent],
      providers: [
        { provide: Router, useValue: { navigate: jest.fn() } },
        {
          provide: PeopleDataService,
          multi: false,
          useValue: peopleSvcMock,
        }
      ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA],
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(PeopleComponent);
    component = fixture.componentInstance;
    peopleDataService = TestBed.inject(PeopleDataService);
    router = TestBed.inject(Router);
    ngUnsubscribe = new Subject();
  });

  afterEach(() => {
    ngUnsubscribe.next('');
    ngUnsubscribe.complete();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });


  it('should retrieve all People on initialization', () => {
    jest.spyOn(peopleDataService, 'getAll');

    fixture.detectChanges();

    expect(peopleDataService.getAll).toHaveBeenCalled();
    expect(component.people).toEqual([mockData]);
  });

  it('should delete an item', () => {
    const id = '1';
    component.people = [mockData];
    jest.spyOn(peopleDataService, 'delete');
    const itemIndex = component.people.findIndex(m => m.id === id);
    component.people.splice(itemIndex, 1);
    component.people = [...component.people];

    component.deleteItem(id);

    expect(peopleDataService.delete).toHaveBeenCalledWith(id);
    expect(component.people).toEqual([]);
  });


  it('should open item in modal', () => {
    const item: Person = mockData;
    component.modal = { showModal: jest.fn() };
    component.selectedPerson = mockData;
    component.modalTitle = '';

    component.openItemInModal(item);

    expect(component.selectedPerson).toEqual(item);
    expect(component.modalTitle).toEqual('Edit Person');
  });

  it('should add new item', () => {
    component.selectedPerson = mockData;
    component.modal = { showModal: jest.fn() };
    component.modalTitle = '';

    component.addNew();

    expect(component.selectedPerson).toEqual({});
    expect(component.modalTitle).toEqual('New Person');
  });

  it('should update data', () => {
    const data: Person = mockData;
    const expectedItem: Person = mockData;
    component.people = [mockData];
    jest.spyOn(peopleDataService, 'update');

    component.dataUpdated(data);

    expect(peopleDataService.update).toHaveBeenCalledWith(data);
    expect(component.people[0]).toEqual(expectedItem);
  });

  it('should create data', () => {
    const createMockData = {
      id: '',
    };
    const data: Person = createMockData;
    const expectedItem: Person = mockData;
    component.people = [mockData];
    jest.spyOn(peopleDataService, 'create');

    component.dataUpdated(data);

    expect(peopleDataService.create).toHaveBeenCalledWith(data);
    expect(component.people[0]).toEqual(expectedItem);
  });

  it('should open dialog', () => {
    component.modal = { showModal: jest.fn() };

    component.openDialog();

    expect(component.modal.showModal).toHaveBeenCalledWith('modal-create');
  });



  it('should close dialog', () => {
    component.modal = { closeModal: jest.fn() };

    component.closeDialog();

    expect(component.modal.closeModal).toHaveBeenCalledWith('modal-create');
  });


  it('should call onSort method', () => {
    console.info = jest.fn();

    component.onSort('sortEvent');

    expect(console.info).toHaveBeenCalledWith('Sort called with:', 'sortEvent');
  });

});
