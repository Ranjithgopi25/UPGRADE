import { Component, EventEmitter, Input, Output, OnChanges } from '@angular/core';
import { FormBuilder, FormGroup, AbstractControl, Validators } from '@angular/forms';
import { Person } from '../person-model';

@Component({
    selector: 'app-create',
    templateUrl: './create.component.html',
    styleUrls: ['./create.component.scss'],
    standalone: false
})
export class CreateComponent implements OnChanges {
  personForm: FormGroup;
  @Input() personData!: Person;

  constructor(private fb: FormBuilder) {
    this.personForm = this.fb.group({});
  }

  ngOnChanges() {
    this.personForm = this.fb.group({
      id: this.personData?.id ?? '',
    });
  }

  @Input()
  title: string | undefined;

  @Output()
  modalDisplayChange = new EventEmitter();

  @Output()
  dataChanged = new EventEmitter();

  closeModal() {
    this.modalDisplayChange.emit('');
  }

  submitForm() {
    const data = this.personForm.value;
    this.dataChanged.emit(data);
    this.personForm.reset();
    this.modalDisplayChange.emit('');
  }

}
