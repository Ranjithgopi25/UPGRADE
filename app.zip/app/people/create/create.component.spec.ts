import { CreateComponent } from './create.component';

describe('CreateComponent', () => {
  let component: any;
  let formBuilder: any;
  beforeEach(() => {
    formBuilder = {
      group: jest.fn(),
    };
    component = new CreateComponent(formBuilder);
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should emit blank string on calling of closeModal Function', () => {
    let spy = jest.spyOn(component.modalDisplayChange, 'emit');
    component.closeModal();
    expect(spy).toHaveBeenCalled();
  });

  it('should call reset on completion of submitForm Function', () => {
    component.personForm = { reset: jest.fn(), value: { id: '' } };
    component.submitForm();
    expect(component.personForm.reset).toHaveBeenCalled();
  });
});
