import { HttpClient } from '@angular/common/http';
import { of } from 'rxjs';
import { PeopleDataService } from './people-data.service';
import { Person } from './person-model';

describe('PeopleDataService', () => {
  let service: PeopleDataService;
  let httpClient: HttpClient;

  beforeEach(() => {
    httpClient = {
      get: jest.fn(),
      post: jest.fn(),
      put: jest.fn(),
      delete: jest.fn(),
    } as any;
    service = new PeopleDataService(httpClient);
  });

  it('should retrieve all People', () => {
    const expectedData = [{ id: '1', name: 'Model 1' }, { id: '2', name: 'Model 2' }];
    jest.spyOn(httpClient, 'get').mockReturnValue(of(expectedData));

    service.getAll().subscribe((data: Person[]) => {
      expect(data).toEqual(expectedData);
    });
    expect(httpClient.get).toHaveBeenCalled();
  });

  it('should retrieve a Person by id', () => {
    const expectedData = { id: '1', name: 'Model 1' };
    const id = '1';
    jest.spyOn(httpClient, 'get').mockReturnValue(of(expectedData));

    service.getById(id).subscribe((data: Person) => {
      expect(data).toEqual(expectedData);
    });
    expect(httpClient.get).toHaveBeenCalled();
  });

  it('should delete a Person by id', () => {
    const id = '1';
    jest.spyOn(httpClient, 'delete').mockReturnValue(of(null));

    service.delete(id).subscribe(() => {
      expect(httpClient.delete).toHaveBeenCalled();
    });
  });

  it('should create a Person', () => {
    const person = { id: '1', name: 'Model 1' };
    const expectedData = { id: '1', name: 'Model 1' };
    jest.spyOn(httpClient, 'post').mockReturnValue(of(expectedData));

    service.create(person).subscribe(data => {
      expect(data).toEqual(expectedData);
    });

    expect(httpClient.post).toHaveBeenCalled();
  });

  it('should update a Person', () => {
    const person = { id: '1', name: 'Model 1' };
    jest.spyOn(httpClient, 'put').mockReturnValue(of(person));

    service.update(person).subscribe(data => {
      expect(data).toEqual(person);
    });
    expect(httpClient.put).toHaveBeenCalled();
  });
});  
