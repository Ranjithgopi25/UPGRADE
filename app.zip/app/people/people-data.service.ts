import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from '../../environments/environment';
import { Person } from './person-model';

@Injectable()
export class PeopleDataService {

  private apiUrl = `${environment.apiUrl}people`;

  constructor(private httpClient: HttpClient) {}

  public getAll(): Observable<Person[]> {
    return this.httpClient.get<Person[]>(this.apiUrl);
  }

  public getById(id: string): Observable<Person> {
    const safeId = this.sanitizeId(id);
    if (!safeId) {
      throw new Error('Invalid ID format');
    }
    const encodedId = encodeURIComponent(safeId);
    return this.httpClient.get<Person>(`${this.apiUrl}/${encodedId}`);
  }

  public delete(id: string): Observable<void> {
    const safeId = this.sanitizeId(id);
    if (!safeId) {
      throw new Error('Invalid ID format');
    }
    const encodedId = encodeURIComponent(safeId);
    return this.httpClient.delete<void>(`${this.apiUrl}/${encodedId}`);
  }

  public create(person: Person): Observable<Person> {
    return this.httpClient
      .post<Person>(this.apiUrl, person);
  }

  public update(person: Person): Observable<Person>  {
    return this.httpClient
      .put<Person>(`${this.apiUrl}/${person.id}`,  person);
  }

  private sanitizeId(id: string): string | null {
    const isValid = /^[a-zA-Z0-9\-]+$/;
    return isValid.test(id) ? id : null;
  }
}
