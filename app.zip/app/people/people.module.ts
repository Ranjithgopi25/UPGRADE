import {
  NgModule
} from '@angular/core';

import { ReactiveFormsModule } from '@angular/forms';
import { CreateComponent } from './create/create.component';
import { PeopleDetailsComponent } from './people-details/people-details.component';
import { PeopleRoutingModule } from './people-routing.module';
import { PeopleComponent } from './people.component';
import { PeopleDataService } from './people-data.service';
import { ButtonModule } from '@appkit4/angular-components/button';
import { TableModule } from '@appkit4/angular-components/table';
import { ModalModule } from '@appkit4/angular-components/modal';
import { FieldModule } from '@appkit4/angular-components/field';
import { FormsModule } from '@angular/forms';
import { BreadcrumbModule } from '@appkit4/angular-components/breadcrumb';
import { CommonModule } from '@angular/common';
import { PaginationModule } from '@appkit4/angular-components/pagination';
import { CheckboxModule } from '@appkit4/angular-components/checkbox';
import { PanelModule } from '@appkit4/angular-components/panel';
import { ToggleModule } from '@appkit4/angular-components/toggle';

@NgModule({
  imports: [
    ButtonModule,
    TableModule,
    BreadcrumbModule,
    PaginationModule,
    CheckboxModule,
    PanelModule,
    ModalModule,
    FieldModule,
    ToggleModule,
    FormsModule,
    CommonModule,
    ReactiveFormsModule,
    PeopleRoutingModule,
  ],
  declarations: [
    PeopleComponent,
    PeopleDetailsComponent,
    CreateComponent,
  ],
  providers: [PeopleDataService],
})
export class PeopleModule { }
