import {
  AfterViewInit,
  Component,
  OnDestroy,
  OnInit,
  ViewChild,
} from '@angular/core';
import { Router } from '@angular/router';
import { PaginationComponent } from '@appkit4/angular-components/pagination';
import { Subject, takeUntil } from 'rxjs';
import { Person } from './person-model';
import { PeopleDataService } from './people-data.service';

@Component({
    selector: 'app-people',
    templateUrl: './people.component.html',
    styleUrls: ['./people.component.scss'],
    standalone: false
})
export class PeopleComponent implements OnInit, AfterViewInit, OnDestroy {
  selectedPerson!: Person;
  modalTitle!: string;
  @ViewChild('modal', { static: false }) modal: any;
  people!: Person[];
  config: any = {};
  @ViewChild('pagination') pagination: PaginationComponent | undefined;

  private ngUnsubscribe = new Subject();

  constructor(
    private peopleDataService: PeopleDataService,
    private router: Router
  ) { }

  onSort(event: any) {
    console.info('Sort called with:', event);
  }

  ngAfterViewInit() {
    this.config['pagination'] = this.pagination;
    this.config['pageSize'] = 10;
  }

  ngOnInit() {
    this.peopleDataService
      .getAll()
      .pipe(takeUntil(this.ngUnsubscribe))
      .subscribe(items => {
        this.people = items;
      });
  }
  deleteItem(id: string) {
    this.peopleDataService.delete(id)
      .pipe(takeUntil(this.ngUnsubscribe))
      .subscribe(() => {
        const itemIndex = this.people.findIndex(m => m.id === id);
        this.people.splice(itemIndex, 1);

        // trigger a change on the grid
        this.people = [...this.people];
      });
  }
  view(id: string) {
    this.router.navigate(['/people/', id]);
  }

  openItemInModal(item: Person) {
    this.selectedPerson = item;

    this.modalTitle = 'Edit Person';
    this.openDialog();
  }

  addNew() {
    this.modalTitle = 'New Person';
    this.selectedPerson = <Person>{};
    this.openDialog();
  }

  dataUpdated(data: Person) {
    if (data.id) {
      this.peopleDataService.update(data)
        .pipe(takeUntil(this.ngUnsubscribe))
        .subscribe(() => {
          const item = this.people.find(m => m.id === data.id);

          if (item) {
          }

          // trigger a change on the grid
          this.people = [...this.people];
        });

        return;
    }

    this.peopleDataService.create(data)
      .pipe(takeUntil(this.ngUnsubscribe))
      .subscribe(item => {
        this.people = [item, ...this.people];
      });
  }

  openDialog() {
    this.modal.showModal('modal-create');
  }

  closeDialog() {
    this.modal.closeModal('modal-create');
  }

  ngOnDestroy() {
    this.ngUnsubscribe.next('');
    this.ngUnsubscribe.complete();
  }
}
