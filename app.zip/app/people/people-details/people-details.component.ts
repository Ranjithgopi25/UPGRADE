import { Component, OnDestroy, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Subject, takeUntil } from 'rxjs';
import { PeopleDataService } from '../people-data.service';

@Component({
    selector: 'app-people-details',
    templateUrl: './people-details.component.html',
    styleUrls: ['./people-details.component.scss'],
    standalone: false
})
export class PeopleDetailsComponent implements OnInit, OnDestroy {
  id: any;
  peopleDetails: any = {};
  ngUnsubscribe = new Subject();

  constructor(
    private route: ActivatedRoute,
    private detailsService: PeopleDataService
  ) {}

  ngOnInit() {
    this.route.params.subscribe((params) => {
      this.id = params['id'];
      this.getById();
    });
  }

  private getById() {
    this.detailsService
      .getById(this.id)
      .pipe(takeUntil(this.ngUnsubscribe))
      .subscribe(
        (result: any) => {
          if (result) {
            this.peopleDetails = result;
          }
        },

        (error) => {
          console.info(error);
        }
      );
  }

  ngOnDestroy() {
    this.ngUnsubscribe.next('');
    this.ngUnsubscribe.complete();
  }
}
