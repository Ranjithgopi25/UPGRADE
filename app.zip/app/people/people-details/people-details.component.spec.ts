import { ComponentFixture, TestBed } from '@angular/core/testing';
import { ActivatedRoute } from '@angular/router';
import { BehaviorSubject, of } from 'rxjs';
import { PeopleDetailsComponent } from './people-details.component';
import { PeopleDataService } from '../people-data.service';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';

describe('PeopleDetailsComponent', () => {
  let component: PeopleDetailsComponent;
  let fixture: ComponentFixture<PeopleDetailsComponent>;

  const routerMock = {
    params: of({ id: '' }),
  };

  const peopleSvcMock = {
    getById: () => of({}),
  };

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [PeopleDetailsComponent],
      providers: [
        { provide: ActivatedRoute, multi: false, useValue: routerMock },
        {
          provide: PeopleDataService,
          multi: false,
          useValue: peopleSvcMock,
        },
      ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(PeopleDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
