import { provideHttpClient, withInterceptorsFromDi } from '@angular/common/http';
import { 
NgModule, inject, provideAppInitializer } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { AppRoutingModule } from './app-routing.module';
import { MainComponent } from './main/main.component';
import { TokenComponent } from './auth/token.component/token.component';
import { PeopleDataService } from './people/people-data.service';
import { AvatarModule } from '@appkit4/angular-components/avatar';
import { DropdownModule } from '@appkit4/angular-components/dropdown';
import { FooterModule } from '@appkit4/angular-components/footer';
import { HeaderModule } from '@appkit4/angular-components/header';
import { LoadingModule } from '@appkit4/angular-components/loading';
import { NavigationModule } from '@appkit4/angular-components/navigation';
import { OauthAdapterModule } from './auth/oauth-adapter.module';
import { OauthAdapterService } from './auth/oauth-adapter.service';
import { appInitFactory } from './auth/bootstrap-factory';
import { Router } from '@angular/router';
import { NgChartsModule } from 'ng2-charts';

@NgModule({ declarations: [MainComponent, TokenComponent],
    bootstrap: [MainComponent], imports: [BrowserModule,
        NgChartsModule,
        HeaderModule,
        AvatarModule,
        FooterModule,
        DropdownModule,
        LoadingModule,
        NavigationModule,
        AppRoutingModule,
        BrowserAnimationsModule,
        OauthAdapterModule,

  ],
  providers: [

        PeopleDataService,
        provideAppInitializer(() => {
          const oauthService = inject(OauthAdapterService);
          const initializerFn = (
            appInitFactory
          )(
            oauthService
          );
          return initializerFn();
        }),
        provideHttpClient(withInterceptorsFromDi()),
    ] })
export class AppModule {}
