import { Component, OnInit, OnDestroy, ChangeDetectorRef } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ChatService } from '../../../core/services';
import { CurrentUserService } from '../../../core/services/current-user.service';
import { AuthService } from '../../../auth/auth.service';
import { LeaderReviewFlowComponent } from '../../../features/thought-leadership/leader-review/leader-review-flow.component';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';

@Component({
  selector: 'app-my-requests-table',
  standalone: true,
  imports: [CommonModule, FormsModule, LeaderReviewFlowComponent],
  templateUrl: './my-requests-table.component.html',
  styleUrls: ['./my-requests-table.component.scss']
})
export class MyRequestsTableComponent implements OnInit, OnDestroy {
  // Expose Array for template usage with @for
  Array = Array;
  // Panel state
  showMyRequestsPanel: boolean = false;
  activeTab: 'requests' | 'reviews' = 'requests';
  
  // Track if data has been fetched to avoid duplicate API calls
  private myRequestsDataFetched: boolean = false;
  private leaderTasksDataFetched: boolean = false;
  
  // My Requests data and columns
  myRequestsData: any[] = [];
  leaderTasksData: any[] = [];
  myRequestsColumns: string[] = [];
  leaderTasksColumns: string[] = [];
  isLoading: boolean = false;
  error: string = '';
  
  // Filter state for My Requests tab
  myRequestsFilters: { [key: string]: string } = {};
  filteredMyRequestsData: any[] = [];
  myRequestsActiveFilterColumns: Set<string> = new Set();
  selectedMyRequestsColumnToAdd: string = '';
  
  // Filter state for Review Requests tab
  leaderTasksFilters: { [key: string]: string } = {};
  filteredLeaderTasksData: any[] = [];
  leaderTasksActiveFilterColumns: Set<string> = new Set();
  selectedLeaderTasksColumnToAdd: string = '';

  // Pagination state
  itemsPerPage: number = 7;
  currentPageMyRequests: number = 1;
  currentPageLeaderTasks: number = 1;
  maxPagesToShow: number = 3;
  paginationOffsetMyRequests: number = 0;
  paginationOffsetLeaderTasks: number = 0;

  // Track which files are currently downloading to disable buttons
  downloadingRequestIds: Set<string> = new Set();

  // Confirmation dialog state
  showConfirmationDialog: boolean = false;
  confirmationData: {
    action: 'approve' | 'reject';
    requestId: string;
    statusType: 'offering' | 'practice';
  } | null = null;

  // Leader Review Flow state
  showLeaderReviewFlow: boolean = false;
  leaderReviewFlowData: {
    requestId: string;
    statusType: 'offering' | 'practice';
    requestData: any;
  } | null = null;

  // Form Data Popup state
  showFormDataPopup: boolean = false;
  formDataPopupContent: any = null;
  formDataPopupTitle: string = '';

  // Risk Assessment View state
  showRiskAssessmentView: boolean = false;
  riskAssessmentViewData: any = null;
  riskAssessmentViewRequestId: string = '';
  riskAssessmentViewRequestData: any = null;
  riskAssessmentViewTab: 'user' | 'offering' | 'practice' = 'user';

  // Notification/Toast state
  showNotification: boolean = false;
  notificationMessage: string = '';
  notificationTimeout: any = null;

  private destroy$ = new Subject<void>();

  constructor(
    private chatService: ChatService,
    private currentUserService: CurrentUserService,
    private authService: AuthService,
    private cdr: ChangeDetectorRef
  ) {}

  ngOnInit(): void {
    // Retrieve and store access token on component initialization
    this.authService.getAccessToken();
  }

  ngOnDestroy(): void {
    this.destroy$.next();
    this.destroy$.complete();
  }

  /**
   * Handle My Requests button click from parent component
   * Deactivate any selected flow and show the My Requests panel
   */
  onMyRequestsClick(): void {
    this.showMyRequestsPanel = true;
    this.activeTab = 'requests';
    this.cdr.markForCheck();
    // Always fetch fresh data when opening the panel
    this.myRequestsDataFetched = false;
    this.fetchMyRequests();
  }

  /**
   * Close the My Requests panel
   */
  closeMyRequestsPanel(): void {
    this.showMyRequestsPanel = false;
    this.cdr.markForCheck();
  }

  /**
   * Switch between My Requests and Review Requests tabs
   */
  switchTab(tab: 'requests' | 'reviews'): void {
    this.activeTab = tab;
    this.cdr.markForCheck();
    if (tab === 'requests') {
      this.leaderTasksDataFetched = false;
      this.fetchMyRequests();
    } else if (tab === 'reviews') {
      this.myRequestsDataFetched = false;
      this.fetchLeaderTasks();
    }
  }

  /**
   * Fetch user's requests from the API and populate the table with dynamic columns
   */
  private fetchMyRequests(): void {
    // Log API call for debugging first-time navigation issues
    console.log('[MyRequestsTableComponent] fetchMyRequests called', { myRequestsDataFetched: this.myRequestsDataFetched });
    
    this.isLoading = true;
    this.error = '';
    this.cdr.markForCheck();

    const currentUser = this.currentUserService.currentUser;
    const requestedEmail = (currentUser?.email || '').toLowerCase().replace('@dev365.', '@');
    if (!currentUser || !requestedEmail) {
      this.error = 'User email not found. Please log in again.';
      this.isLoading = false;
      this.cdr.markForCheck();
      return;
    }

    // Define which columns to display for My Requests
    const desiredColumns = ['request_id', 'offering_leader_name', 'offering_leader_status', 'practice_leader_name', 'practice_leader_status', 'request_status', 'phoenix_id', 'created_at'];

    this.chatService.getMyRequests(requestedEmail).pipe(
      takeUntil(this.destroy$)
    ).subscribe({
      next: (response: any) => {
        if (response?.success && response?.data && Array.isArray(response.data)) {
          this.myRequestsData = response.data;
          
          // Set column list first - filter to only desired columns that exist in the response
          this.myRequestsColumns = desiredColumns.filter(col => 
            response.data.length > 0 && col in response.data[0]
          );
          
          console.log('[MyRequestsTableComponent] Final columns to display:', this.myRequestsColumns);

          // Transform data to only include desired columns, but preserve file_size, user info, email fields, and request_link for tooltips
          this.myRequestsData = response.data.map((row: any) => {
            const filteredRow: any = {};
            this.myRequestsColumns.forEach(col => {
              filteredRow[col] = row[col];
            });
            // Always include these fields for API calls and tooltip display, even if not in columns
            if (row.file_size) {
              filteredRow.file_size = row.file_size;
            }
            if (row.file_name) {
              filteredRow.file_name = row.file_name;
            }
            if (row.user_name) {
              filteredRow.user_name = row.user_name;
            }
            if (row.user_email) {
              filteredRow.user_email = row.user_email;
            }
            if (row.offering_leader_email) {
              filteredRow.offering_leader_email = row.offering_leader_email;
            }
            if (row.practice_leader_email) {
              filteredRow.practice_leader_email = row.practice_leader_email;
            }
            if (row.request_link) {
              filteredRow.request_link = row.request_link;
            }
            if (row.user_form_data) {
              filteredRow.user_form_data = row.user_form_data;
            }
            if (row.phoenix_form_data) {
              filteredRow.phoenix_form_data = row.phoenix_form_data;
            }
            if (row.sharepoint_file_link) {
              filteredRow.sharepoint_file_link = row.sharepoint_file_link;
            }
            if (row.phoenix_link) {
              filteredRow.phoenix_link = row.phoenix_link;
            }
            return filteredRow;
          });
          
          // Sort data by created_at in descending order (most recent first)
          this.myRequestsData = this.sortDataByCreatedAt(this.myRequestsData);
          
          // Initialize filters for each column
          this.myRequestsFilters = {};
          this.myRequestsColumns.forEach(col => {
            this.myRequestsFilters[col] = '';
          });
          
          // Apply initial filter
          this.applyMyRequestsFilter();
        } else {
          this.myRequestsData = [];
          this.myRequestsColumns = [];
          this.myRequestsFilters = {};
          this.filteredMyRequestsData = [];
        }
        this.myRequestsDataFetched = true;
        this.isLoading = false;
        this.cdr.markForCheck();
      },
      error: (err) => {
        console.error('Error fetching my requests:', err);
        this.error = err?.error?.message || 'Failed to fetch requests. Please try again.';
        this.myRequestsData = [];
        this.myRequestsColumns = [];
        this.isLoading = false;
        this.myRequestsDataFetched = true;
        this.cdr.markForCheck();
      },
      complete: () => {
        this.myRequestsDataFetched = true;
      }
    });
  }

  /**
   * Apply filter to My Requests data based on filter criteria
   */
  applyMyRequestsFilter(): void {
    this.filteredMyRequestsData = this.myRequestsData.filter(row => {
      return Object.entries(this.myRequestsFilters).every(([columnName, filterValue]) => {
        if (!filterValue || filterValue.trim() === '') {
          return true; // Empty filter means show all
        }
        
        const cellValue = String(row[columnName] || '').toLowerCase();
        const searchValue = filterValue.toLowerCase();
        return cellValue.includes(searchValue);
      });
    });
    this.currentPageMyRequests = 1; // Reset to first page when filter changes
    this.paginationOffsetMyRequests = 0; // Reset pagination offset
    this.cdr.markForCheck();
  }
  
  /**
   * Apply filter to Leader Tasks (Review Requests) data based on filter criteria
   */
  applyLeaderTasksFilter(): void {
    this.filteredLeaderTasksData = this.leaderTasksData.filter(row => {
      return Object.entries(this.leaderTasksFilters).every(([columnName, filterValue]) => {
        if (!filterValue || filterValue.trim() === '') {
          return true; // Empty filter means show all
        }
        
        const cellValue = String(row[columnName] || '').toLowerCase();
        const searchValue = filterValue.toLowerCase();
        return cellValue.includes(searchValue);
      });
    });
    this.currentPageLeaderTasks = 1; // Reset to first page when filter changes
    this.paginationOffsetLeaderTasks = 0; // Reset pagination offset
    this.cdr.markForCheck();
  }
  
  /**
   * Update filter for My Requests and reapply (multi-column support)
   */
  onMyRequestsFilterChange(column: string, value: string): void {
    this.myRequestsFilters[column] = value;
    this.applyMyRequestsFilter();
  }

  /**
   * Add a new column to filter for My Requests
   */
  addMyRequestsFilterColumn(column: string): void {
    if (column && !this.myRequestsActiveFilterColumns.has(column)) {
      this.myRequestsActiveFilterColumns.add(column);
      this.myRequestsFilters[column] = '';
      this.selectedMyRequestsColumnToAdd = '';
      this.cdr.markForCheck();
    }
  }

  /**
   * Remove a column from filter for My Requests
   */
  removeMyRequestsFilterColumn(column: string): void {
    this.myRequestsActiveFilterColumns.delete(column);
    this.myRequestsFilters[column] = '';
    this.cdr.markForCheck();
    this.applyMyRequestsFilter();
  }

  /**
   * Get available columns to add for My Requests (excluding already active ones)
   */
  getAvailableMyRequestsColumns(): string[] {
    return this.myRequestsColumns.filter(col => !this.myRequestsActiveFilterColumns.has(col));
  }
  
  /**
   * Update filter for Leader Tasks and reapply (multi-column support)
   */
  onLeaderTasksFilterChange(column: string, value: string): void {
    this.leaderTasksFilters[column] = value;
    this.applyLeaderTasksFilter();
  }

  /**
   * Add a new column to filter for Leader Tasks
   */
  addLeaderTasksFilterColumn(column: string): void {
    if (column && !this.leaderTasksActiveFilterColumns.has(column)) {
      this.leaderTasksActiveFilterColumns.add(column);
      this.leaderTasksFilters[column] = '';
      this.selectedLeaderTasksColumnToAdd = '';
      this.cdr.markForCheck();
    }
  }

  /**
   * Remove a column from filter for Leader Tasks
   */
  removeLeaderTasksFilterColumn(column: string): void {
    this.leaderTasksActiveFilterColumns.delete(column);
    this.leaderTasksFilters[column] = '';
    this.cdr.markForCheck();
    this.applyLeaderTasksFilter();
  }

  /**
   * Get available columns to add for Leader Tasks (excluding already active ones)
   */
  getAvailableLeaderTasksColumns(): string[] {
    return this.leaderTasksColumns.filter(col => !this.leaderTasksActiveFilterColumns.has(col));
  }

  /**
   * Format column names from snake_case to user-friendly Title Case
   * Example: "request_id" -> "Request ID"
   */
  formatColumnName(columnName: string): string {
    return columnName
      .split('_') // Split by underscore
      .map(word => word.charAt(0).toUpperCase() + word.slice(1).toLowerCase()) // Capitalize each word
      .join(' '); // Join with space
  }

  /**
   * Format tooltip text showing filename and file size
   * Example: "report.pdf (2.5 MB)"
   */
  formatFileTooltip(fileName: string, fileSize?: number): string {
    if (!fileName) {
      return '';
    }
    
    if (!fileSize) {
      return fileName;
    }

    // Format file size to human-readable format
    const sizeInMB = fileSize / (1024 * 1024);
    if (sizeInMB >= 1) {
      return `${fileName} (${sizeInMB.toFixed(2)} MB)`;
    }

    const sizeInKB = fileSize / 1024;
    if (sizeInKB >= 1) {
      return `${fileName} (${sizeInKB.toFixed(2)} KB)`;
    }

    return `${fileName} (${fileSize} B)`;
  }

  /**
   * Format tooltip text showing leader name and email
   * Example: "John Doe (john.doe@example.com)"
   */
  formatLeaderTooltip(leaderName: string, leaderEmail?: string): string {
    if (!leaderName) {
      return '';
    }

    if (!leaderEmail) {
      return leaderName;
    }

    return `${leaderName}\n${leaderEmail}`;
  }

  /**
   * Sort data by created_at date in descending order (most recent first)
   */
  private sortDataByCreatedAt(data: any[]): any[] {
    return data.sort((a, b) => {
      const dateA = new Date(a.created_at).getTime();
      const dateB = new Date(b.created_at).getTime();
      // Descending order: newer dates first
      return dateB - dateA;
    });
  }

  /**
   * Show confirmation dialog for Approve action
   */
  onApproveLeaderStatus(requestId: string, statusType: 'offering' | 'practice'): void {
    // Get the row data for the request
    const row = this.leaderTasksData.find((r: any) => r.request_id === requestId);
    
    if (row) {
      // Always open both Risk Assessment View and Leader Review Flow side by side
      this.leaderReviewFlowData = {
        requestId,
        statusType,
        requestData: row
      };
      
      // Always set up risk assessment view data (even if empty)
      this.riskAssessmentViewRequestId = requestId;
      this.riskAssessmentViewRequestData = row;
      
      // Try to parse and set form data if it exists
      if (row.phoenix_form_data) {
        try {
          const formData = typeof row.phoenix_form_data === 'string' 
            ? JSON.parse(row.phoenix_form_data) 
            : row.phoenix_form_data;
          
          this.riskAssessmentViewData = formData;
        } catch (error) {
          console.error('Error parsing phoenix_form_data:', error);
          this.riskAssessmentViewData = null;
        }
      } else {
        this.riskAssessmentViewData = null;
      }
      
      // Always show both views when Action is clicked
      this.showRiskAssessmentView = true;
      this.showLeaderReviewFlow = true;
      this.cdr.markForCheck();
    }
  }

  /**
   * Show confirmation dialog for Reject action
   */
  onRejectLeaderStatus(requestId: string, statusType: 'offering' | 'practice'): void {
    this.confirmationData = {
      action: 'reject',
      requestId,
      statusType
    };
    this.showConfirmationDialog = true;
    this.cdr.markForCheck();
  }

  /**
   * Execute the approve action after confirmation
   */
  onConfirmApprove(): void {
    if (!this.confirmationData) return;

    const { requestId, statusType } = this.confirmationData;
    console.log(`Confirmed approving ${statusType} leader status for request: ${requestId}`);
    
    // Get the row from the correct data array (always from leaderTasksData in reviews tab)
    const row = this.leaderTasksData.find((r: any) => r.request_id === requestId);
    
    if (row) {
      // Construct the payload for updateLeaderAction API
      const payload = {
        request_id: requestId,
        user_name: row.user_name || '',
        user_email: row.user_email || '',
        offering_leader_email: row.offering_leader_email || '',
        practice_leader_email: row.practice_leader_email || '',
        who_actioned: statusType === 'offering' ? 'offering_leader' : 'practice_leader',
        status: 'Approved',
        token: this.authService.accessToken || ''
      };

      // Call the API to update leader action
      this.chatService.updateLeaderAction(payload).subscribe({
        next: (response: any) => {
          console.log('Leader action updated successfully:', response);
          
          // Refresh the entire table with fresh data from the API
          this.fetchLeaderTasks();
          
          // Show submission notification with request ID
          this.showSubmissionNotification(requestId);
          
          this.closeConfirmationDialog();
        },
        error: (error: any) => {
          console.error('Error updating leader action:', error);
          // Show error to user - could use a toast notification here
          alert('Failed to update status. Please try again.');
          this.closeConfirmationDialog();
        }
      });
    } else {
      this.closeConfirmationDialog();
    }
  }

  /**
   * Execute the reject action after confirmation
   */
  onConfirmReject(): void {
    if (!this.confirmationData) return;

    const { requestId, statusType } = this.confirmationData;
    console.log(`Confirmed rejecting ${statusType} leader status for request: ${requestId}`);
    
    // Get the row from the correct data array (always from leaderTasksData in reviews tab)
    const row = this.leaderTasksData.find((r: any) => r.request_id === requestId);
    
    if (row) {
      // Construct the payload for updateLeaderAction API
      const payload = {
        request_id: requestId,
        user_name: row.user_name || '',
        user_email: row.user_email || '',
        offering_leader_email: row.offering_leader_email || '',
        practice_leader_email: row.practice_leader_email || '',
        who_actioned: statusType === 'offering' ? 'offering_leader' : 'practice_leader',
        status: 'Rejected',
        token: this.authService.accessToken || ''
      };

      // Call the API to update leader action
      this.chatService.updateLeaderAction(payload).subscribe({
        next: (response: any) => {
          console.log('Leader action updated successfully:', response);
          
          // Refresh the entire table with fresh data from the API
          this.fetchLeaderTasks();
          
          // Show submission notification with request ID
          this.showSubmissionNotification(requestId);
          
          this.closeConfirmationDialog();
        },
        error: (error: any) => {
          console.error('Error updating leader action:', error);
          // Show error to user - could use a toast notification here
          alert('Failed to update status. Please try again.');
          this.closeConfirmationDialog();
        }
      });
    } else {
      this.closeConfirmationDialog();
    }
  }

  /**
   * Close confirmation dialog
   */
  closeConfirmationDialog(): void {
    this.showConfirmationDialog = false;
    this.confirmationData = null;
    this.cdr.markForCheck();
  }

  /**
   * Handle leader review submission from LeaderReviewFlowComponent
   */
  onLeaderReviewSubmitted(reviewData: {
    requestId: string;
    statusType: 'offering' | 'practice';
    action: 'approve' | 'reject';
    reviewData: any;
  }): void {
    const { requestId, statusType, action, reviewData: formData } = reviewData;
    console.log(`Leader review submitted: ${action} for request ${requestId}`, formData);
    
    // Get the row from the data array
    const row = this.leaderTasksData.find((r: any) => r.request_id === requestId);
    
    if (row) {
      // Create form_data JSON object with all leader review form data
      const formDataObject = {
        dueDiligence: formData?.dueDiligence || {},
        additionalRiskReview: formData?.additionalRiskReview || '',
        riskReviewCategories: formData?.riskReviewCategories || {},
        supportPublication: formData?.supportPublication || '',
        supportPublicationRationale: formData?.supportPublicationRationale || '',
        requestMcxEditorialSupport: formData?.requestMcxEditorialSupport || '',
        requestMcxCreativeSupport: formData?.requestMcxCreativeSupport || ''
      };

      // Construct the payload for updateLeaderAction API with form data as JSON string
      const payload = {
        request_id: requestId,
        user_name: row.user_name || '',
        user_email: row.user_email || '',
        offering_leader_email: row.offering_leader_email || '',
        practice_leader_email: row.practice_leader_email || '',
        offering_leader_name: row.offering_leader_name || '',
        practice_leader_name: row.practice_leader_name || '',
        who_actioned: statusType === 'offering' ? 'offering_leader' : 'practice_leader',
        status: action === 'approve' ? 'Approved' : 'Rejected',
        token: this.authService.accessToken || '',
        // Add leader review form data as JSON string
        form_data: JSON.stringify(formDataObject),
        user_form_data: row.user_form_data || '',
        phoenix_form_data: row.phoenix_form_data || '',
        sharepoint_file_link: row.sharepoint_file_link || ''

      };

      // Call the API to update leader action
      this.chatService.updateLeaderAction(payload).subscribe({
        next: (response: any) => {
          console.log('Leader action updated successfully:', response);
          
          // Refresh the entire table with fresh data from the API
          this.fetchLeaderTasks();
          
          // Show submission notification with request ID
          this.showSubmissionNotification(requestId);
          
          this.closeLeaderReviewFlow();
        },
        error: (error: any) => {
          console.error('Error updating leader action:', error);
          // Show error to user - could use a toast notification here
          alert('Failed to update status. Please try again.');
          this.closeLeaderReviewFlow();
        }
      });
    } else {
      this.closeLeaderReviewFlow();
    }
  }

  /**
   * Close leader review flow and risk assessment view if both are open
   */
  closeLeaderReviewFlow(): void {
    this.showLeaderReviewFlow = false;
    this.leaderReviewFlowData = null;
    // Also close risk assessment view to close both modals at once
    this.closeRiskAssessmentView();
    this.cdr.markForCheck();
  }

  /**
   * Open form data popup for a request
   * Displays the phoenix_form_data in a user-friendly format
   */
  openFormDataPopup(requestId: string): void {
    const row = this.leaderTasksData.find((r: any) => r.request_id === requestId);
    
    if (row && row.phoenix_form_data) {
      try {
        // Parse phoenix_form_data if it's a JSON string
        const formData = typeof row.phoenix_form_data === 'string' 
          ? JSON.parse(row.phoenix_form_data) 
          : row.phoenix_form_data;
        
        this.formDataPopupContent = formData;
        this.formDataPopupTitle = `Request Form Data - ${requestId}`;
        this.showFormDataPopup = true;
        this.cdr.markForCheck();
      } catch (error) {
        console.error('Error parsing phoenix_form_data:', error);
        // If parsing fails, display raw data
        this.formDataPopupContent = { rawData: row.phoenix_form_data };
        this.formDataPopupTitle = `Request Form Data - ${requestId}`;
        this.showFormDataPopup = true;
        this.cdr.markForCheck();
      }
    }
  }

  /**
   * Close form data popup
   */
  closeFormDataPopup(): void {
    this.showFormDataPopup = false;
    this.formDataPopupContent = null;
    this.formDataPopupTitle = '';
    this.cdr.markForCheck();
  }

  /**
   * Open risk assessment view for a request
   * Displays the risk assessment questions and answers from phoenix_form_data
   */
  openRiskAssessmentView(requestId: string): void {
    // Search in both myRequestsData and leaderTasksData
    let row = this.leaderTasksData.find((r: any) => r.request_id === requestId);
    if (!row) {
      row = this.myRequestsData.find((r: any) => r.request_id === requestId);
    }
    
    if (row && row.phoenix_form_data) {
      try {
        // Parse phoenix_form_data if it's a JSON string
        const formData = typeof row.phoenix_form_data === 'string' 
          ? JSON.parse(row.phoenix_form_data) 
          : row.phoenix_form_data;
        
        this.riskAssessmentViewData = formData;
        this.riskAssessmentViewRequestId = requestId;
        this.riskAssessmentViewRequestData = row;
        this.showRiskAssessmentView = true;
        this.cdr.markForCheck();
      } catch (error) {
        console.error('Error parsing phoenix_form_data:', error);
        alert('Error opening risk assessment view. Please try again.');
      }
    }
  }

  /**
   * Open phoenix link in a new tab
   */
  openPhoenixLink(phoenixLink: string | null | undefined, phoenixId: string): void {
    if (!phoenixLink) {
      alert(`Phoenix link not available for request: ${phoenixId}`);
      console.warn(`Phoenix link not available for request ID: ${phoenixId}`);
      return;
    }

    // Validate the URL is a proper link
    try {
      new URL(phoenixLink); // This will throw if invalid URL
      window.open(phoenixLink, '_blank', 'noopener,noreferrer');
    } catch (error) {
      console.error('Invalid phoenix link URL:', phoenixLink, error);
      alert('Invalid phoenix link. Please try again.');
    }
  }

  /**
   * Check if both modals are open for side-by-side layout
   */
  isSideBySideLayout(): boolean {
    return this.showRiskAssessmentView && this.showLeaderReviewFlow;
  }

  /**
   * Close risk assessment view
   */
  closeRiskAssessmentView(): void {
    this.showRiskAssessmentView = false;
    this.riskAssessmentViewData = null;
    this.riskAssessmentViewRequestId = '';
    this.riskAssessmentViewRequestData = null;
    this.riskAssessmentViewTab = 'user';
    this.cdr.markForCheck();
  }

  /**
   * Select risk assessment view tab
   */
  selectRiskAssessmentViewTab(tab: 'user' | 'offering' | 'practice'): void {
    this.riskAssessmentViewTab = tab;
  }

  /**
   * Get field components for User input tab (questions without (Offering Leader) or (Practice Leader))
   */
  getUserInputFields(): any[] {
    return this.getFieldComponents().filter((field: any) => {
      const fieldNameLower = (field.name || '').toLowerCase();
      return !fieldNameLower.includes('(offering leader)') && !fieldNameLower.includes('(practice leader)');
    });
  }

  /**
   * Get field components for Offering leader input tab (questions with (Offering Leader))
   */
  getOfferingLeaderFields(): any[] {
    return this.getFieldComponents().filter((field: any) => 
      (field.name || '').toLowerCase().includes('(offering leader)')
    );
  }

  /**
   * Get field components for Practice leader input tab (questions with (Practice Leader))
   */
  getPracticeLeaderFields(): any[] {
    return this.getFieldComponents().filter((field: any) => 
      (field.name || '').toLowerCase().includes('(practice leader)')
    );
  }

  /**
   * Get the field components (risk assessment questions)
   */
  getFieldComponents(): any[] {
    if (!this.riskAssessmentViewData) return [];
    const fieldComponents = this.riskAssessmentViewData.fieldComponents || [];
    // Set all fields as required
    return fieldComponents.map((field: any) => ({
      ...field,
      required: true
    }));
  }

  /**
   * Get integration components (people pickers)
   */
  getIntegrationComponents(): any[] {
    if (!this.riskAssessmentViewData) return [];
    const integrationComponents = this.riskAssessmentViewData.integrationComponents || [];
    // Set all components as required
    return integrationComponents.map((component: any) => ({
      ...component,
      required: true
    }));
  }

  /**
   * Get display value for a field
   */
  getDisplayValue(field: any): string {
    if (!field.value) return '—';
    
    // Handle array values (checkboxes, checklists)
    if (Array.isArray(field.value)) {
      return field.value.length > 0 ? field.value.join(', ') : '—';
    }
    
    // Handle string/radio values
    return String(field.value);
  }

  /**
   * Get email from integration component
   */
  getIntegrationEmail(component: any): string {
    if (!component.subFields) return '—';
    const emailField = component.subFields.find((sf: any) => sf.name === 'Email');
    return emailField?.value || '—';
  }

  /**
   * Get name from integration component
   */
  getIntegrationName(component: any): string {
    if (!component.subFields) return '—';
    const nameField = component.subFields.find((sf: any) => sf.name === 'Name');
    return nameField?.value || '—';
  }

  /**
   * Get files from form data
   */
  getFormDataFiles(): any[] {
    if (!this.riskAssessmentViewData) return [];
    
    // Check for files in direct files property
    if (this.riskAssessmentViewData.files && Array.isArray(this.riskAssessmentViewData.files)) {
      return this.riskAssessmentViewData.files;
    }
    
    // Check for files in fieldComponents with file upload type
    const fileFields = this.getFieldComponents().filter(
      (field: any) => field.fieldType === 'File Upload' && field.value
    );
    
    // Flatten file arrays from file upload fields
    const filesFromFields: any[] = [];
    fileFields.forEach((field: any) => {
      if (Array.isArray(field.value)) {
        filesFromFields.push(...field.value);
      } else {
        filesFromFields.push(field.value);
      }
    });
    
    return filesFromFields.length > 0 ? filesFromFields : [];
  }

  /**
   * Format file size to human-readable format for modal display
   */
  formatFileSize(bytes: number): string {
    if (!bytes || bytes === 0) return '0 B';
    
    const sizeInMB = bytes / (1024 * 1024);
    if (sizeInMB >= 1) {
      return `${sizeInMB.toFixed(2)} MB`;
    }

    const sizeInKB = bytes / 1024;
    if (sizeInKB >= 1) {
      return `${sizeInKB.toFixed(2)} KB`;
    }

    return `${bytes} B`;
  }

  /**
   * Download file from risk assessment modal
   */
  onDownloadFileFromModal(fileId: string, fileName: string): void {
    if (!fileId || !fileName) return;
    this.onDownloadFile(fileId, fileName);
  }

  /**
   * Open SharePoint link in a new tab
   */
  openSharePointLink(url: string): void {
    if (url) {
      window.open(url, '_blank');
    }
  }

  /**
   * Extract requestor from user_form_data JSON
   * Looks for the 'requestor' field in user_form_data
   * Used only in Review Requests tab for the "requestor" column
   */
  extractRequesterName(userFormData: any): string {
    if (!userFormData) {
      return '';
    }

    try {
      // Parse if it's a JSON string
      const formData = typeof userFormData === 'string' 
        ? JSON.parse(userFormData) 
        : userFormData;

      // Look for requestor field
      if (formData.requestor) {
        return formData.requestor;
      }

      // Fallback to other common field names
      const fieldNames = ['applicant_name', 'requester_name', 'full_name', 'name', 'Applicant Name', 'Applicant name'];
      for (const fieldName of fieldNames) {
        if (formData[fieldName]) {
          return formData[fieldName];
        }
      }

      return '';
    } catch (error) {
      console.error('Error extracting requestor:', error);
      return '';
    }
  }

  /**
   * Get display label for form data fields
   * Converts snake_case or camelCase to Title Case
   */
  getFieldLabel(fieldName: unknown): string {
    const name = String(fieldName || '');
    return name
      .replace(/([A-Z])/g, ' $1') // Add space before capitals
      .replace(/_/g, ' ') // Replace underscores with spaces
      .replace(/^./, str => str.toUpperCase()) // Capitalize first letter
      .trim();
  }

  /**
   * Download file for a request
   * Uses the downloadFile API from ChatService
   * Opens browser's Save As dialog to select download location
   * Does not refresh the table
   */
  onDownloadFile(requestId: string, fileName: string): void {
    // Add to downloading set (disable button without refreshing table)
    this.downloadingRequestIds.add(requestId);

    this.chatService.downloadFile(requestId).subscribe({
      next: (blob: Blob) => {
        // Try to use File System Access API for "Save As" dialog (modern browsers)
        if ('showSaveFilePicker' in window) {
          this.downloadFileWithFileSystemAccess(blob, fileName, requestId);
        } else {
          // Fallback to traditional download for older browsers
          this.downloadFileTraditional(blob, fileName, requestId);
        }
      },
      error: (err) => {
        console.error('Download error:', err);
        // Remove from downloading set even on error
        this.downloadingRequestIds.delete(requestId);
      }
    });
  }

  /**
   * Download file using File System Access API (shows Save As dialog)
   * Works in modern browsers (Chrome, Edge, etc.)
   */
  private async downloadFileWithFileSystemAccess(blob: Blob, fileName: string, requestId: string): Promise<void> {
    try {
      // Get file extension from fileName
      const fileExtension = fileName.split('.').pop() || '';
      
      // Show Save As dialog
      const fileHandle = await (window as any).showSaveFilePicker({
        suggestedName: fileName,
        types: [
          {
            description: 'All Files',
            accept: { '*/*': [`.${fileExtension}`] }
          }
        ]
      });

      // Create writable stream and write blob to file
      const writable = await fileHandle.createWritable();
      await writable.write(blob);
      await writable.close();

      // Remove from downloading set after successful save
      this.downloadingRequestIds.delete(requestId);
    } catch (err: any) {
      // User cancelled the dialog or error occurred
      if (err.name !== 'AbortError') {
        console.error('File save error:', err);
      }
      // Remove from downloading set
      this.downloadingRequestIds.delete(requestId);
    }
  }

  /**
   * Fallback download method for older browsers (traditional download)
   * Downloads to default downloads folder
   */
  private downloadFileTraditional(blob: Blob, fileName: string, requestId: string): void {
    try {
      // Create URL from blob
      const url = window.URL.createObjectURL(blob);
      
      // Create temporary link element (no download attribute to potentially trigger save dialog)
      const link = document.createElement('a');
      link.href = url;
      link.download = fileName || `file_${requestId}`;
      
      // Append to body and trigger click
      document.body.appendChild(link);
      link.click();
      
      // Clean up immediately
      document.body.removeChild(link);
      window.URL.revokeObjectURL(url);
    } finally {
      // Remove from downloading set
      this.downloadingRequestIds.delete(requestId);
    }
  }
  
  /**
   * Clear all filters for My Requests
   */
  clearMyRequestsFilters(): void {
    Object.keys(this.myRequestsFilters).forEach(key => {
      this.myRequestsFilters[key] = '';
    });
    this.myRequestsActiveFilterColumns.clear();
    this.selectedMyRequestsColumnToAdd = '';
    this.applyMyRequestsFilter();
  }
  
  /**
   * Clear all filters for Leader Tasks
   */
  clearLeaderTasksFilters(): void {
    Object.keys(this.leaderTasksFilters).forEach(key => {
      this.leaderTasksFilters[key] = '';
    });
    this.leaderTasksActiveFilterColumns.clear();
    this.selectedLeaderTasksColumnToAdd = '';
    this.applyLeaderTasksFilter();
  }

  /**
   * Fetch leader tasks (review requests) from the API and populate the table with specific columns
   */
  private fetchLeaderTasks(): void {
    // Log API call for debugging first-time navigation issues
    console.log('[MyRequestsTableComponent] fetchLeaderTasks called', { leaderTasksDataFetched: this.leaderTasksDataFetched });
    
    this.isLoading = true;
    this.error = '';
    this.cdr.markForCheck();

    const currentUser = this.currentUserService.currentUser;
    const requestedEmail = (currentUser?.email || '').toLowerCase().replace('@dev365.', '@');
    if (!currentUser || !requestedEmail) {
      this.error = 'User email not found. Please log in again.';
      this.isLoading = false;
      this.cdr.markForCheck();
      return;
    }

    // Define which columns to display for Review Requests
    const desiredColumns = ['request_id', 'requestor', 'offering_leader_name', 'offering_leader_status', 'practice_leader_name', 'practice_leader_status', 'request_status', 'phoenix_id', 'created_at'];

    this.chatService.getLeaderTasks(requestedEmail).pipe(
      takeUntil(this.destroy$)
    ).subscribe({
      next: (response: any) => {
        if (response?.success && response?.data && Array.isArray(response.data)) {
          this.leaderTasksData = response.data;
          
          // Set column list first - filter to only desired columns that exist in the response
          // Note: 'requestor' is computed from user_form_data, so skip the existence check for it
          this.leaderTasksColumns = desiredColumns.filter(col => 
            col === 'requestor' || (response.data.length > 0 && col in response.data[0])
          );
          
          console.log('[MyRequestsTableComponent] Final columns to display in review requests:', this.leaderTasksColumns);

          // Transform data to only include desired columns, but preserve file_size, user info, email fields, and request_link for tooltips
          this.leaderTasksData = response.data.map((row: any) => {
            const filteredRow: any = {};
            this.leaderTasksColumns.forEach(col => {
              // Use user_name for requestor column
              if (col === 'requestor') {
                filteredRow[col] = row.user_name;
              } else {
                filteredRow[col] = row[col];
              }
            });
            // Always include these fields for API calls and tooltip display, even if not in columns
            if (row.file_size) {
              filteredRow.file_size = row.file_size;
            }
            if (row.file_name) {
              filteredRow.file_name = row.file_name;
            }
            if (row.user_name) {
              filteredRow.user_name = row.user_name;
            }
            if (row.user_email) {
              filteredRow.user_email = row.user_email;
            }
            if (row.offering_leader_email) {
              filteredRow.offering_leader_email = row.offering_leader_email;
            }
            if (row.practice_leader_email) {
              filteredRow.practice_leader_email = row.practice_leader_email;
            }
            if (row.request_link) {
              filteredRow.request_link = row.request_link;
            }
            if (row.user_form_data) {
              filteredRow.user_form_data = row.user_form_data;
            }
            if (row.phoenix_form_data) {
              filteredRow.phoenix_form_data = row.phoenix_form_data;
            }
            if (row.sharepoint_file_link) {
              filteredRow.sharepoint_file_link = row.sharepoint_file_link;
            }
            if (row.phoenix_link) {
              filteredRow.phoenix_link = row.phoenix_link;
            }
            return filteredRow;
          });
          
          // Sort data by created_at in descending order (most recent first)
          this.leaderTasksData = this.sortDataByCreatedAt(this.leaderTasksData);
          
          // Initialize filters for each column
          this.leaderTasksFilters = {};
          this.leaderTasksColumns.forEach(col => {
            this.leaderTasksFilters[col] = '';
          });
          
          // Apply initial filter
          this.applyLeaderTasksFilter();
        } else {
          this.leaderTasksData = [];
          this.leaderTasksColumns = [];
          this.leaderTasksFilters = {};
          this.filteredLeaderTasksData = [];
        }
        this.leaderTasksDataFetched = true;
        this.isLoading = false;
        this.cdr.markForCheck();
      },
      error: (err) => {
        console.error('Error fetching leader tasks:', err);
        this.error = err?.error?.message || 'Failed to fetch review requests. Please try again.';
        this.leaderTasksData = [];
        this.leaderTasksColumns = [];
        this.leaderTasksDataFetched = true;
        this.isLoading = false;
        this.cdr.markForCheck();
      },
      complete: () => {
        this.leaderTasksDataFetched = true;
      }
    });
  }

  /**
   * Get paginated data for My Requests table
   */
  getPaginatedMyRequestsData(): any[] {
    const startIndex = (this.currentPageMyRequests - 1) * this.itemsPerPage;
    const endIndex = startIndex + this.itemsPerPage;
    return this.filteredMyRequestsData.slice(startIndex, endIndex);
  }

  /**
   * Get paginated data for Leader Tasks (Review Requests) table
   */
  getPaginatedLeaderTasksData(): any[] {
    const startIndex = (this.currentPageLeaderTasks - 1) * this.itemsPerPage;
    const endIndex = startIndex + this.itemsPerPage;
    return this.filteredLeaderTasksData.slice(startIndex, endIndex);
  }

  /**
   * Get total pages for My Requests table
   */
  getTotalPagesMyRequests(): number {
    return Math.ceil(this.filteredMyRequestsData.length / this.itemsPerPage);
  }

  /**
   * Get total pages for Leader Tasks (Review Requests) table
   */
  getTotalPagesLeaderTasks(): number {
    return Math.ceil(this.filteredLeaderTasksData.length / this.itemsPerPage);
  }

  /**
   * Set current page for My Requests table
   */
  /**
   * Set current page for My Requests table
   * Also adjusts pagination offset to keep the page visible
   */
  setCurrentPageMyRequests(page: number | string): void {
    const pageNum = typeof page === 'string' ? parseInt(page, 10) : page;
    const maxPage = this.getTotalPagesMyRequests();
    if (!isNaN(pageNum) && pageNum >= 1 && pageNum <= maxPage) {
      this.currentPageMyRequests = pageNum;
      
      // Adjust offset to ensure the page is visible
      const rangeStart = this.paginationOffsetMyRequests + 1;
      const rangeEnd = rangeStart + this.maxPagesToShow - 1;
      
      if (pageNum < rangeStart) {
        // Page is before the current range, move range backwards
        this.paginationOffsetMyRequests = Math.max(0, pageNum - 1);
      } else if (pageNum > rangeEnd) {
        // Page is after the current range, move range forwards
        this.paginationOffsetMyRequests = Math.max(0, pageNum - this.maxPagesToShow);
      }
      
      this.cdr.markForCheck();
    }
  }

  /**
   * Set current page for Leader Tasks (Review Requests) table
   * Also adjusts pagination offset to keep the page visible
   */
  setCurrentPageLeaderTasks(page: number | string): void {
    const pageNum = typeof page === 'string' ? parseInt(page, 10) : page;
    const maxPage = this.getTotalPagesLeaderTasks();
    if (!isNaN(pageNum) && pageNum >= 1 && pageNum <= maxPage) {
      this.currentPageLeaderTasks = pageNum;
      
      // Adjust offset to ensure the page is visible
      const rangeStart = this.paginationOffsetLeaderTasks + 1;
      const rangeEnd = rangeStart + this.maxPagesToShow - 1;
      
      if (pageNum < rangeStart) {
        // Page is before the current range, move range backwards
        this.paginationOffsetLeaderTasks = Math.max(0, pageNum - 1);
      } else if (pageNum > rangeEnd) {
        // Page is after the current range, move range forwards
        this.paginationOffsetLeaderTasks = Math.max(0, pageNum - this.maxPagesToShow);
      }
      
      this.cdr.markForCheck();
    }
  }

  /**
   * Get array of page numbers for My Requests pagination with max pages limit
   * Shows max 5 pages, with "..." if there are more
   */
  getPageNumbersMyRequests(): (number | string)[] {
    const totalPages = this.getTotalPagesMyRequests();
    const pages: (number | string)[] = [];
    
    // Calculate the range of pages to show based on offset
    const startPage = this.paginationOffsetMyRequests + 1;
    const endPage = Math.min(startPage + this.maxPagesToShow - 1, totalPages);
    
    // Add page numbers
    for (let i = startPage; i <= endPage; i++) {
      pages.push(i);
    }
    
    // Add "..." if there are more pages after the current range
    if (endPage < totalPages) {
      pages.push('...');
    }
    
    return pages;
  }

  /**
   * Get array of page numbers for Leader Tasks pagination with max pages limit
   * Shows max 5 pages, with "..." if there are more
   */
  getPageNumbersLeaderTasks(): (number | string)[] {
    const totalPages = this.getTotalPagesLeaderTasks();
    const pages: (number | string)[] = [];
    
    // Calculate the range of pages to show based on offset
    const startPage = this.paginationOffsetLeaderTasks + 1;
    const endPage = Math.min(startPage + this.maxPagesToShow - 1, totalPages);
    
    // Add page numbers
    for (let i = startPage; i <= endPage; i++) {
      pages.push(i);
    }
    
    // Add "..." if there are more pages after the current range
    if (endPage < totalPages) {
      pages.push('...');
    }
    
    return pages;
  }

  /**
   * Handle click on "..." for My Requests pagination
   * Shows next 1 page and hides the first 1
   */
  showMorePagesMyRequests(): void {
    const totalPages = this.getTotalPagesMyRequests();
    const maxOffset = Math.max(0, totalPages - this.maxPagesToShow);
    
    // Shift offset by 1 page
    this.paginationOffsetMyRequests = Math.min(
      this.paginationOffsetMyRequests + 1,
      maxOffset
    );
    this.cdr.markForCheck();
  }

  /**
   * Handle click on "..." for Leader Tasks pagination
   * Shows next 1 page and hides the first 1
   */
  showMorePagesLeaderTasks(): void {
    const totalPages = this.getTotalPagesLeaderTasks();
    const maxOffset = Math.max(0, totalPages - this.maxPagesToShow);
    
    // Shift offset by 1 page
    this.paginationOffsetLeaderTasks = Math.min(
      this.paginationOffsetLeaderTasks + 1,
      maxOffset
    );
    this.cdr.markForCheck();
  }

  /**
   * Show notification toast at the bottom of the screen
   * Automatically hides after 7 seconds
   * @param requestId The request ID to display in the notification
   */
  showSubmissionNotification(requestId?: string): void {
    const idText = requestId ? ` ${requestId}` : '';
    this.notificationMessage = `Response is submitted, Please check the status of the request ID:${idText}`;
    this.showNotification = true;
    this.cdr.markForCheck();

    // Auto-hide notification after 7 seconds
    if (this.notificationTimeout) {
      clearTimeout(this.notificationTimeout);
    }
    this.notificationTimeout = setTimeout(() => {
      this.hideNotification();
    }, 7000);
  }

  /**
   * Hide notification toast
   */
  hideNotification(): void {
    this.showNotification = false;
    this.notificationMessage = '';
    if (this.notificationTimeout) {
      clearTimeout(this.notificationTimeout);
      this.notificationTimeout = null;
    }
    this.cdr.markForCheck();
  }

  /**
   * Check if the current user can take action on a leader status
   * Only shows action button if user email matches the leader email
   * @param row The request row
   * @param statusType The type of status ('offering' or 'practice')
   * @returns true if user can take action, false otherwise
   */
  canUserTakeAction(row: any, statusType: 'offering' | 'practice'): boolean {
    const currentUser = this.currentUserService.currentUser;
    const currentUserEmail = (currentUser?.email || '').toLowerCase().replace('@dev365.', '@');
    
    if (!currentUserEmail || !row) {
      return false;
    }

    if (statusType === 'offering') {
      const offeringLeaderEmail = (row.offering_leader_email || '').toLowerCase().replace('@dev365.', '@');
      return currentUserEmail === offeringLeaderEmail;
    } else if (statusType === 'practice') {
      const practiceLeaderEmail = (row.practice_leader_email || '').toLowerCase().replace('@dev365.', '@');
      return currentUserEmail === practiceLeaderEmail;
    }

    return false;
  }
}
