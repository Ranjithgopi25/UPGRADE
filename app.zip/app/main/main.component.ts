import { AfterViewInit, Component, ElementRef, OnInit, signal, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { NavigationItem } from '@appkit4/angular-components/navigation';
import { OauthAdapterService } from '../auth/oauth-adapter.service';
import { NavLink } from './nav-link.model';
import { environment } from '../../environments/environment';

@Component({
    selector: 'app-root',
    templateUrl: './main.component.html',
    styleUrls: ['./main.component.scss'],
    standalone: false
})
export class MainComponent implements OnInit, AfterViewInit {
  useAuth = environment.useAuth;
  apiReferenceBlock: boolean = false;
  currentYear: number = new Date().getFullYear();
  footerContent: string = ` © ${this.currentYear} PwC. All rights reserved. PwC refers to the PwC network and/or one or more of its member firms, each of which is a separate legal entity. Please see <a class='ap-link' href='https://www.pwc.com/structure'>www.pwc.com/structure</a> for further details.`;
  footerType: string = 'text';
  indeterminate = true;
  compact = true;
  showDropdown: boolean = false;
  showSettingsDropdown: boolean = false;
  showAvatarDropdown: boolean = false;
  profileName: any;
  status: string = 'Login';
  items = [
    { value: 'item1', label: 'Default' },
    { value: 'item2', label: 'List Item 1' },
    { value: 'item3', label: 'List Item 2' },
  ];

  settingItems = [{ value: 'item1', label: 'App setting' }];

  avatarList = [{ value: 'item1', label: 'Welcome to QuickSuite' }];

  autoCloseForDropdown() {
    if (
      this.showDropdown ||
      this.showSettingsDropdown ||
      this.showAvatarDropdown
    ) {
      this.showAvatarDropdown = false;
      this.showSettingsDropdown = false;
      this.showDropdown = false;
    }
  }

  onClick() {
    this.router.navigate(['']);
  }
  navLinks: Array<NavLink> = [
    {
      name: 'Dashboard',
      type: 'link',
      route: 'dashboard',
    },
    {
      name: 'People',
      type: 'link',
      route: 'people',
    },
  ];

  userData!: Record<string, any>;

  constructor(
    private authService: OauthAdapterService,
    private router: Router
  ) { }

  ngOnInit(): void {
    this.userData = this.authService.getIdentityClaims();

    if (this.userData) {
      const userId = this.userData['uid'] || this.userData['pwcguid'] || '';
      
      this.profileName = userId.substring(0, 2).toUpperCase();
      this.status = 'Logout';
    }

    this.avatarList.push({ value: 'item2', label: this.status });
    if (this.useAuth) {
      this.navLinks.push({
        name: 'Profile',
        type: 'link',
        route: 'profile'
      });
    }
  }

  ngAfterViewInit(): void {
    console.info('Main component initialized');
  }

  onSelectDropdown(event: any) {
    this.showDropdown = false;
  }

  onSelectSettingsDropdown(event: any) {
    this.showSettingsDropdown = false;
  }

  onSelectAvatarDropdown(event: any) {
    if (event.selected.label == 'Logout') {
      this.authService.logout().subscribe();
    }
    if (event.selected.label == 'Login') {
      this.router.navigate(['/']);
    }
    this.showAvatarDropdown = false;
  }
}
