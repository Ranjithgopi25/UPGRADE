export interface NavLink {
    name? : string,
    type? : string,
    route? : string
}