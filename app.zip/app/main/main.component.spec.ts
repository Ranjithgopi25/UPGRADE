import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { TestBed } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { OAuthModule } from 'angular-oauth2-oidc';
import { Observable, of } from 'rxjs';
import { OauthAdapterService } from '../auth/oauth-adapter.service';
import { MainComponent } from './main.component';

let mockService: Partial<OauthAdapterService> = {
  getIdentityClaims(): Observable<any> {
    return of({ name: 'testuser', email: 'testuser@testmail.com' });
  },
};
describe('LayoutComponent', () => {
  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [RouterTestingModule, OAuthModule.forRoot()],
      declarations: [MainComponent],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
      providers: [
        { provide: OauthAdapterService, useValue: mockService }],
    }).compileComponents();
  });

  it('should create the app', () => {
    const fixture = TestBed.createComponent(MainComponent);
    const app = fixture.componentInstance;
    expect(app).toBeTruthy();
  });
});
