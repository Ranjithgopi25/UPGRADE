import { Component, Output, EventEmitter, HostListener, Input, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ChatService } from '../../../core/services/chat.service';
import { TlChatBridgeService } from '../../../core/services/tl-chat-bridge.service';
import { AuthService } from '../../../auth/auth.service';
import { firstValueFrom } from 'rxjs';
import { CurrentUserService } from '../../../core/services/current-user.service';
import { ThoughtLeadershipMetadata } from '../../../core/models';

@Component({
  selector: 'app-risk-assessment-flow',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './risk-assessment-flow.component.html',
  styleUrls: ['./risk-assessment-flow.component.scss']
})
export class RiskAssessmentFlowComponent {
  @Input() uploadedFile: File | null = null;
  @Output() close = new EventEmitter<void>();
  @Output() ticketCreated = new EventEmitter<{ requestNumber: string; phoenixRdpLink: string }>();
  
  // Offering and Practice Lead fields
  offeringLead: string = '';
  practiceLead: string = '';
  offeringLeadSearchInput: string = '';
  practiceLeadSearchInput: string = '';
  offeringLeadEmail: string = '';
  practiceLeadEmail: string = '';
  offeringLeadSelected: boolean = false; // Track if selection was made from dropdown
  practiceLeadSelected: boolean = false; // Track if selection was made from dropdown
  filteredOfferingLeads: Array<{ id: string, name: string, formattedName?: string, cloudEmailAddress?: string }> = [];
  filteredPracticeLeads: Array<{ id: string, name: string, formattedName?: string, cloudEmailAddress?: string }> = [];
  offeringLeadDropdownOpen: boolean = false;
  practiceLeadDropdownOpen: boolean = false;
  offeringLeadLoading: boolean = false;
  practiceLeadLoading: boolean = false;
  templateJson_old: any = {
  "source": "69244907b6aaf264b9629e14",
  "requestor": "",
  "engagementId": "5b48ba0a7eba1e1bac2883ff",
  "engagementName": "Non-Client/IFS/US",
  "requestName": "",
  "configId": "69bd33b98cd4c8c234df1df1",
  "configName": "Thought Leadership - Article Ideation and Leader Review",
  "requestTeamMembers": {
    "roleOptions": [
      "Engagement Team Primary",
      "Engagement Team Member",
      "Engagement Partner",
      "Engagement Manager",
      "Engagement Director"
    ],
    "teamMembers": [
      {
        "guidOrEmail": "",
        "role": ""
      }
    ]
  },
  "integrationComponents": [
    {
      "name": "Who is your Offering leader?",
      "type": "People Picker (Type Ahead)",
      "value": "Who is your Offering leader?",
      "required": true,
      "subFields": [
        {
          "name": "Name",
          "required": false,
          "value": ""
        },
        {
          "name": "Email",
          "required": true,
          "value": ""
        },
        {
          "name": "GUID",
          "required": false,
          "value": ""
        }
      ]
    },
    {
      "name": "Who is your Practice leader?",
      "type": "People Picker (Type Ahead)",
      "value": "Who is your Practice leader?",
      "required": true,
      "subFields": [
        {
          "name": "Name",
          "required": false,
          "value": ""
        },
        {
          "name": "Email",
          "required": true,
          "value": ""
        },
        {
          "name": "GUID",
          "required": false,
          "value": ""
        }
      ]
    }
  ],
  "fieldComponents": [
    {
      "name": "Have you completed the following due diligence?",
      "fieldType": "Check list",
      "required": true,
      "value": [],
      "options": [
        "Fully reviewed the entire piece",
        "Stand behind all arguments / perspectives",
        "Reviewed and verified all sources",
        "Cited all relavent data and information"
      ]
    },
    {
      "name": "Does this content cover any of the following high-risk topics? (Checking these boxes will trigger additional risk reviews)",
      "fieldType": "Check box",
      "required": false,
      "value": [],
      "options": [
        "AI",
        "Policies (America in Motion)",
        "US and other territory regulatory environments",
        "References to third parties* including product names, brands, or logos",
        "PwC built or third-party technology",
        "None of the above"
      ]
    },
    {
      "name": "Could this content, in the public setting, create risk for PwC?",
      "fieldType": "Radio Buttons",
      "required": true,
      "value": "",
      "options": [
        "Yes",
        "No",
        "Request consultation"
      ]
    },
    {
      "name": "Where do you intend to publish this content?",
      "fieldType": "Text area(5000)",
      "required": true,
      "value": ""
    },
    {
      "name": "Please attest",
      "fieldType": "Check box",
      "required": true,
      "value": [],
      "options": [
        "I hereby certify the provided information is accurate. I understand that failure to comply with risk review guidlines may result in disciplinary action."
      ]
    }
  ],
  "activities": [
    {
      "activityName": "Offering leader review",
      "selected": "Yes",
      "options": [
        "Yes",
        "No"
      ],
      "fieldComponents": []
    },
    {
      "activityName": "Practice leader review",
      "selected": "Yes",
      "options": [
        "Yes",
        "No"
      ],
      "fieldComponents": []
    },
    {
      "activityName": "Editor",
      "selected": "Yes",
      "options": [
        "Yes",
        "No"
      ],
      "fieldComponents": []
    },
    {
      "activityName": "Research",
      "selected": "Yes",
      "options": [
        "Yes",
        "No"
      ],
      "fieldComponents": []
    },
    {
      "activityName": "Network of Experts",
      "selected": "Yes",
      "options": [
        "Yes",
        "No"
      ],
      "fieldComponents": []
    },
    {
      "activityName": "Partner In Charge",
      "selected": "Yes",
      "options": [
        "Yes",
        "No"
      ],
      "fieldComponents": []
    },
    {
      "activityName": "MCX Approver",
      "selected": "Yes",
      "options": [
        "Yes",
        "No"
      ],
      "fieldComponents": []
    },
    {
      "activityName": "R&I / OGC",
      "selected": "Yes",
      "options": [
        "Yes",
        "No"
      ],
      "fieldComponents": []
    }
  ]
};

  templateJson: any = {
  "source": "69244907b6aaf264b9629e14",
  "requestor": "",
  "engagementId": "5b48ba0a7eba1e1bac2883ff",
  "engagementName": "Non-Client/IFS/US",
  "requestName": "",
  "configId": "69c37fe2d3fa4c849f17837d",
  "configName": "Thought Leadership - Article Ideation and Leader Review",
  "requestTeamMembers": {
    "roleOptions": [
      "Engagement Team Primary",
      "Engagement Team Member",
      "Engagement Partner",
      "Engagement Manager",
      "Engagement Director"
    ],
    "teamMembers": [
      {
        "guidOrEmail": "",
        "role": ""
      }
    ]
  },
  "integrationComponents": [
    {
      "name": "Who is your Offering leader?",
      "type": "People Picker (Type Ahead)",
      "value": "Who is your Offering leader?",
      "required": true,
      "subFields": [
        {
          "name": "Name",
          "required": false,
          "value": ""
        },
        {
          "name": "Email",
          "required": true,
          "value": ""
        },
        {
          "name": "GUID",
          "required": false,
          "value": ""
        }
      ]
    },
    {
      "name": "Who is your Practice leader?",
      "type": "People Picker (Type Ahead)",
      "value": "Who is your Practice leader?",
      "required": true,
      "subFields": [
        {
          "name": "Name",
          "required": false,
          "value": ""
        },
        {
          "name": "Email",
          "required": true,
          "value": ""
        },
        {
          "name": "GUID",
          "required": false,
          "value": ""
        }
      ]
    }
  ],
  "fieldComponents": [
    {
      "name": "Have you completed the following due diligence?",
      "fieldType": "Check list",
      "required": true,
      "value": [],
      "options": [
        "Fully reviewed the entire piece",
        "Stand behind all arguments / perspectives",
        "Reviewed and verified all sources",
        "Cited all relavent data and information"
      ]
    },
    {
      "name": "Does this content cover any of the following high-risk topics? (Checking these boxes will trigger additional risk reviews)",
      "fieldType": "Check box",
      "required": false,
      "value": [],
      "options": [
        "AI",
        "Policies (America in Motion)",
        "US and other territory regulatory environments",
        "References to third parties* including product names, brands, or logos",
        "PwC built or third-party technology",
        "None of the above"
      ]
    },
    {
      "name": "Could this content, in the public setting, create risk for PwC?",
      "fieldType": "Radio Buttons",
      "required": true,
      "value": "",
      "options": [
        "Yes",
        "No",
        "Request consultation"
      ]
    },
    {
      "name": "Where do you intend to publish this content?",
      "fieldType": "Text area(5000)",
      "required": true,
      "value": ""
    },
    {
      "name": "Please attest",
      "fieldType": "Check box",
      "required": true,
      "value": [],
      "options": [
        "I hereby certify the provided information is accurate. I understand that failure to comply with risk review guidlines may result in disciplinary action."
      ]
    },
    {
      "name": "Have you completed the following due diligence? (Offering Leader)",
      "fieldType": "Check box",
      "required": true,
      "value": [],
      "options": [
        "Fully reviewed the content and Self-services risk assessment checklist",
        "Agree with the Self-Service Risk Assessment checklist"
      ]
    },
    {
      "name": "Does this content require additional risk review per the risk review guidelines? (Offering Leader)",
      "fieldType": "Radio Buttons",
      "required": true,
      "value": "",
      "options": [
        "Yes",
        "No"
      ]
    },
    {
      "name": "Do you support publication – content is high quality, presents a new perspective, aligns with Practice / Offering goals, and meets PwC publication standards? (Offering Leader)",
      "fieldType": "Radio Buttons",
      "required": true,
      "value": "",
      "options": [
        "Yes",
        "Not at this time"
      ]
    },
    {
      "name": "Do you want to request MCX editorial support? (Offering Leader) MCX leadership will review requests; not all requests will be approved due to limited availability",
      "fieldType": "Radio Buttons",
      "required": true,
      "value": "",
      "options": [
        "Yes",
        "No"
      ]
    },
    {
      "name": "Do you want to request MCX creative support? (Offering Leader) MCX leadership will review requests; not all requests will be approved due to limited availability",
      "fieldType": "Radio Buttons",
      "required": true,
      "value": "",
      "options": [
        "Yes",
        "No"
      ]
    },
    {
      "name": "Have you completed the following due diligence? (Practice Leader)",
      "fieldType": "Check box",
      "required": true,
      "value": [],
      "options": [
        "Fully reviewed the content and Self-services risk assessment checklist",
        "Agree with the Self-Service Risk Assessment checklist"
      ]
    },
    {
      "name": "Does this content require additional risk review per the risk review guidelines? (Practice Leader)",
      "fieldType": "Radio Buttons",
      "required": true,
      "value": "",
      "options": [
        "Yes",
        "No"
      ]
    },
    {
      "name": "Do you support publication – content is high quality, presents a new perspective, aligns with Practice / Offering goals, and meets PwC publication standards? (Practice Leader)",
      "fieldType": "Radio Buttons",
      "required": true,
      "value": "",
      "options": [
        "Yes",
        "Not at this time"
      ]
    },
    {
      "name": "Do you want to request MCX editorial support? (Practice Leader) MCX leadership will review requests; not all requests will be approved due to limited availability",
      "fieldType": "Radio Buttons",
      "required": true,
      "value": "",
      "options": [
        "Yes",
        "No"
      ]
    },
    {
      "name": "Do you want to request MCX creative support? (Practice Leader) MCX leadership will review requests; not all requests will be approved due to limited availability",
      "fieldType": "Radio Buttons",
      "required": true,
      "value": "",
      "options": [
        "Yes",
        "No"
      ]
    }
  ],
  "activities": [
    {
      "activityName": "Offering leader review",
      "selected": "Yes",
      "options": [
        "Yes",
        "No"
      ],
      "fieldComponents": []
    },
    {
      "activityName": "Practice leader review",
      "selected": "Yes",
      "options": [
        "Yes",
        "No"
      ],
      "fieldComponents": []
    },
    {
      "activityName": "Editor",
      "selected": "Yes",
      "options": [
        "Yes",
        "No"
      ],
      "fieldComponents": []
    },
    {
      "activityName": "Research",
      "selected": "Yes",
      "options": [
        "Yes",
        "No"
      ],
      "fieldComponents": []
    },
    {
      "activityName": "Network of Experts",
      "selected": "Yes",
      "options": [
        "Yes",
        "No"
      ],
      "fieldComponents": []
    },
    {
      "activityName": "Partner In Charge",
      "selected": "Yes",
      "options": [
        "Yes",
        "No"
      ],
      "fieldComponents": []
    },
    {
      "activityName": "MCX Approver",
      "selected": "Yes",
      "options": [
        "Yes",
        "No"
      ],
      "fieldComponents": []
    },
    {
      "activityName": "R&I / OGC",
      "selected": "Yes",
      "options": [
        "Yes",
        "No"
      ],
      "fieldComponents": []
    }
  ]
};
  isGenerating: boolean = false;
  submitErrorMessage: string | null = null;
  ticket_number: string = '';

  private offeringLeadDebounceTimer: any = null;
  private practiceLeadDebounceTimer: any = null;
  
  // Section 1: Due Diligence Checklist
  dueDiligence = {
    fullyReviewed: false,
    standBehindArguments: false,
    reviewedSources: false,
    citedAllData: false
  };

  // Section 2: High-Risk Topics
  highRiskTopics = {
    ai: false,
    policies: false,
    regulations: false,
    independenceConsiderations: false,
    pwcBuiltTechnology: false,
    noneOfAbove: false
  };

  // Section 3: Public Risk
  publicRisk: string = '';

  // Section 3.5: Publishing Destination
  publishingDestination: string = '';

  // Section 4: Certification
  certifyAccuracy: boolean = false;
    // Section 5: Additional Risk Review Type (Dropdown)
  additionalRiskReviewType: string = '';

  constructor(private chatService: ChatService, private tlChatBridge: TlChatBridgeService, private authService: AuthService) {}

  onClose(): void {
    console.log('Closing risk assessment form');
    this.close.emit();
  }

  // Build payload from all form inputs
  buildRiskAssessmentPayload(): any {
    const payload = {
      offeringLead: {
        id: this.offeringLead,
        name: this.offeringLeadSearchInput,
        email: this.offeringLeadEmail
      },
      practiceLead: {
        id: this.practiceLead,
        name: this.practiceLeadSearchInput,
        email: this.practiceLeadEmail
      },
      dueDiligence: {
        fullyReviewed: this.dueDiligence.fullyReviewed,
        standBehindArguments: this.dueDiligence.standBehindArguments,
        reviewedSources: this.dueDiligence.reviewedSources,
        citedAllData: this.dueDiligence.citedAllData,
      },
      highRiskTopics: {
        ai: this.highRiskTopics.ai,
        policies: this.highRiskTopics.policies,
        regulations: this.highRiskTopics.regulations,
        independenceConsiderations: this.highRiskTopics.independenceConsiderations,
        pwcBuiltTechnology: this.highRiskTopics.pwcBuiltTechnology,
        noneOfAbove: this.highRiskTopics.noneOfAbove,
      },
      publicRisk: this.publicRisk,
      publishingDestination: this.publishingDestination,
    };
    return payload;
  }
  private currentUserService = inject(CurrentUserService);

  mapPayloadToRequest(templateJson: any, payload: any, user:any ): any {
  // Deep clone so we don't mutate original template
  const request = JSON.parse(JSON.stringify(templateJson));
  

  request.requestor = (user?.email || '').toLowerCase().replace('@dev365.', '@');


  const offeringLeader = request.integrationComponents.find(
    (c: any) => c.name === "Who is your Offering leader?"
  );

  if (offeringLeader) {
  //offeringLeader.subFields.find((f: any) => f.name === "Name")!.value =payload.offeringLead?.name || "";

    offeringLeader.subFields.find((f: any) => f.name === "Email")!.value =
      payload.offeringLead?.email || "";

    offeringLeader.subFields.find((f: any) => f.name === "GUID")!.value =
      payload.offeringLead?.id || "";
  }

  const practiceLeader = request.integrationComponents.find(
    (c: any) => c.name === "Who is your Practice leader?"
  );

  if (practiceLeader) {
    //practiceLeader.subFields.find((f: any) => f.name === "Name")!.value =payload.practiceLead?.name || "";

    practiceLeader.subFields.find((f: any) => f.name === "Email")!.value =
      payload.practiceLead?.email || "";

    practiceLeader.subFields.find((f: any) => f.name === "GUID")!.value =
      payload.practiceLead?.id || "";
  }

  const dueDiligenceField = request.fieldComponents.find(
    (f: any) =>
      f.name === "Have you completed the following due diligence?"
  );

  if (dueDiligenceField) {
    const selected: string[] = [];

    if (payload.dueDiligence?.fullyReviewed)
      selected.push("Fully reviewed the entire piece");

    if (payload.dueDiligence?.standBehindArguments)
      selected.push("Stand behind all arguments / perspectives");

    if (payload.dueDiligence?.reviewedSources)
      selected.push("Reviewed and verified all sources");

    if (payload.dueDiligence?.citedAllData)
      selected.push("Cited all relavent data and information");

    dueDiligenceField.value = selected;
  }

  const highRiskField = request.fieldComponents.find(
    (f: any) =>
      f.name.includes("high-risk topics")
  );

  if (highRiskField) {
    const selected: string[] = [];

    if (payload.highRiskTopics?.ai) selected.push("AI");
    if (payload.highRiskTopics?.policies)
      selected.push("Policies (America in Motion)");
    if (payload.highRiskTopics?.regulations) selected.push("US and other territory regulatory environments");
    if (payload.highRiskTopics?.independenceConsiderations)
      selected.push("References to third parties* including product names, brands, or logos");
    if (payload.highRiskTopics?.pwcBuiltTechnology)
      selected.push("PwC built or third-party technology");
    if (payload.highRiskTopics?.noneOfAbove)
      selected.push("None of the above");

    highRiskField.value = selected;
  }

  const publicRiskField = request.fieldComponents.find(
    (f: any) =>
      f.name ===
      "Could this content, in the public setting, create risk for PwC?"
  );

  if (publicRiskField) {
    publicRiskField.value = payload.publicRisk || "";
  }

  // Map publishing destination
  const publishingDestinationField = request.fieldComponents.find(
    (f: any) =>
      f.name ===
      "Where do you intend to publish this content?"
  );

  if (publishingDestinationField) {
    publishingDestinationField.value = payload.publishingDestination || "";
  }

  //
  const pleaseAttest = request.fieldComponents.find(
    (f: any) =>
      f.name ===
      "Please attest"
  );  

  if (pleaseAttest) {
    const selected: string[] = ["I hereby certify the provided information is accurate. I understand that failure to comply with risk review guidlines may result in disciplinary action."];
    pleaseAttest.value = selected;
  }

  return request;
}

generateTicketNumber() {

  const timestamp = Date.now(); // milliseconds since epoch
  const last8Digits = String(timestamp).slice(-8); // get last 8 digits of timestamp

  return `TS${last8Digits}`;

}

async getConfigDetails(): Promise<void> {
    try{
    const config = await firstValueFrom(
      this.chatService.getPhoenixRequestConfigRisk()
    );
    this.templateJson = config;
  }catch (error: any) {
      console.error('[RiskAssessment] Error fetching DDC config');
    }
}

  async submitRiskReview(): Promise<void> {
    // Validate form before submitting
    if (this.isSubmitButtonDisabled()) {
      console.error('[RiskAssessment] Form is not valid, cannot submit');
      return;
    }

    // Get and store access token
    await this.authService.getAccessToken();

    const user = await firstValueFrom(this.currentUserService.user$);
    var user_email = (user?.email || '').toLowerCase().replace('@dev365.', '@');
    var user_name = (user?.name || 'Unknown User').replace(/\s*\([^)]+\)$/, "");
    await this.getConfigDetails();

    // Build the complete payload from form inputs
    const payload = await this.buildRiskAssessmentPayload();
    //console.log("payload://///////////",payload)
    //---fill the JSON
    const updatedRequest = this.mapPayloadToRequest(this.templateJson, payload, user);
        
    //--------------------------------
    //console.log('[RiskAssessment] Building risk assessment payload:', JSON.stringify(payload, null, 2));
    //console.log('[RiskAssessment] Submitting risk review');
    
    // Not creating phoenix ticket 

  //   const formData = new FormData();
  //  formData.append('request', JSON.stringify(updatedRequest));
  //  // Add file to FormData if available
  //  if (this.uploadedFile) {
  //    formData.append('files', this.uploadedFile);
  //  }
    
    this.isGenerating = true;
    // const response: any = await firstValueFrom(this.chatService.createPhoenixRequest(formData));
    
    // if (response.requestId === "0"){ 
    //   this.isGenerating = false;
    //   this.submitErrorMessage = response.errorMessage || 'Unable to submit request. Request creation failed with the error: '+ response.errorMessage;
    //   return;
    // } else {
    //   console.log('[RiskAssessment] API response received');

      try {        
        // this.validateAndEscapeUrl(response.phoenixRdpLink);
        // const escapedRequestNumber = this.escapeHtmlSpecialChars(response.requestNumber);
        // const escapedLink = this.escapeHtmlAttribute(response.phoenixRdpLink);

        //generate request number
        this.ticket_number = this.generateTicketNumber()

        // Sending details to chat
        //const translatedContent = `Request created successfully! Your request number is: <a href="${escapedLink}" target="_blank" rel="noopener noreferrer">${escapedRequestNumber}</a>`.trim();
        const translatedContent = `Request created successfully! Your request number is: ${this.ticket_number}`.trim();

        // Create metadata for the message
        const metadata: ThoughtLeadershipMetadata = {
          contentType: 'Phoenix_Request',
          topic: `Phoenix Request - ${this.ticket_number}`, //`Phoenix Request - ${response.requestNumber}`
          fullContent: translatedContent,
          showActions: false
        };
        
        // create audit log for request to publish

        const formData = new FormData();
        formData.append("user_name", user_name||'Unknown User');
        formData.append("user_email", user_email|| '');
        formData.append("content_category", "Public sources");
        formData.append("verification_status", "Confirmed");
        
        formData.append("comments", "");
        formData.append("request_id", this.ticket_number);
        formData.append("request_link", "");

        //formData.append("comments", "Phoenix request created with number: "+response.requestNumber);
        // formData.append("request_id", response.requestNumber);
        // formData.append("request_link", response.phoenixRdpLink);       
        //---------------
        formData.append("user_form_data",JSON.stringify(updatedRequest)); //sending only payload

        formData.append("offering_leader_name",this.offeringLeadSearchInput);
        formData.append("offering_leader_email",this.offeringLeadEmail);
        //formData.append("offering_leader_form_data",);
        formData.append("offering_leader_status","Pending");
        //formData.append("offering_leader_action_at",);

        formData.append("practice_leader_name",this.practiceLeadSearchInput);
        formData.append("practice_leader_email",this.practiceLeadEmail);
        //formData.append("practice_leader_form_data",);
        formData.append("practice_leader_status","");
        //formData.append("practice_leader_action_at",);

        formData.append("request_status","Pending");
        formData.append("token" ,this.authService.accessToken || '');

        formData.append("phoenix_form_data",JSON.stringify(updatedRequest));

        //---------------

        formData.append("file", this.uploadedFile || new Blob());

        // const obj: Record<string, FormDataEntryValue> = {};

        //   formData.forEach((value, key) => {
        //     obj[key] = value;
        //   });

        //   console.log(obj);

        const response_audit: any = await firstValueFrom(
          this.chatService.createRequestToPublishAuditLog(formData)      
          
        );
        console.log('[RiskAssessment] Audit log created', formData);

        // Send to chat via bridge
        
        console.log('[RiskAssessment] Sending ticket creation message to chat');
        this.tlChatBridge.sendToChat(translatedContent, metadata);
        
        // Emit ticket created event to close parent windows
        // this.ticketCreated.emit({
        //   requestNumber: response.requestNumber,
        //   phoenixRdpLink: response.phoenixRdpLink
        // });
                this.ticketCreated.emit({
          requestNumber: this.ticket_number,
          phoenixRdpLink: ""
        });

      } catch (error) {
        console.error('[RiskAssessment] Invalid ticket data');
        const errorMessage = '❌ Error processing request. Please try again.';
        this.tlChatBridge.sendToChat(errorMessage, {
          contentType: 'Phoenix_Request',
          topic: 'Request Error',
          fullContent: errorMessage,
          showActions: false
        });
        
        // Emit ticket created event to close parent windows even on error
        this.ticketCreated.emit({
          requestNumber: '',
          phoenixRdpLink: ''
        });
      }

      this.isGenerating = false;
      this.close.emit();
    //}

  }

  handleClose(event?: Event): void {
    if (event) {
      event.preventDefault();
      event.stopPropagation();
    }
    console.log('[RiskAssessment] Close button clicked - emitting close event');
    this.resetFormFields();
    this.close.emit();
  }

  resetFormFields(): void {
    // Reset all form fields
    this.dueDiligence = {
      fullyReviewed: false,
      standBehindArguments: false,
      reviewedSources: false,
      citedAllData: false
    };
    this.highRiskTopics = {
      ai: false,
      policies: false,
      regulations: false,
      independenceConsiderations: false,
      pwcBuiltTechnology: false,
      noneOfAbove: false
    };
    this.publicRisk = '';
    this.publishingDestination = '';
    this.certifyAccuracy = false;
    this.offeringLeadSearchInput = '';
    this.offeringLead = '';
    this.offeringLeadEmail = '';
    this.offeringLeadSelected = false;
    this.practiceLeadSearchInput = '';
    this.practiceLead = '';
    this.practiceLeadEmail = '';
    this.practiceLeadSelected = false;
    this.submitErrorMessage = null;
    console.log('[RiskAssessment] Form fields reset');
  }

  // Offering Lead search methods
  async filterOfferingLeads(): Promise<void> {
    const input = this.offeringLeadSearchInput.trim();
    const user = await firstValueFrom(this.currentUserService.user$);
    var user_email = (user?.email || '').toLowerCase().replace('@dev365.', '@');
    
    // Close dropdown if input is empty
    if (!input) {
      this.filteredOfferingLeads = [];
      this.offeringLeadDropdownOpen = false;
      return;
    }
    
    // Only search if at least 3 characters are entered
    if (input.length < 3) {
      this.filteredOfferingLeads = [];
      return;
    }
    
    this.offeringLeadLoading = true;
    this.chatService.searchPeople(input, user_email).subscribe({
      next: (response: any) => {
        // console.log('[RiskAssessment] Offering lead API response:', response);
        // Map the API response to the expected format
        if (Array.isArray(response)) {
          // console.log('[RiskAssessment] Response is array');
          this.filteredOfferingLeads = response.map((person: any) => ({
            id: person.id || person.email || person.name,
            name: person.name || person.displayName || '',
            formattedName: person.formattedName || person.name || person.displayName || '',
            cloudEmailAddress: person.cloudEmailAddress || person.email || ''
          }));
        } else if (response.results && Array.isArray(response.results)) {
          // console.log('[RiskAssessment] Response has results array');
          this.filteredOfferingLeads = response.results.map((person: any) => ({
            id: person.id || person.email || person.name,
            name: person.name || person.displayName || '',
            formattedName: person.formattedName || person.name || person.displayName || '',
            cloudEmailAddress: person.cloudEmailAddress || person.email || ''
          }));
        } else if (response.data && Array.isArray(response.data)) {
          // console.log('[RiskAssessment] Response has data array');
          this.filteredOfferingLeads = response.data.map((person: any) => ({
            id: person.id || person.email || person.name,
            name: person.name || person.displayName || '',
            formattedName: person.formattedName || person.name || person.displayName || '',
            cloudEmailAddress: person.cloudEmailAddress || person.email || ''
          }));
        } else {
          console.log('[RiskAssessment] Response format not recognized', response);
        }
        console.log('[RiskAssessment] Filtered offering leads retrieved');
        this.offeringLeadLoading = false;
      },
      error: (error) => {
        console.error('[RiskAssessment] Error searching offering leads');
        this.filteredOfferingLeads = [];
        this.offeringLeadLoading = false;
      }
    });
  }

  selectOfferingLead(lead: { id: string, name: string, formattedName?: string, cloudEmailAddress?: string }): void {
    this.offeringLead = lead.id;
    this.offeringLeadSearchInput = lead.formattedName || lead.name;
    this.offeringLeadEmail = lead.cloudEmailAddress || '';
    this.offeringLeadSelected = true; // Mark as selected from dropdown
    this.offeringLeadDropdownOpen = false;
  }

  onOfferingLeadInputChange(): void {
    // Reset selection flag when user types in the field
    this.offeringLeadSelected = false;
    this.offeringLead = '';
    this.offeringLeadEmail = '';
    // console.log('[RiskAssessment] Offering lead input changed, reset selection flag');
    
    if (this.offeringLeadDebounceTimer) {
      clearTimeout(this.offeringLeadDebounceTimer);
    }
    this.offeringLeadDropdownOpen = true;
    this.offeringLeadDebounceTimer = setTimeout(() => {
      this.filterOfferingLeads();
    }, 2000);
  }

  openOfferingLeadDropdown(): void {
    this.offeringLeadDropdownOpen = true;
  }

  closeOfferingLeadDropdown(): void {
    // Close with minimal delay - mousedown on dropdown items fires before blur,
    // so selection completes before dropdown closes
    setTimeout(() => {
      this.offeringLeadDropdownOpen = false;
    }, 50);
  }

  // Practice Lead search methods
  async filterPracticeLeads(): Promise<void> {
    const input = this.practiceLeadSearchInput.trim();
    const user = await firstValueFrom(this.currentUserService.user$);
    var user_email = (user?.email || '').toLowerCase().replace('@dev365.', '@');
    
    // Close dropdown if input is empty
    if (!input) {
      this.filteredPracticeLeads = [];
      this.practiceLeadDropdownOpen = false;
      return;
    }
    
    // Only search if at least 3 characters are entered
    if (input.length < 3) {
      this.filteredPracticeLeads = [];
      return;
    }
    
    this.practiceLeadLoading = true;
    this.chatService.searchPeople(input, user_email).subscribe({
      next: (response: any) => {
        // console.log('[RiskAssessment] Practice lead API response:', response);
        // Map the API response to the expected format
        if (Array.isArray(response)) {
          // console.log('[RiskAssessment] Response is array');
          this.filteredPracticeLeads = response.map((person: any) => ({
            id: person.id || person.email || person.name,
            name: person.name || person.displayName || '',
            formattedName: person.formattedName || person.name || person.displayName || '',
            cloudEmailAddress: person.cloudEmailAddress || person.email || ''
          }));
        } else if (response.results && Array.isArray(response.results)) {
          // console.log('[RiskAssessment] Response has results array');
          this.filteredPracticeLeads = response.results.map((person: any) => ({
            id: person.id || person.email || person.name,
            name: person.name || person.displayName || '',
            formattedName: person.formattedName || person.name || person.displayName || '',
            cloudEmailAddress: person.cloudEmailAddress || person.email || ''
          }));
        } else if (response.data && Array.isArray(response.data)) {
          // console.log('[RiskAssessment] Response has data array');
          this.filteredPracticeLeads = response.data.map((person: any) => ({
            id: person.id || person.email || person.name,
            name: person.name || person.displayName || '',
            formattedName: person.formattedName || person.name || person.displayName || '',
            cloudEmailAddress: person.cloudEmailAddress || person.email || ''
          }));
        } else {
          console.log('[RiskAssessment] Response format not recognized', response);
        }
        console.log('[RiskAssessment] Filtered practice leads retrieved');
        this.practiceLeadLoading = false;
      },
      error: (error) => {
        console.error('[RiskAssessment] Error searching practice leads');
        this.filteredPracticeLeads = [];
        this.practiceLeadLoading = false;
      }
    });
  }

  selectPracticeLead(lead: { id: string, name: string, formattedName?: string, cloudEmailAddress?: string }): void {
    this.practiceLead = lead.id;
    this.practiceLeadSearchInput = lead.formattedName || lead.name;
    this.practiceLeadEmail = lead.cloudEmailAddress || '';
    this.practiceLeadSelected = true; // Mark as selected from dropdown
    this.practiceLeadDropdownOpen = false;
  }

  onPracticeLeadInputChange(): void {
    // Reset selection flag when user types in the field
    this.practiceLeadSelected = false;
    this.practiceLead = '';
    this.practiceLeadEmail = '';
    // console.log('[RiskAssessment] Practice lead input changed, reset selection flag');
    
    if (this.practiceLeadDebounceTimer) {
      clearTimeout(this.practiceLeadDebounceTimer);
    }
    this.practiceLeadDropdownOpen = true;
    this.practiceLeadDebounceTimer = setTimeout(() => {
      this.filterPracticeLeads();
    }, 2000);
  }

  openPracticeLeadDropdown(): void {
    this.practiceLeadDropdownOpen = true;
  }

  closePracticeLeadDropdown(): void {
    // Close with minimal delay - mousedown on dropdown items fires before blur,
    // so selection completes before dropdown closes
    setTimeout(() => {
      this.practiceLeadDropdownOpen = false;
    }, 50);
  }

  // Close dropdowns when clicking outside
  @HostListener('document:click', ['$event'])
  onDocumentClick(event: Event): void {
    const target = event.target as HTMLElement;
    if (!target.closest('.search-field-wrapper')) {
      this.offeringLeadDropdownOpen = false;
      this.practiceLeadDropdownOpen = false;
    }
  }

  // Handle public risk radio button clicks for toggle/deselect behavior
  onPublicRiskClick(value: string): void {
    // If clicking the same option that's already selected, deselect it
    if (this.publicRisk === value) {
      this.publicRisk = '';
      console.log('[RiskAssessment] Deselected public risk option:', value);
    } else {
      // Otherwise select the new option
      this.publicRisk = value;
      console.log('[RiskAssessment] Selected public risk option:', value);
    }
  }

  // Handle high-risk topics selection with mutual exclusion for "None of above"
  onHighRiskTopicChange(topic: string): void {
    if (topic === 'noneOfAbove') {
      // If "None of above" is being checked, deselect all others
      if (this.highRiskTopics.noneOfAbove) {
        this.highRiskTopics.ai = false;
        this.highRiskTopics.policies = false;
        this.highRiskTopics.regulations = false;
        this.highRiskTopics.independenceConsiderations = false;
        this.highRiskTopics.pwcBuiltTechnology = false;
        console.log('[RiskAssessment] "None of above" selected - deselected all other options');
      }
    } else {
      // If any other option is being checked and "None of above" is checked, deselect it
      if (this.highRiskTopics.noneOfAbove) {
        this.highRiskTopics.noneOfAbove = false;
        console.log('[RiskAssessment] Other option selected - deselected "None of above"');
      }
    }
    console.log('[RiskAssessment] High-risk topics state:', this.highRiskTopics);
  }

  // Check if form is valid for submission
  isSubmitButtonDisabled(): boolean {
    // Check if ALL due diligence checkboxes are checked (all 4 must be true)
    const isDueDiligenceAnswered = Object.values(this.dueDiligence).every(value => value === true);
    
    // Check if at least one high-risk topic checkbox is checked
    const isHighRiskAnswered = Object.values(this.highRiskTopics).some(value => value === true);
    
    // Check if public risk radio button is selected
    const isPublicRiskAnswered = this.publicRisk && this.publicRisk.length > 0;
    
    // Check if publishing destination is filled
    const isPublishingDestinationFilled = this.publishingDestination && this.publishingDestination.trim().length > 0;
    
    // Check if certification checkbox is checked
    const isCertificationChecked = this.certifyAccuracy === true;
    
    // Check if offering lead was selected from dropdown results (not just typed)
    const isOfferingLeadSelected = this.offeringLeadSelected;
    
    // Check if practice lead was selected from dropdown results (not just typed)
    const isPracticeLeadSelected = this.practiceLeadSelected;
    
    // console.log('[RiskAssessment] Form Validation:', {
    //   isDueDiligenceAnswered,
    //   isHighRiskAnswered,
    //   isPublicRiskAnswered,
    //   isCertificationChecked,
    //   isOfferingLeadSelected,
    //   isPracticeLeadSelected,
    //   dueDiligence: this.dueDiligence,
    //   highRiskTopics: this.highRiskTopics,
    //   publicRisk: this.publicRisk,
    //   certifyAccuracy: this.certifyAccuracy,
    //   offeringLead: this.offeringLead,
    //   offeringLeadSearchInput: this.offeringLeadSearchInput,
    //   practiceLead: this.practiceLead,
    //   practiceLeadSearchInput: this.practiceLeadSearchInput
    // });
    
    // Button is disabled if any required field is missing
    const isDisabled = !(
      isDueDiligenceAnswered &&
      isHighRiskAnswered &&
      isPublicRiskAnswered &&
      isPublishingDestinationFilled &&
      isCertificationChecked &&
      isOfferingLeadSelected &&
      isPracticeLeadSelected
    );
    
    // console.log('[RiskAssessment] Button disabled:', isDisabled);
    return isDisabled;
  }

  /**
   * Escape HTML special characters to prevent XSS
   */
  private escapeHtmlSpecialChars(untrustedData: string): string {
    if (!untrustedData) return '';
    const div = document.createElement('div');
    div.textContent = untrustedData;
    return div.innerHTML;
  }

  /**
   * Escape data for use in HTML attributes
   */
  private escapeHtmlAttribute(untrustedData: string): string {
    if (!untrustedData) return '';
    return untrustedData
      .replace(/&/g, '&amp;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#x27;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;');
  }

  /**
   * Format file size in human-readable format
   */
  formatFileSize(bytes: number): string {
    if (bytes === 0) return '0 Bytes';
    
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    
    return Math.round((bytes / Math.pow(k, i)) * 100) / 100 + ' ' + sizes[i];
  }

  /**
   * Validate URL to prevent open redirect attacks
   */
  private validateAndEscapeUrl(urlString: string): void {
    if (!urlString) throw new Error('URL is empty');
    
    try {
      const url = new URL(urlString);
      
      if (!['http:', 'https:'].includes(url.protocol)) {
        throw new Error(`Invalid protocol: ${url.protocol}`);
      }
    } catch (error) {
      throw new Error(`URL validation failed: ${error instanceof Error ? error.message : 'Invalid URL'}`);
    }
  }
}

/*
this.chatService.submitRiskAssessment(payload).subscribe({
      next: (response: any) => {
        console.log('[RiskAssessment] Risk assessment submitted successfully');
        console.log('[RiskAssessment] API response received');
        // Close the form after successful submission
        this.close.emit();
      },
      error: (error: any) => {
        console.error('[RiskAssessment] Error submitting risk assessment');
        console.error('[RiskAssessment] Error occurred');
        // Handle error - show message to user
      }
    });

*/