import { Component, OnInit, Output, EventEmitter, OnDestroy, ViewChild, AfterViewInit, ChangeDetectorRef } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { FileUploadComponent } from '../../../shared/ui/components/file-upload/file-upload.component';
import { RiskAssessmentFlowComponent } from '../risk-assessment/risk-assessment-flow.component';
import { TlFlowService } from '../../../core/services/tl-flow.service';
import { CurrentUserService } from '../../../core/services/current-user.service';
import { ChatService } from '../../../core/services/chat.service';
import { Subject, firstValueFrom, of } from 'rxjs';
import { takeUntil } from 'rxjs/operators';

interface PublicationForm {
  contentFile: File | null;
}

@Component({
  selector: 'app-ready-to-publish-flow',
  imports: [FormsModule, FileUploadComponent, RiskAssessmentFlowComponent],
  templateUrl: './ready-to-publish-flow.component.html',
  styleUrls: ['./ready-to-publish-flow.component.scss']
})
export class ReadyToPublishFlowComponent implements OnInit, OnDestroy, AfterViewInit {
  @Output() close = new EventEmitter<void>();
  @Output() back = new EventEmitter<void>();
  @ViewChild(FileUploadComponent) fileUploadComponent?: FileUploadComponent;

  // Platform type selection (mutually exclusive)
  selectedPlatform: string | null = null;

  // Results modal
  showCheckResultsModal = false;

  // Risk assessment visibility
  showRiskAssessment = false;

  // Client deliverables confirmation
  clientDeliverablesConfirmed = false;

  // Social media confirmation
  socialConfirmed = false;

  // User profile
  userRole: string | null = null;
  userName: string | null = null;
  userEmail: string | null = null;
  private destroy$ = new Subject<void>();

  // File upload
  formData: PublicationForm = {
    contentFile: null
  };

  // File upload properties
  supportedFormats = '.pdf, .docx, .doc, .md, .txt';
  uploadError = '';
  preGeneratedDocument: File | null = null;
  private viewInitialized = false;

  constructor(
    private tlFlowService: TlFlowService,
    private currentUserService: CurrentUserService,
    private chatService: ChatService,
    private changeDetectorRef: ChangeDetectorRef
  ) {}

  ngOnInit(): void {
    console.log('[ReadyToPublish] ngOnInit - Subscribing to pre-generated document');
    
    // Subscribe to pre-generated document observable
    this.tlFlowService.preGeneratedDocument$
      .pipe(takeUntil(this.destroy$))
      .subscribe((doc: File | null) => {
        if (doc) {
          console.log('[ReadyToPublish] Received pre-generated document from service:', doc.name);
          this.preGeneratedDocument = doc;
          
          // Try to attach immediately if view is already initialized
          if (this.viewInitialized) {
            console.log('[ReadyToPublish] View already initialized, attaching document immediately');
            this.attachPreGeneratedDocument();
          }
        }
      });

    // Fetch UserProfile when the ready-to-publish window is opened
    const currentUser = this.currentUserService.currentUser;
    console.log('[ReadyToPublish] Window opened - fetching user profile');
    
    if (currentUser && currentUser.email) {
      // Clean email (remove @dev365 if present)
      const cleanEmail = currentUser.email.replace('@dev365.', '@');
      this.userEmail = cleanEmail;
      console.log('[ReadyToPublish] Fetching full user profile for email:', cleanEmail);
      
      // Fetch the complete UserProfile from ChatService
      this.chatService.getUserProfile(cleanEmail)
        .pipe(takeUntil(this.destroy$))
        .subscribe({
          next: (userProfile) => {
            console.log('[ReadyToPublish] Full UserProfile received:', userProfile);
            if (userProfile && userProfile.jobTitle) {
              this.userRole = userProfile.jobTitle.toLowerCase();
              this.userName = userProfile.firstName + " " + userProfile.lastName;
              console.log('[ReadyToPublish] User role extracted and saved:', this.userRole);
            } else {
              console.warn('[ReadyToPublish] No jobTitle found in UserProfile');
            }
          },
          error: (error) => {
            console.error('[ReadyToPublish] Error fetching user profile:', error);
          }
        });
    } else {
      console.warn('[ReadyToPublish] No email found in current user');
    }
  }

  ngOnDestroy(): void {
    this.destroy$.next();
    this.destroy$.complete();
  }

  ngAfterViewInit(): void {
    console.log('[ReadyToPublish] AfterViewInit - View hierarchy ready');
    
    // Mark view as initialized
    this.viewInitialized = true;
    
    // If we have a pre-generated document, attach it now
    if (this.preGeneratedDocument) {
      console.log('[ReadyToPublish] View initialized and document available, attaching now');
      this.attachPreGeneratedDocument();
    } else {
      console.log('[ReadyToPublish] View initialized but no document yet (will attach when document arrives)');
    }
  }

  /**
   * Attach the pre-generated document to the file upload component
   * Uses multiple timing attempts to ensure the component is ready
   */
  private attachPreGeneratedDocument(): void {
    if (!this.preGeneratedDocument) {
      console.warn('[ReadyToPublish] attachPreGeneratedDocument called but no document available');
      return;
    }

    if (!this.fileUploadComponent) {
      console.warn('[ReadyToPublish] FileUploadComponent not available yet, will retry');
      // Retry after a short delay
      setTimeout(() => this.attachPreGeneratedDocument(), 50);
      return;
    }

    console.log('[ReadyToPublish] Attaching document:', this.preGeneratedDocument.name);
    
    try {
      // Call addFile on the FileUploadComponent
      this.fileUploadComponent.addFile(this.preGeneratedDocument);
      
      // Update local form data
      this.formData.contentFile = this.preGeneratedDocument;
      
      // Trigger change detection
      this.changeDetectorRef.detectChanges();
      
      console.log('[ReadyToPublish] Document successfully attached to file upload component');
      
      // Clear from service after successful attachment
      this.tlFlowService.clearPreGeneratedDocument();
    } catch (error) {
      console.error('[ReadyToPublish] Error attaching document:', error);
    }
  }

  /**
   * Handle file selection from upload component
   */
  onFileSelected(event: File): void {
    if (event) {
      this.formData.contentFile = event;
      this.uploadError = '';
    }
  }

  /**
   * Handle file removal from upload component
   */
  onFileRemoved(): void {
    this.formData.contentFile = null;
    // Reset selected platform when file is removed
    this.selectedPlatform = null;
    this.showRiskAssessment = false;
  }

  /**
   * Handle platform toggle changes - mutually exclusive selection
   */
  onPlatformToggle(platform: string, event: boolean): void {
    if (event) {
      // If checkbox is checked, select this platform and deselect others
      this.selectedPlatform = platform;
      // Reset confirmations when platform changes
      this.clientDeliverablesConfirmed = false;
      this.socialConfirmed = false;
      this.showRiskAssessment = false;

      // Log platform selection
      console.log('[ReadyToPublish] Platform toggle selected:', platform);
    } else {
      // If checkbox is unchecked, deselect the platform
      if (this.selectedPlatform === platform) {
        this.selectedPlatform = null;
        this.clientDeliverablesConfirmed = false;
        this.socialConfirmed = false;
        this.showRiskAssessment = false;
      }
    }
  }

  /**
   * Check publication readiness
   */
  checkPublicationReadiness(): void {
    // Validate that a platform is selected
    if (!this.selectedPlatform) {
      this.uploadError = 'Please select a platform type.';
      return;
    }

    // Validate that a file is uploaded
    if (!this.formData.contentFile) {
      this.uploadError = 'Please upload a document before checking publication readiness.';
      return;
    }

    this.uploadError = '';

    // For public platform, directly go to risk assessment
    if (this.selectedPlatform === 'public') {
      this.showRiskAssessment = true;
    } else {
      // For internal and social platforms, show the verification modal
      this.showCheckResultsModal = true;
    }

    console.log('Checking publication readiness with:', {
      file: this.formData.contentFile.name,
      platform: this.selectedPlatform
    });
  }

  /**
   * Get visibility state based on active flow
   */
  get isOpen(): boolean {
    return this.tlFlowService.currentFlow === 'ready-to-publish';
  }

  /**
   * Close the flow
   */
  onClose(): void {
    // Reset all toggles and confirmations before closing
    this.selectedPlatform = null;
    this.formData.contentFile = null;
    this.clientDeliverablesConfirmed = false;
    this.socialConfirmed = false;
    this.showRiskAssessment = false;
    this.preGeneratedDocument = null;
    // Clear pre-generated document from service
    this.tlFlowService.clearPreGeneratedDocument();
    this.tlFlowService.closeFlow();
  }

  /**
   * Go back to previous step
   */
  backStep(): void {
    // Reset all toggles, confirmations and user role when going back
    this.selectedPlatform = null;
    this.formData.contentFile = null;
    this.clientDeliverablesConfirmed = false;
    this.socialConfirmed = false;
    this.showRiskAssessment = false;
    this.preGeneratedDocument = null;
    // Clear pre-generated document from service
    this.tlFlowService.clearPreGeneratedDocument();
    this.tlFlowService.closeFlow();
  }

  /**
   * Confirm client deliverables usage and close the flow
   */
  async confirmClientDeliverablesAndClose(): Promise<void> {
     
    this.clientDeliverablesConfirmed = true;    
    //call backend service

    const formData = new FormData();
    formData.append("user_name", this.userName ||'Unknown User');
    formData.append("user_email", this.userEmail || '');
    formData.append("content_category", "Client deliverables");
    formData.append("verification_status", "Confirmed");
    formData.append("comments", "");
    formData.append("file", this.formData.contentFile || new Blob());

    const response: any = await firstValueFrom(
      this.chatService.createRequestToPublishAuditLog(formData)      
      
    );
    console.log('[ReadyToPublish] Audit log created',response);

    this.closeResultsModal();
    this.onClose();
  }

  /**
   * Confirm social media usage and close the flow
   */
  async confirmSocialMediaAndClose(): Promise<void> {
    this.socialConfirmed = true;

    //call backend service
    const formData = new FormData();
    formData.append("user_name", this.userName ||'Unknown User');
    formData.append("user_email", this.userEmail || '');
    formData.append("content_category", "Social");
    formData.append("verification_status", "Confirmed");
    formData.append("comments", "");
    formData.append("file", this.formData.contentFile || new Blob());

    const response: any = await firstValueFrom(
      this.chatService.createRequestToPublishAuditLog(formData)      
      
    );
    console.log('[ReadyToPublish] Audit log created',response);

    this.closeResultsModal();
    this.onClose();
  }

  /**
   * Confirm client deliverables usage
   */
  confirmClientDeliverables(): void {
    this.clientDeliverablesConfirmed = true;
  }

  /**
   * Confirm social media usage
   */
  confirmSocialMedia(): void {
    this.socialConfirmed = true;
  }

  /**
   * Handle risk assessment flow close
   */
  onRiskAssessmentClose(): void {
    console.log('[ReadyToPublish] Risk assessment closed - returning to ready-to-publish');
    // Hide the risk assessment component
    this.showRiskAssessment = false;
  }

  /**
   * Handle ticket created - close both risk assessment and ready-to-publish windows
   */
  onTicketCreatedAndClose(): void {
    console.log('[ReadyToPublish] Ticket created - closing ready-to-publish window');
    // Close the risk assessment
    this.showRiskAssessment = false;
    this.selectedPlatform = null;
    this.formData.contentFile = null;
    // Close the flow service which will close the ready-to-publish window
    this.tlFlowService.closeFlow();
  }

  /**
   * Close the results modal
   */
  closeResultsModal(): void {
    this.showCheckResultsModal = false;
  }

  /**
   * Proceed to risk assessment
   */
  proceedToRiskAssessment(): void {
    this.showRiskAssessment = true;
    this.showCheckResultsModal = false;
  }
}
