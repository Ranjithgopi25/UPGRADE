import { Component, OnInit, OnDestroy } from '@angular/core';
import { DomSanitizer, SafeHtml } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';
import { MatSelectModule } from '@angular/material/select';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatOptionModule } from '@angular/material/core';
import { MatInputModule } from '@angular/material/input';
import { Subject, Subscription, takeUntil } from 'rxjs';
import { TlFlowService } from '../../../core/services/tl-flow.service';
import { ChatService } from '../../../core/services/chat.service';
import { TlChatBridgeService } from '../../../core/services/tl-chat-bridge.service';
import { ThoughtLeadershipMetadata } from '../../../core/models';
import { FileUploadComponent } from '../../../shared/ui/components/file-upload/file-upload.component';
import { TlRequestFormComponent } from '../../phoenix/TL/request-form';
import { AuthFetchService } from '../../../core/services/auth-fetch.service';
import { environment } from '../../../../environments/environment';
import { saveAs } from 'file-saver';

@Component({
    selector: 'app-format-translator-flow',
    imports: [FormsModule, MatSelectModule, MatFormFieldModule, MatOptionModule, MatInputModule, FileUploadComponent, TlRequestFormComponent],
    templateUrl: './format-translator-flow.component.html',
    styleUrls: ['./format-translator-flow.component.scss']
})
export class FormatTranslatorFlowComponent implements OnInit, OnDestroy {
  maxWordLimit = 400;
  wordLimitError = '';
  isGenerating = false;
  generationPhase: 'script' | 'podcast' = 'script';
  translatedContent = '';
  // When Webpage Ready is ON we keep streamed HTML/text here and do NOT show it in the modal
  hiddenTranslatedHtmlContent = '';
  // Audio handling
  audioUrl: string | null = null;
  audioBlob: Blob | null = null;
  audioBase64: string | null = null;  // Store base64 for creating chat-owned blob
  hasAudio = false;
 
  // File upload
  uploadedFile: File | null = null;
  uploadedFileWordCount = 'uploaded content';
  translatedHtmlUrl: string | null = null;
  // True if a document is uploaded via Upload Document button
  isDocumentUploaded: boolean = false;
  
  // Basic fields
  wordLimit = '';
    onWordLimitChange(value: any): void {
      // If Social Media Post is selected, enforce maxWordLimit on socialMediaLength
      if (this.formatSocialMedia) {
        const num = Number(this.socialMediaLength);
        if (!isNaN(num) && num > this.maxWordLimit) {
          this.wordLimitError = `Word limit cannot exceed ${this.maxWordLimit}.*`;
          this.socialMediaLength = this.maxWordLimit.toString();
        } else {
          this.wordLimitError = '';
          this.socialMediaLength = this.socialMediaLength.toString();
        }
      } else {
        // Default word limit logic for other formats
        if (value && Number(value) > this.maxWordLimit) {
          this.wordLimitError = `Word limit cannot exceed ${this.maxWordLimit}.*`;
          this.wordLimit = this.maxWordLimit.toString();
        } else {
          this.wordLimitError = '';
          this.socialMediaLength = this.socialMediaLength.toString();
        }
      }
    }
  // ensure any created blob URL is revoked when not needed
  private revokeTranslatedHtmlUrl(): void {
    if (this.translatedHtmlUrl && this.translatedHtmlUrl.startsWith('blob:')) {
      try { URL.revokeObjectURL(this.translatedHtmlUrl); } catch { /* ignore */ }
    }
    this.translatedHtmlUrl = null;
  }
  // Format selection - only ONE format can be ON at a time (handled via exclusive toggle logic)
  formatSocialMedia = false;
  formatWebpageReady = false;
  formatPlacemat = false;
  formatPodcast = false;
 
  // Social Media Post conditional fields
  socialMediaPlatform = '';
  socialMediaLength = '';
 
  // Placemat conditional fields
  placematPageType = 'one-page'; // 'one-page' or 'two-page'
  placematNumPages = '';
  downloadPlacematUrl = '';
  showCreateRequestButton = false;
  showRequestForm = false;
  _send_To_Chat: boolean = true;
 
  //WebArticle
  
  cleanHtmlContent(text: string): string {
    if (!text) return '';

    return text
      .trim()                       // remove leading/trailing spaces
      .replace(/\n{2,}/g, '\n')     // collapse multiple blank lines
      .replace(/\n/g, '</p><p>')    // convert lines to paragraphs
      .replace(/^/, '<p>')          // wrap with paragraph
      .replace(/$/, '</p>');
  }
 
  // Podcast conditional fields
  podcastFormat = 'monologue'; // 'monologue' or 'dialogue'
  speaker1Name = '';
  speaker1Voice = '';
  speaker1Accent = '';
  speaker2Name = '';
  speaker2Voice = '';
  speaker2Accent = '';
  podcastTheme = '';
  podcastAudience = '';
  podcastDuration = '';
  podcastDurationMode: 'short' | 'medium' | 'long' = 'short';
  podcastDurationSliderValue = 0; // 0: short, 1: medium, 2: long
  podcastDurationLabel = 'Short-Form 1-3 min';
  podcastDurationSliderBackground = '';
  enrichPodcast = false;
 
  // Research sub-options (same as Refine Content)
  researchTopics = '';
  pwcContentLink = false;
  pwcProprietaryResearch = false;
  pwcLicensedThirdParty = false;
  externalResearch = false;
  researchDocumentFile: File | null = null;
  researchLinks = '';
  wordLimitResearch = '';
  selectSpecificPwcSources = false;
  allPwcProprietarySources = false;
  pwcSource1 = false;
  pwcSource2 = false;
  pwcSource3 = false;
  pwcSource4 = false;
  allPwcThirdPartySources = false;
  pwcThirdPartySource1 = false;
  pwcThirdPartySource2 = false;
  pwcThirdPartySource3 = false;
  pwcThirdPartySource4 = false;
 
pwcProprietarySources = [
    { name: 'PwC industry edge', selected: false },
    { name: 'PwC.com', selected: true },
    { name: 'PwC insights', selected: false },
    { name: 's+b journal', selected: false },
    { name: 'Executive leadership hub', selected: false },
    { name: 'The exchange', selected: false },
    { name: 'PwC connected source', selected: false },
    { name: 'PwC benchmarking', selected: false },
    //{ name: 'Insights Factory', selected: false },
    //{ name: 'PwC Intelligence', selected: false },
    //{ name: 'C-Suite Connection Program', selected: true },
    //{ name: 'Viewpoint', selected: true },
    //{ name: 'Analyst and Advisor Relations', selected: true },
    //{ name: 'Assurance Benchmarking Tools', selected: true },
    //{ name: 'Policy on Demand', selected: true },
    //{ name: 'Tax Source', selected: true },
    //{ name: 'FFG Benchmarking', selected: true },
    // { name: 'Client Success Stories', selected: true },
    // { name: 'Inside Industries', selected: false },
    // { name: 'Value Store', selected: false }
  ];
 
  pwcThirdPartySources = [
  { name: 'Factiva, WSJ, Dow Jones', selected: false },
  { name: 'S&P Global- Capital IQ Xpressfeed', selected: false },
  { name: 'IBIS World', selected: false },
  { name: 'BoardEx', selected: false },
  // { name: 'S&P Global- Connect', selected: false },
  // { name: 'Audit Analytics', selected: false },
  // { name: 'S&P Global- SNL Insurance', selected: false },
  // { name: 'Claritas', selected: false },
  // { name: 'Equifax', selected: false },
  // { name: 'Equifax IXI', selected: false },
  // { name: 'Definitive Healthcare Provider Database', selected: false },
  // { name: 'Sg2 Health Care Intelligence', selected: false },
  // { name: 'Strata Market Insights', selected: false },
  // //{ name: 'CompanyIQ', selected: false },
  // { name: 'Global Data(Retail)', selected: false },
  // { name: 'Technology Business Review', selected: false },
  
  // //{ name: 'IDC', selected: false },
  // { name: 'CFRA Industry Surveys', selected: false }
];
 
  socialMediaPlatforms = [
    'x.com',
    'LinkedIn'
  ];
 
  voiceOptions = ['Male', 'Female'];
  accentOptions = ['American', 'British', 'Australian', 'Canadian', 'Indian'];
 
  private destroy$ = new Subject<void>();
  private streamSubscription?: Subscription;
 
  constructor(
    public tlFlowService: TlFlowService,
    private chatService: ChatService,
    private tlChatBridge: TlChatBridgeService,
    private authFetchService: AuthFetchService,
    private sanitizer: DomSanitizer
  ) {}
 
  ngOnInit(): void {
    this.tlFlowService.activeFlow$
      .pipe(takeUntil(this.destroy$))
      .subscribe((flow: any) => {
        if (flow === 'format-translator') {
          this.resetForm();
        }
      });
  }
 
  ngOnDestroy(): void {
    this.cancelStream();
    this.cleanupAudio();
    this.revokeTranslatedHtmlUrl();
    this.destroy$.next();
    this.destroy$.complete();
  }
 
  private cancelStream(): void {
    if (this.streamSubscription) {
      console.log('[FormatTranslatorFlow] Cancelling active stream');
      this.streamSubscription.unsubscribe();
      this.streamSubscription = undefined;
      this.isGenerating = false;
    }
  }
 
  get isOpen(): boolean {
    return this.tlFlowService.currentFlow === 'format-translator';
  }
 
  onClose(): void {
    this.resetForm();
    this.cancelStream();
    this.tlFlowService.closeFlow();
    this.revokeTranslatedHtmlUrl();
  }
 
  back(): void{
    this.cancelStream();
    this.resetForm();
    this.tlFlowService.closeFlow();
    this.tlFlowService.openGuidedDialog();
  }
 
  resetForm(): void {
    this.uploadedFile = null;
    this.isDocumentUploaded = false;
    this.uploadedFileWordCount = 'uploaded content';
    this.formatSocialMedia = false;
    this.formatWebpageReady = false;
    this.formatPlacemat = false;
    this.formatPodcast = false;
    this.clearAllFormatFields();
    this.translatedContent = '';
    this.hiddenTranslatedHtmlContent = '';
    this.revokeTranslatedHtmlUrl();
    this.cleanupAudio();
    this.isGenerating = false;
  }
 
  private cleanupAudio(): void {
    if (this.audioUrl) {
      URL.revokeObjectURL(this.audioUrl);
      this.audioUrl = null;
    }
    this.audioBlob = null;
    this.audioBase64 = null;
    this.hasAudio = false;
  }
 
private async extractTextFromPDF(file: File): Promise<string> {
  try {
    const arrayBuffer = await file.arrayBuffer();
    // Note: This requires pdf.js library. For now, return plain text extraction
    const text = await file.text();
    return text.replace(/\x00/g, ''); // Remove null characters
  } catch (error) {
    console.error('Error extracting PDF:', error);
    return '';
  }
}
 
private async extractTextFromDOCX(file: File): Promise<string> {
  try {
    const arrayBuffer = await file.arrayBuffer();
    // Simple DOCX extraction - get XML and extract text
    const text = await this.extractDOCXText(arrayBuffer);
    return text;
  } catch (error) {
    console.error('Error extracting DOCX:', error);
    return '';
  }
}
 
private async extractDOCXText(arrayBuffer: ArrayBuffer): Promise<string> {
  try {
    // DOCX is a ZIP file, we need to extract document.xml
    const view = new Uint8Array(arrayBuffer);
    const text = new TextDecoder().decode(view);
   
    // Extract text between XML tags
    const textMatches = text.match(/<w:t[^>]*>(.*?)<\/w:t>/gs);
    if (textMatches) {
      return textMatches
        .map(match => match.replace(/<w:t[^>]*>(.*?)<\/w:t>/s, '$1'))
        .join(' ')
        .trim();
    }
   
    return text;
  } catch (error) {
    console.error('Error parsing DOCX:', error);
    return '';
  }
}
 
  private clearAllFormatFields(): void {
    // Clear Social Media fields
    this.socialMediaPlatform = '';
    this.socialMediaLength = '';
   
    // Clear Placemat fields
    this.placematPageType = 'one-page';
    this.placematNumPages = '';
   
    // Clear Podcast fields
    this.podcastFormat = 'monologue';
    this.speaker1Name = '';
    this.speaker1Voice = '';
    this.speaker1Accent = '';
    this.speaker2Name = '';
    this.speaker2Voice = '';
    this.speaker2Accent = '';
    this.podcastTheme = '';
    this.podcastAudience = '';
    this.podcastDuration = '';
    this.podcastDurationMode = 'short';
    this.podcastDurationSliderValue = 0;
    this.podcastDurationLabel = 'Short-Form 1-3 min';
    this.updatePodcastSliderBackground(this.podcastDurationSliderValue);
    this.enrichPodcast = false;
    this.clearResearchOptions();
  }

  private resetGeneratedOutput(): void {
  this.translatedContent = '';
  //this.outputHeading = '';
  this.hasAudio = false;
  this.audioUrl = null;

  this.downloadPlacematUrl = '';
  this.showCreateRequestButton = false;
}
 
  onFileSelected(file: File): void {
    this.uploadedFile = file;
    this.isDocumentUploaded = !!file;
  }

  onFileRemoved(): void {
    this.uploadedFile = null;
    this.isDocumentUploaded = false;
    // Reset all format selections when file is removed
    this.formatSocialMedia = false;
    this.formatWebpageReady = false;
    this.formatPlacemat = false;
    this.formatPodcast = false;
  }
 
  onFormatToggle(format: string, newValue: boolean): void {
    // Ensure only ONE format is ON at a time (exclusive selection)
    if (newValue) {
      // When turning ON a format, turn OFF all others
      switch (format) {
        case 'social-media':
          this.formatWebpageReady = false;
          this.formatPlacemat = false;
          this.formatPodcast = false;
          break;
        case 'webpage-ready':
          this.formatSocialMedia = false;
          this.formatPlacemat = false;
          this.formatPodcast = false;
          break;
        case 'placemat':
          this.formatSocialMedia = false;
          this.formatWebpageReady = false;
          this.formatPodcast = false;
          break;
        case 'podcast':
          this.formatSocialMedia = false;
          this.formatWebpageReady = false;
          this.formatPlacemat = false;
          break;
      }
    }
    // Clear all format-specific fields when toggling
    this.clearAllFormatFields();

     // Clear generated output
    this.resetGeneratedOutput();
  }
 
  onEnrichPodcastToggle(): void {
    if (!this.enrichPodcast) {
      this.clearResearchOptions();
    }
  }
 
  clearResearchOptions(): void {
    this.researchTopics = '';
    this.pwcContentLink = false;
    this.pwcProprietaryResearch = false;
    this.pwcLicensedThirdParty = false;
    this.externalResearch = false;
    this.researchDocumentFile = null;
    this.researchLinks = '';
    this.wordLimitResearch = '';
    this.selectSpecificPwcSources = false;
    this.allPwcProprietarySources = false;
    this.pwcSource1 = false;
    this.pwcSource2 = false;
    this.pwcSource3 = false;
    this.pwcSource4 = false;
    this.allPwcThirdPartySources = false;
    this.pwcThirdPartySource1 = false;
    this.pwcThirdPartySource2 = false;
    this.pwcThirdPartySource3 = false;
    this.pwcThirdPartySource4 = false;
 
    // Reset all proprietary sources array
  this.pwcProprietarySources.forEach(source => source.selected = false);
 
  // Reset all third party sources array
  this.pwcThirdPartySources.forEach(source => source.selected = false);
  }
 
  onResearchDocumentSelected(file: File): void {
    this.researchDocumentFile = file;
  }
 
  onAllPwcProprietarySourcesChange(): void {
    const value = this.allPwcProprietarySources;
    this.pwcSource1 = value;
    this.pwcSource2 = value;
    this.pwcSource3 = value;
    this.pwcSource4 = value;
  }
 
onAllPwcThirdPartyToggle(value: boolean): void {
  this.allPwcThirdPartySources = value;
  this.pwcThirdPartySources.forEach(source => source.selected = value);
}
 
 
onPwcThirdPartySourceChange(): void {
  this.allPwcThirdPartySources = this.pwcThirdPartySources.every(s => s.selected);
}
 
onAllPwcProprietaryToggle(value: boolean): void {
    this.pwcProprietarySources.forEach(source => source.selected = value);
  }
 
  onPwcProprietarySourceChange(): void {
    this.allPwcProprietarySources = this.pwcProprietarySources.every(s => s.selected);
  }
 
  onAllPwcThirdPartySourcesChange(): void {
    const value = this.allPwcThirdPartySources;
    this.pwcThirdPartySource1 = value;
    this.pwcThirdPartySource2 = value;
    this.pwcThirdPartySource3 = value;
    this.pwcThirdPartySource4 = value;
  }
 
  get showPwcSourceSelection(): boolean {
    return this.enrichPodcast && (this.pwcProprietaryResearch || this.pwcLicensedThirdParty);
  }
 
  get showDialogueSpeakers(): boolean {
    return this.formatPodcast && this.podcastFormat === 'dialogue';
  }
 
  
  get canTranslate(): boolean {
    if (!this.uploadedFile) return false;
   
    // At least one format must be selected
    if (!this.formatSocialMedia && !this.formatWebpageReady && !this.formatPlacemat && !this.formatPodcast) {
      return false;
    }
   
    // Validate format-specific required fields
    if (this.formatSocialMedia) {
      return !!(this.socialMediaPlatform); //&& this.socialMediaLength.trim());
    }
   
    if (this.formatWebpageReady) {
      return true; // No additional required fields
    }
   
    if (this.formatPlacemat) {
      // if (this.placematPageType === 'two-page') {
      //   return !!this.placematNumPages.trim();
      // }
      return true;
    }
   
    if (this.formatPodcast) {
      // Basic podcast required fields
      // if (!this.podcastAudience.trim() || !this.podcastDuration.trim()) {
      //   return false;
      // }
      // Speaker 1 required fields
      // if (!this.speaker1Name.trim() || !this.speaker1Voice || !this.speaker1Accent) {
      //   return false;
      // }
      // Speaker 2 required if dialogue
      // if (this.podcastFormat === 'dialogue') {
      //   if (!this.speaker2Name.trim() || !this.speaker2Voice || !this.speaker2Accent) {
      //     return false;
      //   }
      // }
      return true;
    }
   
    return false;
  }
   get outputHeading(): string {
  if (this.formatSocialMedia) {
    return `${this.socialMediaPlatform} Content`;
  }
  if (this.formatWebpageReady) {
    return 'Web Article Content';
  }
  if (this.formatPlacemat) {
    return '';//Placemat Content
  }
  if (this.formatPodcast) {
    return 'Podcast Content';
  }
return 'Translated Content';

}

  /**
   * Extract text from uploaded file using the extract API
   */
  private async extractFileText(file: File): Promise<string> {
    const formData = new FormData();
    formData.append('file', file);

    // Get API URL from environment (supports runtime config via window._env)
    const apiUrl = (window as any)._env?.apiUrl || environment.apiUrl || '';
    const response = await this.authFetchService.authenticatedFetchFormData(`${apiUrl}/api/v1/export/extract-text`, {
      method: 'POST',
      body: formData
    });

    if (!response.ok) {
      throw new Error('Failed to extract text from file');
    }

    const data = await response.json();
    return data.text || '';
  }

  async translateFormat(): Promise<void> {

    if (
    this.formatPlacemat &&
    this.placematPageType === 'custom' &&
    !this.canTranslatePlacemat()
  ) {
    this.translatedContent =
      'Please enter a valid number of pages (1-10) for Custom placemat.';
    this.isGenerating = false;
    return;
  }
    
    if (!this.uploadedFile) {
      console.error('No file uploaded');
      return;
    }
 
    this.isGenerating = true;
    this.generationPhase = this.formatPodcast ? 'script' : 'script';
    this.translatedContent = '';
 
    try {
      // Extract text from uploaded file using API
      let contentText = '';
      try {
        contentText = await this.extractFileText(this.uploadedFile);
      } catch (error) {
        console.error('Error extracting file text:', error);
        this.translatedContent = 'Could not extract text from the file. Please ensure the file contains readable text content.';
        this.isGenerating = false;
        return;
      }
   
      if (!contentText.trim()) {
        this.translatedContent = 'Could not extract text from the file. Please ensure the file contains readable text content.';
        this.isGenerating = false;
        return;
      }
 
      // Determine source format from file extension
      let sourceFormat = 'text';
      const fileName = this.uploadedFile.name.toLowerCase();
      if (fileName.endsWith('.docx')) sourceFormat = 'Word';
      else if (fileName.endsWith('.pdf')) sourceFormat = 'PDF';
      else if (fileName.endsWith('.md')) sourceFormat = 'Markdown';
     
      // Build parameters based on which format is enabled
      let targetFormat = '';
      //let targetFormatKey = '';
      let customization: any = {};
      let podcastStyle = this.podcastFormat;
      let speaker1Name = this.speaker1Name;
      let speaker1Voice = this.speaker1Voice;
      let speaker1Accent = this.speaker1Accent;
      let speaker2Name = this.speaker2Name;
      let speaker2Voice = this.speaker2Voice;
      let speaker2Accent = this.speaker2Accent;
     
      // Extract word limit from social media length if it's a social media post
      let wordLimit: string | undefined = undefined;
      if (this.formatSocialMedia && this.socialMediaLength.trim()) {
        // Extract numeric value from socialMediaLength (e.g., "200 words" -> "200")
        const match = this.socialMediaLength.match(/(\d+)/);
        if (match) {
          wordLimit = match[1];
        }
      }
     
      if (this.formatSocialMedia) {
        targetFormat = 'Social Media Post';
        //targetFormatKey = 'social_media_post';
        customization = {
          platform: this.socialMediaPlatform
        };
        if(this.socialMediaLength.trim()){
          customization.length = this.socialMediaLength;
        }
      } else if (this.formatWebpageReady) {
        targetFormat = 'Webpage Ready';
        //targetFormatKey = 'webpage_ready';
        customization = {
          optimization: 'web_display'
        };
      } else if (this.formatPlacemat) {
        targetFormat = 'Placemat';
        //targetFormatKey = 'placemat';
        customization = {
          layout: this.placematPageType
        };
        if(this.placematNumPages){
          customization.pages = this.placematNumPages;
        }
      } else if (this.formatPodcast) {
        targetFormat = 'Podcast';
        //targetFormatKey = 'podcast';
        customization = {
          format: this.podcastFormat
        };
        if(this.podcastAudience.trim()){
          customization.audience = this.podcastAudience;
        }

        // Map the discrete duration mode to a human-readable label and underlying range
        let durationLabel = '';
        //let durationRange = '';
        switch (this.podcastDurationMode) {
          case 'short':
            durationLabel = 'Short-Form 1-3 min';
            //durationRange = '1-3';
            this.podcastDuration = '1-3';
            break;
          case 'medium':
            durationLabel = 'Medium-Form 3-7 min';
            //durationRange = '3-7';
            this.podcastDuration = '3-7';
            break;
          case 'long':
          default:
            durationLabel = 'Long-Form 7-13 min';
            //durationRange = '7-13';
            this.podcastDuration = '7-13';
            break;
        }

        if (durationLabel) {
          customization.duration_label = durationLabel;
          customization.duration_range = this.podcastDuration;
        }

        if (this.podcastTheme) {
          customization.theme = this.podcastTheme;
        }
      }
 
      // Build prompt message - keep minimal, actual content goes in services
      let prompt = `Please adapt the following content to: ${targetFormat}`;

      // Build services object with format-specific parameters
      const services: any = {};
      services.format_translator = {
        customization: customization
      };

      // Add podcast-specific parameters
      if (this.formatPodcast) {
        services.format_translator.podcast_config = {
          style: podcastStyle,
          speaker1: {
            name: speaker1Name,
            voice: speaker1Voice,
            accent: speaker1Accent
          }
        };
        if (podcastStyle === 'dialogue') {
          services.format_translator.podcast_config.speaker2 = {
            name: speaker2Name,
            voice: speaker2Voice,
            accent: speaker2Accent
          };
        }
      }

      const payload: any = {
        messages: [{ role: 'user' as const, content: prompt }],
        content: contentText,
        source_format: sourceFormat,
        target_format: targetFormat,
        services,
        stream: true
      };
      
      if (wordLimit) {
        payload.word_limit = wordLimit;
      }

      console.log('[FormatTranslatorFlow] Sending JSON request:', {
        fileName: this.uploadedFile.name,
        sourceFormat,
        targetFormat: targetFormat,
        customization
      });
 
      this.streamSubscription = this.chatService.streamFormatTranslator(payload).subscribe({
        next: (data: any) => {
          console.log('[FormatTranslatorFlow] Received data:', data);
         
          if (data.type === 'progress') {
            console.log('[FormatTranslatorFlow] Progress:', data.message);
            // Update generation phase for podcast
            if (this.formatPodcast && data.message && data.message.toLowerCase().includes('podcast')) {
              this.generationPhase = 'podcast';
            } else if (this.formatPodcast && data.message && data.message.toLowerCase().includes('script')) {
              this.generationPhase = 'script';
            }
          }
          else if(data.type === 'placemat' && data.status === 'success')
          {
            
            if (data.url) {
              
              this.downloadPlacematUrl = data.url;
              this.showCreateRequestButton = false;
              this.translatedContent = 'Placemat generated successfully!';
              this._send_To_Chat = false;
             }
 
          }          
          else if (data.type === 'script') {
            // scripts are visible in modal unless Webpage Ready is selected
            // ACCUMULATE content (+=) to preserve ALL chunks, don't overwrite (=)
            if (this.formatWebpageReady) {
              this.hiddenTranslatedHtmlContent += (data.content || '');
            } else {
              this.translatedContent += (data.content || ''); // Changed to += to accumulate all chunks
            }
          } else if (data.type === 'complete') {
            if (data.audio) {
              console.log('[FormatTranslatorFlow] Audio received, creating blob');
              this.generationPhase = 'podcast';
              this.handleAudioResponse(data.audio);
            }
          } else if (data.type === 'content' && data.content) {
            // Handle content chunks from streaming response
            if (this.formatWebpageReady) {
              // accumulate but DO NOT show in modal
              this.hiddenTranslatedHtmlContent += data.content;
            } else {
              this.translatedContent += data.content;
            }
          }
          // ------- ADDED: handle backend-provided hosted HTML URL for Webpage Ready -------
          else if (data.type === 'content_url' && data.url) {
            // Backend provided a hosted HTML URL (e.g., S3/presigned or hosted HTML)
            this.translatedHtmlUrl = data.url;
            // Optionally set a user-facing message or keep the streamed content if any
           
            // keep hidden content as well (in case of fallback)
            if (this.formatWebpageReady && !this.hiddenTranslatedHtmlContent) {
              this.hiddenTranslatedHtmlContent = '';
            }
         
          } else if (data.url && !this.translatedHtmlUrl) {
            // Fallback: some responses include url without a type
            this.translatedHtmlUrl = data.url;
          }
          // -------------------------------------------------------------------------------
          else if (data.type === 'done') {
            
            // Stream complete - clean the final content
            if (this.formatWebpageReady) {
              // Clean hidden content and prepare a blob URL for opening when user clicks Download HTML Doc
              // const cleaned = this.cleanTranslatedContent(this.hiddenTranslatedHtmlContent || '');
              let cleaned = this.cleanHtmlContent(this.hiddenTranslatedHtmlContent);
              this.hiddenTranslatedHtmlContent = cleaned;
              
              // Append disclaimer to webpage content
              const disclaimer = `<hr style="margin-top: 40px; border: none; border-top: 1px solid #ccc;"><p style="font-size: 12px; color: #666; font-style: italic; margin-top: 20px;"><strong>Disclaimer:</strong> This content was generated with the assistance of artificial intelligence and is intended as an initial draft. It may incorporate references to broader industry or third-party sources that may not be exhaustive or fully aligned at a granular level. PwC professionals must review and validate the content to ensure accuracy, appropriate attribution, and suitability for internal or client-facing use, and remain fully responsible for the final version.</p>`;
              cleaned += disclaimer;
              
              // create blob url now so Download HTML Doc can immediately open it
              try {
                this.revokeTranslatedHtmlUrl();
                
                const htmlPayload = `<!DOCTYPE html>
                <html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"></head><body><body>${cleaned}</body>`;
                // ${cleaned.replace(/\n/g, '<br>')}</body></html>`;
                console.log("Generated HTML:", htmlPayload);
                const blob = new Blob([htmlPayload], { type: 'text/html;charset=utf-8' });
                this.translatedHtmlUrl = URL.createObjectURL(blob);
              } catch (e) {
                console.warn('[FormatTranslatorFlow] Could not create HTML blob URL', e);
              }
              // Do NOT expose full HTML content in modal — show completion message only
              // this.translatedContent = 'Click "Download HTML Doc" button to open the file';
              this.translatedContent = 'Translation Completed!';
            } else {
              this.translatedContent = this.cleanTranslatedContent(this.translatedContent);
            }
            console.log('[FormatTranslatorFlow] Stream done, cleaned content');
          } else if (data.error) {
            console.error('[FormatTranslatorFlow] Stream error:', data.error);
            // Sanitize error message to prevent XSS - Angular's [innerHTML] binding provides default XSS protection
            const escapedError = this.escapeHtmlSpecialChars(String(data.error));
            this.translatedContent = 'Sorry — we ran into an issue while processing your request.\nPlease try submitting it again.\nStill having trouble? Reach out to us via the Support option for assistance.';
            this.isGenerating = false;
          } else if (typeof data === 'string') {
            // Fallback for string data
            if (this.formatWebpageReady) this.hiddenTranslatedHtmlContent += data; else this.translatedContent += data;
          } else if (data.content) {
            // Fallback: if data has content property, use it
            if (this.formatWebpageReady) this.hiddenTranslatedHtmlContent += data.content; else this.translatedContent += data.content;
          } else {
            console.warn('[FormatTranslatorFlow] Unhandled data format:', data);
          }
        },
        error: (error: any) => {
          console.error('[FormatTranslatorFlow] Error:', error);
          // Sanitize error message to prevent XSS - Angular's [innerHTML] binding provides default XSS protection
          const errorMsg = error instanceof Error ? error.message : 'Unknown error';
          const escapedError = this.escapeHtmlSpecialChars(errorMsg);
          this.translatedContent = 'Sorry — we ran into an issue while processing your request.\nPlease try submitting it again.\nStill having trouble? Reach out to us via the Support option for assistance.';
          this.isGenerating = false;
        },
        complete: () => {
          console.log('[FormatTranslatorFlow] Translation complete');
         
          this.isGenerating = false;
         
          // Clean the translated content
          if (!this.formatWebpageReady && this.translatedContent) {
            this.translatedContent = this.cleanTranslatedContent(this.translatedContent);
          }

          if(this.translatedContent && this.downloadPlacematUrl)
          {
            
              console.log('create button');              
              this._send_To_Chat = false;
             }
          
          else if (!this.formatWebpageReady && (this.translatedContent || this.hasAudio)) {
            this.sendToChat();
          }

          // if (this.translatedContent || this.hasAudio) {
          //   this.sendToChat();
          // }
          // Note: Content is displayed in the modal, user can manually send to chat if needed
        }
      });
    } catch (error) {
      console.error('[FormatTranslatorFlow] Error reading file:', error);
      this.isGenerating = false;
    }
  }

  onPodcastDurationChange(value: number | string): void {
    const v = Number(value);
    this.podcastDurationSliderValue = v;

    if (v === 0) {
      this.podcastDurationMode = 'short';
      this.podcastDurationLabel = 'Short-Form 1-3 min';
    } else if (v === 1) {
      this.podcastDurationMode = 'medium';
      this.podcastDurationLabel = 'Medium-Form 3-7 min';
    } else {
      this.podcastDurationMode = 'long';
      this.podcastDurationLabel = 'Long-Form 7-13 min';
    }

    this.updatePodcastSliderBackground(this.podcastDurationSliderValue);
  }

  private updatePodcastSliderBackground(value: number): void {
    // Map 0,1,2 to 0%, 50%, 100% fill for the slider track
    let pct = 0;
    if (value === 1) {
      pct = 50;
    } else if (value >= 2) {
      pct = 100;
    }

    const clamped = Math.max(0, Math.min(100, pct));
    this.podcastDurationSliderBackground =
      `linear-gradient(to right, #FFAA72 0%, #FFAA72 ${clamped}%, #E5E7EB ${clamped}%, #E5E7EB 100%)`;
  }
 
  canTranslatePlacemat(): boolean {
  if (this.placematPageType !== 'custom') {
    return true;
  }

  const pages = Number(this.placematNumPages);

  return (
    Number.isInteger(pages) &&
    pages >= 1 &&
    pages <= 10
  );
}

  private handleAudioResponse(base64Audio: string): void {
    try {
      // Clean up previous audio if exists
      this.cleanupAudio();
     
      // Store base64 for creating chat-owned blob later
      this.audioBase64 = base64Audio;
     
      // Convert base64 to blob
      const binaryString = atob(base64Audio);
      const bytes = new Uint8Array(binaryString.length);
      for (let i = 0; i < binaryString.length; i++) {
        bytes[i] = binaryString.charCodeAt(i);
      }
      this.audioBlob = new Blob([bytes], { type: 'audio/mpeg' });
      this.audioUrl = URL.createObjectURL(this.audioBlob);
      this.hasAudio = true;
     
      console.log('[FormatTranslatorFlow] Audio URL created:', this.audioUrl);
    } catch (error) {
      console.error('[FormatTranslatorFlow] Error creating audio blob:', error);
    }
  }
 
  downloadAudio(): void {
    if (!this.audioUrl || !this.audioBlob) return;
   
    const link = document.createElement('a');
    link.href = this.audioUrl;
    link.download = `podcast-${Date.now()}.mp3`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  }
 
  downloadPlacematFile(): void {
    if (!this.downloadPlacematUrl) {
      console.warn('[Placemat] No download URL available');
      return;
    }
   
    // Use async IIFE to handle async/await
    const downloadAsync = async () => {
      try {
        const response = await fetch(this.downloadPlacematUrl);
        if (!response.ok) {
          throw new Error(`HTTP error! status: ${response.status}`);
        }
        const blob = await response.blob();
        
        // Wait for the download dialog to complete
        await this.downloadBlobWithSaveDialog(blob, 'Placemat.pptx', 'application/vnd.openxmlformats-officedocument.presentationml.presentation');
        
        // Mark download as successful after download completes
        this.downloadPlacematUrl = '';
        this.translatedContent = 'You may request support by clicking on the button below';
        this.showCreateRequestButton = true;
        setTimeout(() => { this._send_To_Chat = true; }, 10000);
      } catch (err) {
        console.error('Download error:', err);
        alert('Failed to download placemat. Please try again.');
        this.downloadPlacematUrl = '';
      }
    };

    downloadAsync();
  }

    openRequestForm() {
  this.showRequestForm = true;
}

openReadyToPublish() {
  this.tlFlowService.openFlow('ready-to-publish');
}

phoenixRdpLink = '';

onTicketCreated(event: {
  requestNumber: string;
  phoenixRdpLink: string;
}): void {
  // Validate and escape untrusted data before using in HTTP response
  try {
    this.validateAndEscapeUrl(event.phoenixRdpLink);
    const escapedRequestNumber = this.escapeHtmlSpecialChars(event.requestNumber);
    const escapedLink = this.escapeHtmlAttribute(event.phoenixRdpLink);
    this.phoenixRdpLink = event.phoenixRdpLink;
    console.log('Ticket created:', event.requestNumber);
    this.translatedContent = `Request created successfully! Your request number is: <a href="${escapedLink}" target="_blank" rel="noopener noreferrer">${escapedRequestNumber}</a>`.trim();
  } catch (error) {
    console.error('[FormatTranslatorFlow] Invalid ticket data:', error);
    this.translatedContent = 'Error processing request. Please try again.';
  }
  this.showRequestForm = false;
  this.showCreateRequestButton = false;
}

sendToChat(): void {
  // Send podcast result to chat window with audio player and download
  if (!this.translatedContent && !this.hasAudio) {
    console.warn('[FormatTranslatorFlow] No content to send to chat');
    return;
  }
  
  console.log('[FormatTranslatorFlow] sendToChat() - Content to send:', {
    contentLength: this.translatedContent.length,
    firstChars: this.translatedContent.substring(0, 100),
    hasAudio: this.hasAudio,
    timestamp: new Date().toISOString()
  });
   
    // Determine content type based on selected format
    let contentType: string;
    if (this.formatPodcast) {
      contentType = 'podcast';
    } else if (this.formatSocialMedia) {
      contentType = 'socialMedia';
    } else {
      contentType = 'article';
    }
    
    const topic = this.uploadedFile?.name || '';
   
    // Create metadata for the message
    const metadata: ThoughtLeadershipMetadata = {
      contentType: contentType as any,
      topic: topic,
      fullContent: this.translatedContent,
      showActions: true
    };
   
    // Add podcast-specific metadata if we have audio
    // Create a NEW blob URL for the chat message to own independently
    if (this.hasAudio && this.audioBase64) {
      try {
        // Convert base64 to a new blob that the chat message will own
        const binaryString = atob(this.audioBase64);
        const bytes = new Uint8Array(binaryString.length);
        for (let i = 0; i < binaryString.length; i++) {
          bytes[i] = binaryString.charCodeAt(i);
        }
        const chatAudioBlob = new Blob([bytes], { type: 'audio/mpeg' });
        const chatAudioUrl = URL.createObjectURL(chatAudioBlob);
       
        metadata.podcastAudioUrl = chatAudioUrl;
        metadata.podcastFilename = `${this.sanitizeFilename(topic)}_podcast.mp3`;
       
        console.log('[FormatTranslatorFlow] Created new audio URL for chat:', chatAudioUrl);
      } catch (error) {
        console.error('[FormatTranslatorFlow] Error creating chat audio blob:', error);
      }
    }
    // Send the translated content directly (preserving formatting)
    // Content will be formatted by the chat component's formatting methods
    let chatMessage = this.translatedContent;
    
    // Append disclaimer for social media posts or podcast
    if (this.formatSocialMedia || this.formatPodcast) {
      const disclaimer = '\n\n---\n\n*This content was generated with the assistance of artificial intelligence and is intended as an initial draft. It may incorporate references to broader industry or third-party sources that may not be exhaustive or fully aligned at a granular level. PwC professionals must review and validate the content to ensure accuracy, appropriate attribution, and suitability for internal or client-facing use, and remain fully responsible for the final version.*';
      chatMessage += disclaimer;
      metadata.fullContent += disclaimer;
    }
   
    // Send to chat via bridge
    console.log('[FormatTranslatorFlow] ===== Sending Podcast to Chat =====', {
      metadata: {
        contentType: metadata.contentType,
        topic: metadata.topic,
        showActions: metadata.showActions,
        hasPodcastUrl: !!metadata.podcastAudioUrl,
        podcastUrlLength: metadata.podcastAudioUrl?.length
      },
      messageLength: chatMessage.length,
      timestamp: new Date().toISOString()
    });
    this.tlChatBridge.sendToChat(chatMessage, metadata);
   
    // Close the dialog (this will cleanup the dialog's audio URL, but chat has its own)
    this.onClose();
  }
 
  private sanitizeFilename(filename: string): string {
    return filename.replace(/[^a-z0-9]/gi, '_').toLowerCase();
  }
 
  private cleanTranslatedContent(content: string): string {
    if (!content || content.length < 10) return content;

    let cleaned = content;
    const originalLength = content.length;

    // STEP 1: Only remove OBVIOUS metadata from LINE STARTS (minimal aggressive removal)
    cleaned = cleaned
      .replace(/^here is the (?:rewritten|converted|translated)/gim, '')
      .replace(/^output:\s*/gim, '')
      .replace(/^result:\s*/gim, '');

    // STEP 2: Remove obvious metadata-only LINES (not content lines)
    cleaned = cleaned
      .replace(/^word count:\s*\d+\s*words?$/gim, '')
      .replace(/^source format:\s*[^\n]+$/gim, '')
      .replace(/^target format:\s*[^\n]+$/gim, '');

    // STEP 3: Clean up excessive whitespace only
    cleaned = cleaned
      .replace(/\n{3,}/g, '\n\n') // Collapse multiple blank lines
      .trim();

    // STEP 4: Safety check - if we removed >30% of content, keep original
    const removedAmount = originalLength - cleaned.length;
    const removalPercent = (removedAmount / originalLength) * 100;
    
    if (removalPercent > 30 && originalLength > 200) {
      console.warn('[FormatTranslatorFlow] Cleaning removed', removalPercent.toFixed(1), '% - reverting to original');
      return content;
    }

    console.log('[FormatTranslatorFlow] Cleaned content. Removed:', removalPercent.toFixed(1) + '%');
    return cleaned;
  }
 
  downloadAsHTML(): void {
    
    // Prefer the hosted/blob URL prepared after streaming. If not available, build from hidden content.
    if (!this.translatedHtmlUrl && !this.hiddenTranslatedHtmlContent) {
       console.warn('[FormatTranslatorFlow] No content or URL available to open');
       return;
     }  
    // Close the Format Translator window and clear state   <<<< --- HERE
    this.tlFlowService.closeFlow();
    this.cancelStream();
    this.isGenerating = false;
    this.translatedContent = '';
    this.hiddenTranslatedHtmlContent = '';
     // If backend provided a hosted URL (preferred), open it directly
     if (this.translatedHtmlUrl) {
       // If it's a relative or blob/data URL it still opens correctly
       window.open(this.translatedHtmlUrl, '_blank');
       console.log('[FormatTranslatorFlow] Opened provided HTML URL in new tab:', this.translatedHtmlUrl);
       return;
     }
 
    // Fallback: wrap hiddenTranslatedHtmlContent into an HTML blob and open
    // Check if content already contains HTML tags - if so, use as-is to preserve formatting
    const contentToUse = this.hiddenTranslatedHtmlContent || this.translatedContent;
    const hasHtmlTags = /<[a-z][\s\S]*>/i.test(contentToUse);
    
    // Format content appropriately based on whether it contains HTML
    let bodyContent = '';
    if (hasHtmlTags) {
      // Content already has HTML formatting - preserve it
      bodyContent = contentToUse;
    } else {
      // Plain text - wrap paragraphs with <p> tags to preserve formatting
      const paragraphs = contentToUse.split(/\n\n+/);
      bodyContent = paragraphs
        .map(para => `<p>${para.replace(/\n/g, '<br>')}</p>`)
        .join('\n');
    }

    const htmlContent = `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Webpage Ready Content</title>
  <style>
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
    }
    
    body {
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, sans-serif;
      line-height: 1.6;
      max-width: 900px;
      margin: 0 auto;
      padding: 40px 20px;
      color: #333;
      background-color: #fff;
    }
    
    h1, h2, h3, h4, h5, h6 {
      color: #0066cc;
      margin-top: 1.5em;
      margin-bottom: 0.5em;
      font-weight: 600;
      line-height: 1.3;
    }
    
    h1 { font-size: 2em; }
    h2 { font-size: 1.75em; }
    h3 { font-size: 1.5em; }
    h4 { font-size: 1.25em; }
    h5 { font-size: 1.1em; }
    h6 { font-size: 1em; }
    
    p {
      margin-bottom: 1em;
      text-align: justify;
    }
    
    strong, b {
      font-weight: 700;
      color: #000;
    }
    
    em, i {
      font-style: italic;
    }
    
    u {
      text-decoration: underline;
    }
    
    a {
      color: #0066cc;
      text-decoration: none;
      word-break: break-word;
    }
    
    a:hover {
      text-decoration: underline;
    }
    
    ul, ol {
      margin-left: 2em;
      margin-bottom: 1em;
    }
    
    li {
      margin-bottom: 0.5em;
      line-height: 1.8;
    }
    
    blockquote {
      border-left: 4px solid #0066cc;
      padding-left: 1em;
      margin-left: 0;
      margin-bottom: 1em;
      color: #666;
      font-style: italic;
    }
    
    code {
      background-color: #f4f4f4;
      padding: 2px 6px;
      border-radius: 3px;
      font-family: 'Courier New', monospace;
      font-size: 0.9em;
    }
    
    pre {
      background-color: #f4f4f4;
      padding: 1em;
      border-radius: 4px;
      overflow-x: auto;
      margin-bottom: 1em;
    }
    
    pre code {
      background-color: transparent;
      padding: 0;
    }
    
    table {
      width: 100%;
      border-collapse: collapse;
      margin-bottom: 1em;
    }
    
    th, td {
      border: 1px solid #ddd;
      padding: 10px;
      text-align: left;
    }
    
    th {
      background-color: #f4f4f4;
      font-weight: 600;
    }
    
    hr {
      border: none;
      border-top: 1px solid #ddd;
      margin: 2em 0;
    }
    
    img {
      max-width: 100%;
      height: auto;
      display: block;
      margin: 1em 0;
    }
  </style>
</head>
<body>
${bodyContent}
</body>
</html>`;
 
    const blob = new Blob([htmlContent], { type: 'text/html;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    window.open(url, '_blank');
    setTimeout(() => URL.revokeObjectURL(url), 5000);
 
    console.log('[FormatTranslatorFlow] HTML opened in new tab (blob fallback)', { hasHtmlTags });
  }

  /**
   * Escape HTML special characters to prevent XSS attacks
   */
  private escapeHtmlSpecialChars(untrustedData: string): string {
    if (!untrustedData) return '';
    const div = document.createElement('div');
    div.textContent = untrustedData;
    return div.innerHTML;
  }

  /**
   * Escape data for use in HTML attributes
   */
  private escapeHtmlAttribute(untrustedData: string): string {
    if (!untrustedData) return '';
    return untrustedData
      .replace(/&/g, '&amp;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#x27;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;');
  }

  /**
   * Validate URL to prevent open redirect attacks
   */
  private validateAndEscapeUrl(urlString: string): void {
    if (!urlString) throw new Error('URL is empty');
    
    try {
      const url = new URL(urlString);
      
      if (!['http:', 'https:'].includes(url.protocol)) {
        throw new Error(`Invalid protocol: ${url.protocol}`);
      }
    } catch (error) {
      throw new Error(`URL validation failed: ${error instanceof Error ? error.message : 'Invalid URL'}`);
    }
  }

  private async downloadBlobWithSaveDialog(blob: Blob, filename: string, mimeTypeOverride?: string): Promise<void> {
    // Check if File System Access API is available (Chrome, Edge, Firefox)
    if ('showSaveFilePicker' in window) {
      try {
        const ext = filename.split('.').pop()?.toLowerCase() || '';
        let mimeType = mimeTypeOverride || blob.type || 'application/octet-stream';
        
        // Map extensions to proper MIME types if needed
        if (!mimeTypeOverride && (!blob.type || blob.type === 'application/octet-stream')) {
          switch (ext) {
            case 'pptx':
              mimeType = 'application/vnd.openxmlformats-officedocument.presentationml.presentation';
              break;
            case 'docx':
              mimeType = 'application/vnd.openxmlformats-officedocument.wordprocessingml.document';
              break;
            case 'xlsx':
              mimeType = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet';
              break;
            case 'pdf':
              mimeType = 'application/pdf';
              break;
          }
        }
        
        const handle = await (window as any).showSaveFilePicker({
          suggestedName: filename,
          types: [
            {
              description: `${ext.toUpperCase()} Files`,
              accept: { [mimeType]: [`.${ext}`] }
            }
          ]
        });
        const safeBlob = new Blob([await blob.arrayBuffer()], {
  type: 'application/octet-stream'
});
 
const writable = await handle.createWritable();
await writable.write(await safeBlob.arrayBuffer());
await writable.close();

      } catch (error: any) {
        if (error.name !== 'AbortError') {
          console.error('[FormatTranslator] Error saving file with dialog:', error);
          // Fallback to default download if dialog fails
          this.fallbackDownload(blob, filename);
        } else {
          console.log('[FormatTranslator] Save dialog cancelled by user');
        }
      }
    } else {
      // Fallback: use default download behavior for unsupported browsers
      this.fallbackDownload(blob, filename);
    }
  }

  private fallbackDownload(blob: Blob, filename: string): void {
  // ✅ Sanitize the filename
  const safeFilename = filename
   .replace(/[^a-zA-Z0-9._-]/g, '_')
   .replace(/_{2,}/g, '_')
   .replace(/^_+|_+$/g, '') || 'download';
  // ✅ Create a safe blob with correct MIME (optional, use blob.type if already safe)
  const safeBlob = new Blob([blob], { type: blob.type || 'application/octet-stream' });
  // ✅ Use FileSaver.js to trigger the download
  saveAs(safeBlob, safeFilename);
}
}
