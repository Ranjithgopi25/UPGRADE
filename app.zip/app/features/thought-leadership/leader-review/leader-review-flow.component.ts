import { Component, Input, Output, EventEmitter } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

// Standalone component for leader review flow
@Component({
  selector: 'app-leader-review-flow',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './leader-review-flow.component.html',
  styleUrls: ['./leader-review-flow.component.scss'],
  host: {
    '[class.side-by-side-right]': 'showSideBySide'
  }
})
export class LeaderReviewFlowComponent {
  // Input properties from parent component
  @Input() requestId: string = '';
  @Input() statusType: 'offering' | 'practice' = 'offering';
  @Input() requestData: any = null;
  @Input() showSideBySide: boolean = false;

  // Output events
  @Output() close = new EventEmitter<void>();
  @Output() reviewSubmitted = new EventEmitter<{
    requestId: string;
    statusType: 'offering' | 'practice';
    action: 'approve' | 'reject';
    reviewData: any;
  }>();
  
  // Section 1: Due Diligence Checklist
  dueDiligence = {
    fullyReviewed: false,
    agreeWithRiskAssessment: false
  };

  // Section 2: Additional Risk Review
  additionalRiskReview: string = '';
  riskReviewCategories = {
    ai: false,
    policiesAmericaInMotion: false,
    regulation: false,
    generalRiskReview: false,
    independenceConsiderations: false,
    pwcBuiltTechnology: false
  };

  // Section 3: Support Publication
  supportPublication: string = '';
  supportPublicationRationale: string = '';

  // Section 4: MCX Editorial Support
  requestMcxEditorialSupport: string = '';
  requestMcxCreativeSupport: string = '';

  constructor() {}

  onClose(): void {
    console.log('Closing leader review form');
    this.close.emit();
  }

  /**
   * Handle support publication change and reset MCX fields if needed
   */
  onSupportPublicationChange(value: string): void {
    // Reset MCX request fields and rationale when support publication changes
    this.requestMcxEditorialSupport = '';
    this.requestMcxCreativeSupport = '';
    this.supportPublicationRationale = '';
  }

  /**
   * Handle additional risk review change and reset risk review categories
   */
  onAdditionalRiskReviewChange(value: string): void {
    // Reset all risk review categories when additional risk review selection changes
    this.riskReviewCategories = {
      ai: false,
      policiesAmericaInMotion: false,
      regulation: false,
      generalRiskReview: false,
      independenceConsiderations: false,
      pwcBuiltTechnology: false
    };
  }

  /**
   * Approve the request after review
   */
  approveLeaderReview(): void {
    const reviewData = {
      dueDiligence: this.dueDiligence,
      additionalRiskReview: this.additionalRiskReview,
      riskReviewCategories: this.riskReviewCategories,
      supportPublication: this.supportPublication,
      supportPublicationRationale: this.supportPublicationRationale,
      requestMcxEditorialSupport: this.requestMcxEditorialSupport,
      requestMcxCreativeSupport: this.requestMcxCreativeSupport
    };

    console.log('Approving leader review for request:', this.requestId, reviewData);
    this.reviewSubmitted.emit({
      requestId: this.requestId,
      statusType: this.statusType,
      action: 'approve',
      reviewData
    });
  }

  /**
   * Reject the request after review
   */
  rejectLeaderReview(): void {
    const reviewData = {
      dueDiligence: this.dueDiligence,
      additionalRiskReview: this.additionalRiskReview,
      riskReviewCategories: this.riskReviewCategories,
      supportPublication: this.supportPublication,
      supportPublicationRationale: this.supportPublicationRationale,
      requestMcxEditorialSupport: this.requestMcxEditorialSupport,
      requestMcxCreativeSupport: this.requestMcxCreativeSupport
    };

    console.log('Rejecting leader review for request:', this.requestId, reviewData);
    this.reviewSubmitted.emit({
      requestId: this.requestId,
      statusType: this.statusType,
      action: 'reject',
      reviewData
    });
  }

  submitLeaderReview(): void {
    const reviewData = {
      dueDiligence: this.dueDiligence,
      additionalRiskReview: this.additionalRiskReview,
      riskReviewCategories: this.riskReviewCategories,
      supportPublication: this.supportPublication,
      supportPublicationRationale: this.supportPublicationRationale,
      requestMcxEditorialSupport: this.requestMcxEditorialSupport,
      requestMcxCreativeSupport: this.requestMcxCreativeSupport
    };

    // Determine action based on supportPublication value
    const action: 'approve' | 'reject' = this.supportPublication === 'yes' ? 'approve' : 'reject';

    console.log('Submitting leader review for request:', this.requestId, 'with action:', action, reviewData);
    this.reviewSubmitted.emit({
      requestId: this.requestId,
      statusType: this.statusType,
      action: action,
      reviewData
    });
  }

  /**
   * Validate that all required fields are completed
   */
  areAllFieldsValid(): boolean {
    // Check due diligence checklist
    if (!this.dueDiligence.fullyReviewed && !this.dueDiligence.agreeWithRiskAssessment) {
      return false;
    }

    // Check additional risk review
    if (!this.additionalRiskReview) {
      return false;
    }

    // If additional risk review is yes, at least one category must be selected
    if (this.additionalRiskReview === 'yes') {
      const hasSelectedCategory = 
        this.riskReviewCategories.ai || 
        this.riskReviewCategories.policiesAmericaInMotion || 
        this.riskReviewCategories.regulation || 
        this.riskReviewCategories.generalRiskReview ||
        this.riskReviewCategories.independenceConsiderations ||
        this.riskReviewCategories.pwcBuiltTechnology;
      
      if (!hasSelectedCategory) {
        return false;
      }
    }

    // Check support publication
    if (!this.supportPublication) {
      return false;
    }

    // If support publication is "not at this time", rationale must be provided
    if (this.supportPublication === 'not_at_this_time' && !this.supportPublicationRationale.trim()) {
      return false;
    }

    // Only validate MCX fields if support publication is "yes"
    if (this.supportPublication === 'yes') {
      // Check MCX editorial support
      if (!this.requestMcxEditorialSupport) {
        return false;
      }

      // Check MCX creative support
      if (!this.requestMcxCreativeSupport) {
        return false;
      }
    }

    return true;
  }
}
