import { Component, OnInit, OnDestroy, ChangeDetectorRef, ViewChild } from '@angular/core';

import { FormsModule } from '@angular/forms';
import { Subject, Subscription, takeUntil } from 'rxjs';
import { TlFlowService } from '../../../core/services/tl-flow.service';
import { ChatService } from '../../../core/services/chat.service';
import { AuthFetchService } from '../../../core/services/auth-fetch.service';
import { TlChatBridgeService } from '../../../core/services/tl-chat-bridge.service';
import { ThoughtLeadershipMetadata, Message } from '../../../core/models';
import { FileUploadComponent } from '../../../shared/ui/components/file-upload/file-upload.component';
import { environment } from '../../../../environments/environment';
import { toSnakeCase } from '../../../core/utils/string.utils';

interface EditForm {
  outlineFile: File | null;
  supportingDocsFile: File | null;
  supportingDocsFiles: File[]; // Array for multiple supporting documents
}

@Component({
    selector: 'app-draft-content-flow',
    imports: [FormsModule, FileUploadComponent],
    templateUrl: './draft-content-flow.component.html',
    styleUrls: ['./draft-content-flow.component.scss']
})
export class DraftContentFlowComponent implements OnInit, OnDestroy {
  @ViewChild('outlineFileUpload') outlineFileUpload?: FileUploadComponent;
  maxWordLimit = 10000;
  wordLimitError = '';
  isGenerating = false;
  draftContent = '';
  outlineFileUploadError = false;
  
  // Satisfaction feedback properties
  showSatisfactionPrompt = false;
  showImprovementInput = false;
  improvementRequestText = '';
  iterationCount = 0;
  
  // Store original draft parameters for improvement iterations
  originalContentType = '';
  originalWordLimit = '';
  originalAudienceTone = '';
  originalOutlineDoc = '';
  originalSupportingDoc = '';
  originalUseFactivaResearch = false;

  // Topic input
  topicInput = '';

  // Outline text input validation
  outlineTextInputError = '';
  outlineFileWordsError = '';
  private readonly MIN_OUTLINE_WORDS = 25;
  private readonly MIN_OUTLINE_WORDS_ARTICLE = 25;

  // Content type selection - exclusive toggles (only ONE can be ON)
  contentTypeArticle = false;
  contentTypeBlog = false;
  contentTypeExecutiveBrief = false;
  contentTypeWhitePaper = false;

  // Basic fields
  wordLimit = '';
    onWordLimitChange(value: any): void {
      if (value && Number(value) > this.maxWordLimit) {
        this.wordLimitError = `Word limit cannot exceed ${this.maxWordLimit}.*`;
        //alert(this.wordLimitError);
        // Optionally, reset the value
        this.wordLimit = this.maxWordLimit.toString();
      } else {
        this.wordLimitError = '';
      }
    }
    
  audienceTone = '';
  outlineTextInput = '';

  // File uploads
    formData: EditForm = {
    outlineFile: null,
    supportingDocsFile: null,
    supportingDocsFiles: []
  };
  originalContent: string = '';
  originalcontentoutlineText: string = '';
  
  // Supporting documents multi-upload properties
  MAX_SUPPORTING_DOCS = 5;
  MAX_TOKEN_LIMIT = 50000;
  supportingDocsTokenCount = 0;
  supportingDocsError = '';

  // Research toggle (Yes/No)
  conductResearch = false;

  // Research conditional fields
  researchTopics = '';

  // Research sources (4 toggles)
  pwcContentLink = false;
  pwcProprietaryResearch = true;
  pwcLicensedThirdParty = true;
  externalResearch = true;

  // Research documents multi-upload properties
  MAX_RESEARCH_DOCS = 5;
  researchDocumentFiles: File[] = [];
  researchDocsError = '';
  researchDocInstructions = '';
  researchLinks = '';
  supportingLinks = '';
  //outlineTextInput = '';

  // Select specific PwC sources (appears if PwC sources selected)
  selectSpecificPwcSources = false;

  // PwC Proprietary Research Sources
  allPwcProprietarySources = true;
  pwcSource1 = false;
  pwcSource2 = false;
  pwcSource3 = false;
  pwcSource4 = false;

pwcProprietarySources = [
    { name: 'PwC industry edge', selected: true },
    { name: 'PwC.com', selected: true },
    { name: 'PwC insights', selected: true },
    { name: 's+b journal', selected: true },
    { name: 'Executive leadership hub', selected: true },
    { name: 'The exchange', selected: true },
    { name: 'PwC connected source', selected: true },
    { name: 'PwC benchmarking', selected: true },
    //{ name: 'Insights Factory', selected: true },
    //{ name: 'PwC Intelligence', selected: true },
    //{ name: 'C-Suite Connection Program', selected: true },
    //{ name: 'Viewpoint', selected: true },
    //{ name: 'Analyst and Advisor Relations', selected: true },
    //{ name: 'Assurance Benchmarking Tools', selected: true },
    //{ name: 'Policy on Demand', selected: true },
    //{ name: 'Tax Source', selected: true },
    //{ name: 'FFG Benchmarking', selected: true },
    //{ name: 'Client Success Stories', selected: true },
    //{ name: 'Inside Industries', selected: true },
    //{ name: 'Value Store', selected: true }
  ];

  // PwC Third Party Tools
  allPwcThirdPartySources = true;
  pwcThirdPartySource1 = false;
  pwcThirdPartySource2 = false;
  pwcThirdPartySource3 = false;
  pwcThirdPartySource4 = false;

pwcThirdPartySources = [
  { name: 'Factiva, WSJ, Dow Jones', selected: true },
    { name: 'S&P Global- Capital IQ Xpressfeed', selected: true },
    { name: 'IBIS World', selected: true },
    { name: 'BoardEx', selected: true },
    // { name: 'S&P Global- Connect', selected: true },
    // { name: 'Audit Analytics', selected: true },
    // { name: 'S&P Global- SNL Insurance', selected: true },
    // { name: 'Claritas', selected: true },
    // { name: 'Equifax', selected: true },
    // { name: 'Equifax IXI', selected: true },
    // { name: 'Definitive Healthcare Provider Database', selected: true },
    // { name: 'Sg2 Health Care Intelligence', selected: true },
    // //{ name: 'Strata Market Insights', selected: true },
    // //{ name: 'CompanyIQ', selected: true },
    // { name: 'Global Data(Retail)', selected: true },
    // { name: 'Technology Business Review', selected: true },
    
    // //{ name: 'IDC', selected: true },
    // { name: 'CFRA Industry Surveys', selected: true }
];


  // Additional guidelines
  additionalGuidelines = '';

  private destroy$ = new Subject<void>();
  private streamSubscription?: Subscription;

  constructor(
    public tlFlowService: TlFlowService,
    private chatService: ChatService,
    private tlChatBridge: TlChatBridgeService,
    private cdr: ChangeDetectorRef,
    private authFetchService: AuthFetchService
  ) { }

  ngOnInit(): void {
    // Subscribe to preselected content type
    this.tlFlowService.preselectedContentType$
      .pipe(takeUntil(this.destroy$))
      .subscribe((contentType: string | null) => {
        if (contentType) {
          this.preselectContentType(contentType);
        }
      });

    // Subscribe to preselected topic
    this.tlFlowService.preselectedTopic$
      .pipe(takeUntil(this.destroy$))
      .subscribe((topic: string | null) => {
        if (topic !== null) {
          this.topicInput = topic;
        }
      });

    this.tlFlowService.activeFlow$
      .pipe(takeUntil(this.destroy$))
      .subscribe((flow: any) => {
        if (flow === 'draft-content') {
          // Get preselected values before reset
          const preselectedType = this.tlFlowService.preselectedContentType;
          const preselectedTopic = this.tlFlowService.preselectedTopic;
          
          console.log('[DraftContentFlow] Flow activated, preselected values:', { preselectedType, preselectedTopic });
          
          // Always reset the form
          this.resetForm();
          
          // Then reapply the preselected content type if it exists
          if (preselectedType) {
            this.preselectContentType(preselectedType);
          }
          // Set topic after reset and content type
          if (preselectedTopic) {
            console.log('[DraftContentFlow] Setting topicInput to:', preselectedTopic);
            this.topicInput = preselectedTopic;
            this.cdr.detectChanges();
          }
        }
      });
  }

  private preselectContentType(contentType: string): void {
    // Reset all content types first
    this.contentTypeArticle = false;
    this.contentTypeBlog = false;
    this.contentTypeExecutiveBrief = false;
    this.contentTypeWhitePaper = false;

    // Set the selected content type
    switch (contentType) {
      case 'Article':
        this.contentTypeArticle = true;
        break;
      case 'Blog':
        this.contentTypeBlog = true;
        break;
      case 'Executive Brief':
        this.contentTypeExecutiveBrief = true;
        break;
      // White Paper intentionally left disabled
    }
  }

  ngOnDestroy(): void {
    this.cancelStream();
    this.destroy$.next();
    this.destroy$.complete();
  }

  // Copy to Clipboard functionality removed

  private getContentTypeLabel(contentType: string): string {
    const labels: { [key: string]: string } = {
      'article': 'Article',
      'blog': 'Social Media',
      'white_paper': 'White Paper',
      'executive_brief': 'Executive Brief',
      'podcast': 'Podcast'
    };
    return labels[contentType] || contentType;
  }

  private cancelStream(): void {
    if (this.streamSubscription) {
      console.log('[DraftContentFlow] Cancelling active stream');
      this.streamSubscription.unsubscribe();
      this.streamSubscription = undefined;
      this.isGenerating = false;
    }
  }

  private formatContentWithSpacing(content: string): string {
  // Ultra-compact formatting - minimal line breaks
  let formatted = content
    // Replace multiple newlines with single newline
    .replace(/\n{2,}/g, '\n')
    // Remove line breaks within paragraphs (join lines)
    .replace(/([^\n-*#\d])\n([^\n-*#\d])/g, '$1 $2')
    // Add single spacing before headers
    .replace(/([^\n])\n(#{1,6}\s)/g, '$1\n$2')
    // Add single spacing before lists
    .replace(/([^\n-*\d])\n([-*]\s)/g, '$1\n$2')
    .replace(/([^\n\d])\n(\d+\.\s)/g, '$1\n$2')
    .trim();

  return formatted;
}
  get isOpen(): boolean {
    return this.tlFlowService.currentFlow === 'draft-content';
  }

  onClose(): void {
    this.resetForm();
    this.cancelStream();
    this.tlFlowService.closeFlow();
  }

  back(): void{
    this.resetForm();
    this.cancelStream();
    this.tlFlowService.closeFlow();
    this.tlFlowService.openGuidedDialog();
  }

  resetForm(): void {
    this.topicInput = '';
    this.contentTypeArticle = false;
    this.contentTypeBlog = false;
    this.contentTypeExecutiveBrief = false;
    this.contentTypeWhitePaper = false;
    this.wordLimit = '';
    this.audienceTone = '';
    this.outlineTextInputError = '';
    this.outlineFileWordsError = '';
    this.outlineFileUploadError = false;
      this.formData = {
      outlineFile: null,
      supportingDocsFile: null,
      supportingDocsFiles: []
    };
    this.supportingDocsTokenCount = 0;
    this.supportingDocsError = '';
    this.supportingLinks = '';
    this.conductResearch = false;
    this.clearResearchFields();
    this.additionalGuidelines = '';
    this.draftContent = '';
    this.outlineTextInput = '';
    this.allPwcProprietarySources = true;
    this.allPwcThirdPartySources = true;
    this.showSatisfactionPrompt = false;
    this.showImprovementInput = false;
    this.improvementRequestText = '';
    this.iterationCount = 0;
    this.isGenerating = false;
    // Reset all proprietary sources array to selected (ON by default)
  this.pwcProprietarySources.forEach(source => source.selected = true);

  // Reset all third party sources array to selected (ON by default)
  this.pwcThirdPartySources.forEach(source => source.selected = true);
  }

  private clearResearchFields(): void {
    this.researchTopics = '';
    this.pwcContentLink = false;
    this.pwcProprietaryResearch = true;
    this.pwcLicensedThirdParty = true;
    this.externalResearch = true;
    this.researchDocumentFiles = [];
    this.researchDocsError = '';
    this.researchLinks = '';
    this.researchDocInstructions = '';
    this.supportingLinks = '';
    this.selectSpecificPwcSources = false;
    this.clearPwcSources();
  }

  private clearPwcSources(): void {
    this.allPwcProprietarySources = true;
    this.pwcSource1 = false;
    this.pwcSource2 = false;
    this.pwcSource3 = false;
    this.pwcSource4 = false;
    this.allPwcThirdPartySources = true;
    this.pwcThirdPartySource1 = false;
    this.pwcThirdPartySource2 = false;
    this.pwcThirdPartySource3 = false;
    this.pwcThirdPartySource4 = false;
  }

  onContentTypeToggle(type: string, newValue: boolean): void {
    // Disallow White Paper selection
    if (type === 'white-paper') {
      this.contentTypeWhitePaper = false;
      return;
    }

    // Ensure only ONE content type is ON at a time (exclusive selection)
    if (newValue) {
      switch (type) {
        case 'article':
          this.contentTypeBlog = false;
          this.contentTypeExecutiveBrief = false;
          break;
        case 'blog':
          this.contentTypeArticle = false;
          this.contentTypeExecutiveBrief = false;
          break;
        case 'executive-brief':
          this.contentTypeArticle = false;
          this.contentTypeBlog = false;
          break;
      }
      // Always force white paper off
      this.contentTypeWhitePaper = false;
      
      // Reset outline when switching content type (minimum word requirement changed)
      this.outlineTextInput = '';
      
      // If there's an uploaded file, re-validate it against the new content type
      if (this.formData.outlineFile) {
        this.onOutlineFileSelected(this.formData.outlineFile);
      } else {
        // No file uploaded, clear the error
        this.outlineTextInputError = '';
      }
    }
  }

  onResearchToggle(value: boolean): void {
    this.conductResearch = value;
    if (!value) {
      this.clearResearchFields();
    }
  }

  async onOutlineFileSelected(file: File): Promise<void> {
    // Validate file format - only .doc, .docx, .pdf, .txt allowed
    const acceptedFormats = ['.doc', '.docx', '.pdf', '.txt'];
    const fileExtension = file.name.substring(file.name.lastIndexOf('.')).toLowerCase();
    const isValidFormat = acceptedFormats.includes(fileExtension);
    
    if (!isValidFormat) {
      console.warn(`[DraftContentFlow] Invalid outline file format: ${file.name}. Accepted formats: .doc, .docx, .pdf, .txt`);
      this.outlineFileUploadError = true;
      // Reset the file upload component to prevent invalid file from being stored
      if (this.outlineFileUpload) {
        this.outlineFileUpload.reset();
      }
      return;
    }
    
    this.outlineFileUploadError = false;
    this.formData.outlineFile = file;

    // Extract text and validate word count
    try {
      const extractedText = await this.extractFileText(file);
      const wordCount = extractedText.trim().split(/\s+/).length;
      const minOutlineWords = this.contentTypeArticle ? this.MIN_OUTLINE_WORDS_ARTICLE : this.MIN_OUTLINE_WORDS;
      
      if (wordCount < minOutlineWords) {
        this.outlineFileWordsError = `Outline must contain at least ${minOutlineWords} words. Current: ${wordCount} words.`;
      } else {
        this.outlineFileWordsError = '';
      }
    } catch (error) {
      console.error('[DraftContentFlow] Error extracting outline file text:', error);
      this.outlineFileWordsError = 'Error reading file. Please try again.';
    }
  }

  onOutlineFileRemoved(): void {
    this.formData.outlineFile = null;
    // Clear errors when file is removed
    this.outlineFileWordsError = '';
    this.outlineTextInputError = '';
  }

  onSupportingDocsFileSelected(file: File): void {
    this.formData.supportingDocsFile = file;

  //   if (file.length > 3) {
  //   this.formData.supportingDocsFile = file.slice(0, 3);
  //   alert("You can upload a maximum of 3 supporting documents. Only the first 3 were accepted.");
  // } else {
  //   this.formData.supportingDocsFile = file;
  // }

  }

  onOutlineTextInputChange(value: string): void {
    if (value && value.trim()) {
      const wordCount = value.trim().split(/\s+/).length;
      const minOutlineWords = this.contentTypeArticle ? this.MIN_OUTLINE_WORDS_ARTICLE : this.MIN_OUTLINE_WORDS;
      if (wordCount < minOutlineWords) {
        this.outlineTextInputError = `Outline must contain at least ${minOutlineWords} words. Current: ${wordCount} words.`;
      } else {
        this.outlineTextInputError = '';
      }
    } else {
      this.outlineTextInputError = '';
    }
  }

  // Handle multiple supporting documents upload
  onSupportingDocsFilesChange(event: Event): void {
    const input = event.target as HTMLInputElement;
    if (input.files && input.files.length > 0) {
      const filesArray = Array.from(input.files);
      
      // Check if adding these files would exceed max
      const totalFiles = this.formData.supportingDocsFiles.length + filesArray.length;
      if (totalFiles > this.MAX_SUPPORTING_DOCS) {
        const availableSlots = this.MAX_SUPPORTING_DOCS - this.formData.supportingDocsFiles.length;
        if (availableSlots > 0) {
          this.formData.supportingDocsFiles.push(...filesArray.slice(0, availableSlots));
          this.supportingDocsError = `Only ${availableSlots} file(s) were added. Maximum of ${this.MAX_SUPPORTING_DOCS} files allowed.`;
        } else {
          this.supportingDocsError = `Maximum of ${this.MAX_SUPPORTING_DOCS} supporting documents already reached.`;
        }
      } else {
        this.formData.supportingDocsFiles.push(...filesArray);
        this.supportingDocsError = '';
      }
      
      // Reset the input so the same file can be selected again
      input.value = '';
      
      // Validate token count
      this.validateSupportingDocsTokenCount();
    }
  }

  // Remove a supporting document
  removeSupportingDoc(index: number): void {
    this.formData.supportingDocsFiles.splice(index, 1);
    this.supportingDocsError = '';
    this.validateSupportingDocsTokenCount();
  }

  // Validate token count for supporting documents
  private async validateSupportingDocsTokenCount(): Promise<void> {
    if (this.formData.supportingDocsFiles.length === 0) {
      this.supportingDocsTokenCount = 0;
      return;
    }

    try {
      // Extract text from all supporting documents
      const extractionPromises = this.formData.supportingDocsFiles.map(file => 
        this.extractFileText(file)
      );
      
      const extractedTexts = await Promise.all(extractionPromises);
      const combinedText = extractedTexts.join('\n\n');
      
      // Approximate token count (roughly 4 characters per token)
      const estimatedTokens = Math.ceil(combinedText.length / 4);
      this.supportingDocsTokenCount = estimatedTokens;
      
      // Check if exceeds limit
      if (estimatedTokens > this.MAX_TOKEN_LIMIT) {
        // Remove the last file and revalidate
        const removedFile = this.formData.supportingDocsFiles.pop();
        this.supportingDocsError = `Token limit exceeded (${estimatedTokens}/${this.MAX_TOKEN_LIMIT}). File "${removedFile?.name}" was removed.`;
        await this.validateSupportingDocsTokenCount();
      }
    } catch (error) {
      console.error('Error validating token count:', error);
    }
  }

  onResearchDocumentsFilesChange(event: Event): void {
    const input = event.target as HTMLInputElement;
    if (input.files && input.files.length > 0) {
      const filesArray = Array.from(input.files);
      
      // Check if adding these files would exceed max
      const totalFiles = this.researchDocumentFiles.length + filesArray.length;
      if (totalFiles > this.MAX_RESEARCH_DOCS) {
        const availableSlots = this.MAX_RESEARCH_DOCS - this.researchDocumentFiles.length;
        if (availableSlots > 0) {
          this.researchDocumentFiles.push(...filesArray.slice(0, availableSlots));
          this.researchDocsError = `Only ${availableSlots} file(s) were added. Maximum of ${this.MAX_RESEARCH_DOCS} files allowed.`;
        } else {
          this.researchDocsError = `Maximum of ${this.MAX_RESEARCH_DOCS} research documents already reached.`;
        }
      } else {
        this.researchDocumentFiles.push(...filesArray);
        this.researchDocsError = '';
      }
      
      // Reset the input so the same file can be selected again
      input.value = '';
    }
  }

  removeResearchDoc(index: number): void {
    this.researchDocumentFiles.splice(index, 1);
    this.researchDocsError = '';
  }

    onAllPwcProprietaryToggle(value: boolean): void {
    this.pwcProprietarySources.forEach(source => source.selected = value);
  }

  onPwcProprietarySourceChange(): void {
    this.allPwcProprietarySources = this.pwcProprietarySources.every(s => s.selected);
  }

  onAllPwcThirdPartySourcesChange(): void {
    const value = this.allPwcThirdPartySources;
    this.pwcThirdPartySource1 = value;
    this.pwcThirdPartySource2 = value;
    this.pwcThirdPartySource3 = value;
    this.pwcThirdPartySource4 = value;
  }

  // onPwcProprietarySourceChange(): void {
  //   // Sync "All" checkbox with individual sources
  //   // Use setTimeout to ensure Angular has updated the bound values first
  //   setTimeout(() => {
  //     this.allPwcProprietarySources = this.pwcSource1 && this.pwcSource2 && this.pwcSource3 && this.pwcSource4;
  //   });
  // }

  // onPwcThirdPartySourceChange(): void {
  //   // Sync "All" checkbox with individual sources
  //   // Use setTimeout to ensure Angular has updated the bound values first
  //   setTimeout(() => {
  //     this.allPwcThirdPartySources = this.pwcThirdPartySource1 && this.pwcThirdPartySource2 && this.pwcThirdPartySource3 && this.pwcThirdPartySource4;
  //   });
  // }

  onAllPwcThirdPartyToggle(value: boolean): void {
  this.allPwcThirdPartySources = value;
  this.pwcThirdPartySources.forEach(source => source.selected = value);
}


onPwcThirdPartySourceChange(): void {
  this.allPwcThirdPartySources = this.pwcThirdPartySources.every(s => s.selected);
}

  get showPwcSourceSelection(): boolean {
    return this.conductResearch &&
      this.selectSpecificPwcSources &&
      (this.pwcProprietaryResearch || this.pwcLicensedThirdParty);
  }

  get invalidSupportingLinks(): boolean {
    if (!this.supportingLinks) return false;

    return this.supportingLinks
      .split('\n')
      .map(l => l.trim())
      .filter(Boolean)
      .some(link => !/^https?:\/\/.+/.test(link));
  }

  get invalidLinks(): boolean {
    if (!this.researchLinks) return false;

    return this.researchLinks
      .split('\n')
      .map(l => l.trim())
      .filter(Boolean)
      .some(link => !/^https?:\/\/.+/.test(link));
  }

  get canGenerateDraft(): boolean {
    // Must have topic
    if (!this.topicInput.trim()) return false;

    // Must have selected a content type
    if (!this.contentTypeArticle && !this.contentTypeBlog &&
      !this.contentTypeExecutiveBrief && !this.contentTypeWhitePaper) {
      return false;
    }

     // Must have outline file
      if (!this.formData.outlineFile && !this.outlineTextInput.trim()) {
        return false;
      }
      if (this.outlineTextInputError) return false;
      if (this.outlineFileWordsError) return false;

      // Also disable if there are invalid supporting links
      if (this.invalidSupportingLinks) {
          return false;
      }
    // Must have audience and tone
    if (!this.audienceTone.trim()) return false;

    // If research is enabled, must have research topics AND at least one source
    if (this.conductResearch) {
      if (!this.researchTopics.trim()) {
        return false;
      }
      // If "PwC Content/Link" is toggled ON, require either documents or links
      if (this.pwcContentLink) {
        const hasDocuments = this.researchDocumentFiles.length > 0;
        const hasLinks = this.researchLinks && this.researchLinks.trim().length > 0;
        
        // Disable if toggle is ON but neither documents nor links are provided
        if (!hasDocuments && !hasLinks) {
          return false;
        }
        
        // Also disable if there are invalid links
        if (this.invalidLinks) {
          return false;
        }
      } else {
        // If research is enabled but pwcContentLink is OFF, must have at least one other research source
        if (!this.pwcProprietaryResearch &&
          !this.pwcLicensedThirdParty && !this.externalResearch) {
          return false;
        }
      }
    }

    return true;
  }

  private async extractFileText(file: File): Promise<string> {
    const formData = new FormData();
    formData.append('file', file);

    // Get API URL from environment (supports runtime config via window._env)
    const apiUrl = (window as any)._env?.apiUrl || environment.apiUrl || '';
    const response = await this.authFetchService.authenticatedFetchFormData(`${apiUrl}/api/v1/export/extract-text`, {
      method: 'POST',
      body: formData
    });

    if (!response.ok) {
      throw new Error('Failed to extract text from file');
    }

    const data = await response.json();
    return data.text || '';
  }

  async generateDraftContent(): Promise<void> {
    if (!this.canGenerateDraft) {
      console.error('Form validation failed');
      return;
    }
    // Validate word limit before generating
    if (this.wordLimit && Number(this.wordLimit) > this.maxWordLimit) {
      this.wordLimitError = `Word limit cannot exceed ${this.maxWordLimit}.`;
      return;
    }

    this.isGenerating = true;
    this.draftContent = '';

    try {
      // Determine selected content type
      let contentType = '';
      let contentTypeKey = '';
      if (this.contentTypeArticle) {
        contentType = 'Article';
        contentTypeKey = 'article';
      } else if (this.contentTypeBlog) {
        contentType = 'Blog';
        contentTypeKey = 'blog';
      } else if (this.contentTypeExecutiveBrief) {
        contentType = 'Executive Brief';
        contentTypeKey = 'executive_brief';
      } else if (this.contentTypeWhitePaper) {
        contentType = 'White Paper';
        contentTypeKey = 'white_paper';
      }

      // Build the original prompt text for messages field
      let prompt = `Please draft the following type of content:\n\n`;
      prompt += `Content Type: ${contentType}\n`;
      prompt += `Topic: ${this.topicInput}\n`;
      if (String(this.wordLimit).trim()) {
        prompt += `Word Limit: ${this.wordLimit}\n`;
      }
      prompt += `Audience/Tone: ${this.audienceTone}\n`;

      // Extract outline text
      let contentoutlineText = '';
      let outlineType: 'text' | 'file' = 'text';
      
      if (this.formData.outlineFile) {
        console.log('Extracting outline file text');
        const outlineText = await this.extractFileText(this.formData.outlineFile);
        contentoutlineText = outlineText;
        this.originalcontentoutlineText = contentoutlineText;
        outlineType = 'file';
        prompt += `\nInitial Outline/Concept:\n${this.originalcontentoutlineText}\n`;
      } else if (this.outlineTextInput.trim()) {
        contentoutlineText = this.outlineTextInput.trim();
        this.originalcontentoutlineText = contentoutlineText;
        outlineType = 'text';
        prompt += `\nInitial Outline/Concept:\n${this.originalcontentoutlineText}\n`;
      }

      // Extract supporting document text
      let contentText = '';
      let supportingDocsContent = '';
      
      // Handle multiple supporting documents
      if (this.formData.supportingDocsFiles.length > 0) {
        const extractionPromises = this.formData.supportingDocsFiles.map((file, index) => 
          this.extractFileText(file).then(text => ({
            filename: file.name,
            text: text,
            index: index + 1
          }))
        );
        
        const extractedDocs = await Promise.all(extractionPromises);
        
        // Combine all documents with separators
        supportingDocsContent = extractedDocs
          .map(doc => `--- Supporting Document ${doc.index}: ${doc.filename} ---\n${doc.text}`)
          .join('\n\n');
        
        this.originalContent = supportingDocsContent;
        prompt += `\nSupporting Documents:\n${this.originalContent}\n`;
      } else if (this.formData.supportingDocsFile) {
        // Fallback to single file support (backward compatibility)
        const extractedText = await this.extractFileText(this.formData.supportingDocsFile);
        contentText = extractedText;
        this.originalContent = contentText;
        prompt += `\nSupporting Documents:\n${this.originalContent}\n`;
      }

      // Add supporting links if provided
      if (this.supportingLinks) {
        prompt += `\nSupporting Links:\n${this.supportingLinks}\n`;
      }

      // Check if Factiva, WSJ, Dow Jones is selected
      const isFactivaSelected = this.pwcThirdPartySources.some(source => source.name === 'Factiva, WSJ, Dow Jones' && source.selected);
      if (isFactivaSelected) {
        prompt += `\nUse Factiva, WSJ, Dow Jones Research: true\n`;
      }

      // Add research to prompt
      if (this.conductResearch) {
        prompt += `\nResearch Requested: Yes\n`;
        prompt += `Research Topics: ${this.researchTopics}\n`;

        const sources = [];
        if (this.pwcContentLink) sources.push('PwC Content or Link');
        if (this.pwcProprietaryResearch) sources.push('PwC Proprietary Research');
        if (this.pwcLicensedThirdParty) sources.push('PwC Licensed Third Party Tools');
        if (this.externalResearch) sources.push('External Research');

        if (sources.length > 0) {
          prompt += `Research Sources: ${sources.join(', ')}\n`;
        }

        if (this.researchLinks) {
          prompt += `Research Links: ${this.researchLinks}\n`;
        }

        if (this.researchDocumentFiles.length > 0) {
          const fileNames = this.researchDocumentFiles.map(f => f.name).join(', ');
          prompt += `Research Documents: ${fileNames}\n`;
        }
      }

      if (this.additionalGuidelines.trim()) {
        prompt += `\nAdditional Guidelines: ${this.additionalGuidelines}\n`;
      }

      // Build structured research object
      const researchData: any = {
        isSelected: this.conductResearch
      };

      if (this.conductResearch) {
        // Add research topics if provided
        if (this.researchTopics.trim()) {
          researchData.research_topics = this.researchTopics;
        }

        // Add additional guidelines if provided
        if (this.additionalGuidelines.trim()) {
          researchData.additional_guidelines = this.additionalGuidelines;
        }

        // PwC Content - only include if toggle is ON
        if (this.pwcContentLink) {
          researchData.pwc_content = {
            isSelected: true
          };

          // Add research document text if files were uploaded
          if (this.researchDocumentFiles.length > 0) {
            try {
              const extractionPromises = this.researchDocumentFiles.map(file => 
                this.extractFileText(file)
              );
              const extractedTexts = await Promise.all(extractionPromises);
              const combinedText = extractedTexts.join('\n\n');
              researchData.pwc_content.supportingDoc = combinedText;
              
              // Send filenames for citations
              researchData.pwc_content.supportingDocFilenames = this.researchDocumentFiles.map(f => f.name);
            } catch (error) {
              console.error('[DraftContentFlow] Error extracting research documents:', error);
            }
          }

          // Add instructions if provided
          if (this.researchDocInstructions) {
            researchData.pwc_content.supportingDoc_instructions = this.researchDocInstructions;
          }

          // Add research links if provided
          if (this.researchLinks) {
            researchData.pwc_content.research_links = this.researchLinks;
          }
        }

        // Proprietary Sources - only include if toggle is ON
        if (this.pwcProprietaryResearch) {
          const selectedProprietarySources = this.pwcProprietarySources
            .filter(s => s.selected)
            .map(s => toSnakeCase(s.name));

          researchData.proprietary = {
            isSelected: true,
            sources: selectedProprietarySources
          };
        }

        // Third Party Sources - only include if toggle is ON
        if (this.pwcLicensedThirdParty) {
          const selectedThirdPartySources = this.pwcThirdPartySources
            .filter(s => s.selected)
            .map(s => toSnakeCase(s.name));

          researchData.thirdParty = {
            isSelected: true,
            sources: selectedThirdPartySources
          };
        }

        // External Research - only include if toggle is ON
        if (this.externalResearch) {
          researchData.externalResearch = {
            isSelected: true
          };

          // Add research links if provided
          if (this.researchLinks) {
            researchData.externalResearch.research_links = this.researchLinks;
          }
        }
      }

      // Build the complete payload with all user selections nested under `services`
      const services: any = {};

      // Draft/service-specific parameters
      services.draft = {
        content_type: contentTypeKey,
        topic: this.topicInput,
        audience_tone: this.audienceTone,
        outline: {
          type: outlineType,
          content: contentoutlineText
        }
      };

      // Add optional draft-level fields
      if (this.wordLimit && String(this.wordLimit).trim()) {
        services.draft.word_limit = this.wordLimit;
      }

      // Add supporting documents - prioritize multiple files over single file
      if (supportingDocsContent) {
        services.draft.supporting_documents = {
          content: supportingDocsContent,
          filenames: this.formData.supportingDocsFiles.map(f => f.name)
        };
        if (this.supportingLinks) {
          services.draft.supporting_documents.links = this.supportingLinks;
        }
      } else if (contentText) {
        services.draft.supporting_documents = {
          content: contentText,
          filenames: this.formData.supportingDocsFile ? [this.formData.supportingDocsFile.name] : []
        };
        if (this.supportingLinks) {
          services.draft.supporting_documents.links = this.supportingLinks;
        }
      } else if (this.supportingLinks) {
        // If only links are provided without documents
        services.draft.supporting_documents = {
          links: this.supportingLinks
        };
      }

      // Attach research configuration under services
      services.research = researchData;

      const payload: any = {
        messages: [{ role: 'user' as const, content: prompt }],
        services,
        stream: true
      };

      console.log('[DraftContentFlow] Sending structured request (messages + services):', {
        contentType: contentTypeKey,
        topic: this.topicInput,
        hasResearch: this.conductResearch
      });

      // Store original parameters for improvement iterations
      this.originalContentType = contentType;
      this.originalWordLimit = this.wordLimit;
      this.originalAudienceTone = this.audienceTone;
      this.originalOutlineDoc = contentoutlineText;
      this.originalSupportingDoc = contentText;
      this.originalUseFactivaResearch = isFactivaSelected;

      this.streamSubscription = this.chatService.streamDraftContent(payload as any).subscribe({
        next: (data: any) => {
          if (typeof data === 'string') {
            this.draftContent += data;
          } else if (data.type === 'content' && data.content) {
            this.draftContent += data.content;
          } else if (data.type === 'done' && data.done === true) {
            // Append disclaimer whenever draft content generation completes
            const disclaimer = '\n\n---\n\n*This content was generated with the assistance of artificial intelligence and is intended as an initial draft. It may incorporate references to broader industry or third-party sources that may not be exhaustive or fully aligned at a granular level. PwC professionals must review and validate the content to ensure accuracy, appropriate attribution, and suitability for internal or client-facing use, and remain fully responsible for the final version.*';
            this.draftContent += disclaimer;
          }
        },
        error: (error: any) => {
          console.error('[DraftContentFlow] Error:', error);
          this.draftContent = 'Sorry, there was an error generating your draft content. Please try again.';
          this.isGenerating = false;
        },
        complete: () => {
          console.log('[DraftContentFlow] Draft generation complete');
          this.isGenerating = false;

          // Send content to chat immediately with satisfaction question
          if (this.draftContent && this.draftContent.trim()) {
            this.iterationCount = 1;
            this.sendDraftToChatWithSatisfactionQuestion();
          }
        }
      });
    } catch (error) {
      console.error('[DraftContentFlow] Error:', error);
      this.isGenerating = false;
    }
  }

  /** Get satisfaction prompt text */
  getSatisfactionPromptText(): string {
    if (this.iterationCount === 0) {
      return 'Are you satisfied with the generated content, or do you need additional improvements?';
    }
    return `Are you satisfied with this revision (Iteration ${this.iterationCount}), or do you need additional improvements?`;
  }

  /** Send draft content to chat with satisfaction question */
  private sendDraftToChatWithSatisfactionQuestion(): void {
    if (this.draftContent && this.draftContent.trim()) {
      let plainText = this.draftContent;
      if (this.draftContent.includes('<')) {
        const tempDiv = document.createElement('div');
        tempDiv.innerHTML = this.draftContent;
        plainText = tempDiv.textContent || tempDiv.innerText || '';
      }

      // Map content type to metadata format
      let metadataContentType: 'article' | 'blog' | 'white_paper' | 'executive_brief' | 'podcast' = 'article';
      if (this.contentTypeBlog) metadataContentType = 'blog';
      else if (this.contentTypeWhitePaper) metadataContentType = 'white_paper';
      else if (this.contentTypeExecutiveBrief) metadataContentType = 'executive_brief';

      // Prepend a header with content type for better identification
      const contentWithHeader = `**Generated Content** - ${this.getContentTypeLabel(metadataContentType)}\n\n${this.draftContent}`;

      const metadata: ThoughtLeadershipMetadata = {
        contentType: metadataContentType,
        topic: this.topicInput,
        fullContent: plainText,
        showActions: true
      };

      // Send the draft content to chat
      console.log('[DraftContentFlow] Sending draft content to chat:', metadata);
      this.tlChatBridge.sendToChat(contentWithHeader, metadata);

      // Store draft context for handling improvement requests
      this.tlChatBridge.setDraftContext({
        contentType: this.originalContentType,
        topic: this.topicInput,
        wordLimit: this.originalWordLimit,
        audienceTone: this.originalAudienceTone,
        outlineDoc: this.originalOutlineDoc,
        supportingDoc: this.originalSupportingDoc,
        useFactivaResearch: this.originalUseFactivaResearch,
        generatedContent: plainText
      });
      console.log('[DraftContentFlow] ✓ Draft context stored successfully');

      // Add satisfaction question as a system message in the chat
      const satisfactionMessage = 'Are you satisfied with this content? If not, let me know what improvements you\'d like and I\'ll regenerate it for you.';
      console.log('[DraftContentFlow] Sending satisfaction question to chat');
      
      // Send as a system message using sendMessage method
      const systemMessage: Message = {
        role: 'system',
        content: satisfactionMessage,
        timestamp: new Date()
      };
      this.tlChatBridge.sendMessage(systemMessage);
      console.log('[DraftContentFlow] ✓ Satisfaction question sent');

      // Close the modal after sending to chat
      console.log('[DraftContentFlow] About to close modal');
      this.onClose();
      console.log('[DraftContentFlow] Modal closed');
    }
  }

  /** Get validation for improvement request */
  get isImprovementRequestValid(): boolean {
    return !!this.improvementRequestText && this.improvementRequestText.trim().length > 0;
  }

  /** Trigger change detection when improvement text changes */
  onImprovementTextChange(): void {
    this.cdr.markForCheck();
  }

  /** Handle satisfaction response - send to chat or show improvement input */
  onSatisfactionResponse(isSatisfied: boolean): void {
    if (isSatisfied) {
      if (this.draftContent && this.draftContent.trim()) {
        let plainText = this.draftContent;
        if (this.draftContent.includes('<')) {
          const tempDiv = document.createElement('div');
          tempDiv.innerHTML = this.draftContent;
          plainText = tempDiv.textContent || tempDiv.innerText || '';
        }

        // Map content type to metadata format
        let metadataContentType: 'article' | 'blog' | 'white_paper' | 'executive_brief' | 'podcast' = 'article';
        if (this.contentTypeBlog) metadataContentType = 'blog';
        else if (this.contentTypeWhitePaper) metadataContentType = 'white_paper';
        else if (this.contentTypeExecutiveBrief) metadataContentType = 'executive_brief';

        // Prepend a header with content type for better identification
        const contentWithHeader = `**Generated Content** - ${this.getContentTypeLabel(metadataContentType)}\n\n${this.draftContent}`;

        const metadata: ThoughtLeadershipMetadata = {
          contentType: metadataContentType,
          topic: this.topicInput,
          fullContent: plainText,
          showActions: true
        };

        console.log('[DraftContentFlow] Sending satisfied content to chat:', metadata);
        this.tlChatBridge.sendToChat(contentWithHeader, metadata);

        // Close the modal after sending to chat
        this.onClose();
      }
    } else {
      // Show improvement input
      this.showImprovementInput = true;
      this.showSatisfactionPrompt = false;
    }
  }

  /** Submit improvement request */
  submitImprovementRequest(): void {
    if (!this.improvementRequestText?.trim()) {
      return;
    }

    const nextIteration = this.iterationCount + 1;
    if (nextIteration > 5) {
      alert('You have reached the maximum number of iterations (5). Please start a new draft if you need further changes.');
      this.cancelImprovementRequest();
      return;
    }

    const revisedPlainText = this.draftContent.replace(/<br>/g, '\n');
    const improvementMessage = `Topic: ${this.topicInput}\n\nPlease review the following generated content and apply these improvements:\n\n${this.improvementRequestText.trim()}\n\nGenerated Content:\n${revisedPlainText}`;

    const messages = [{
      role: 'user' as const,
      content: improvementMessage
    }];

    this.isGenerating = true;
    this.showImprovementInput = false;
    
    // Store the improvement text before clearing it
    const improvementText = this.improvementRequestText;
    this.improvementRequestText = '';
    this.draftContent = '';

    // Prepare draft parameters to send to backend
    const draftParams = {
      contentType: this.originalContentType,
      wordLimit: this.originalWordLimit,
      audienceTone: this.originalAudienceTone,
      outlineDoc: this.originalOutlineDoc,
      supportingDoc: this.originalSupportingDoc,
      useFactivaResearch: this.originalUseFactivaResearch
    };

    this.streamSubscription = this.chatService.streamDraftContent(messages, improvementText, draftParams).subscribe({
      next: (data: any) => {
        if (typeof data === 'string') {
          this.draftContent += data;
        } else if (data.type === 'content' && data.content) {
          this.draftContent += data.content;
        } else if (data.type === 'done' && data.done === true) {
          // Append disclaimer whenever draft content generation completes
          const disclaimer = '\n\n---\n\n*This content was generated with the assistance of artificial intelligence and is intended as an initial draft. It may incorporate references to broader industry or third-party sources that may not be exhaustive or fully aligned at a granular level. PwC professionals must review and validate the content to ensure accuracy, appropriate attribution, and suitability for internal or client-facing use, and remain fully responsible for the final version.*';
          this.draftContent += disclaimer;
        }
      },
      error: (error: any) => {
        console.error('[DraftContentFlow] Error improving content:', error);
        this.draftContent = 'Sorry, there was an error processing your improvement request. Please try again.';
        this.isGenerating = false;
        this.draftContent = revisedPlainText.replace(/\n/g, '<br>');
        this.showSatisfactionPrompt = true;
      },
      complete: () => {
        this.isGenerating = false;
        this.iterationCount = nextIteration;
        this.showSatisfactionPrompt = true;
      }
    });
  }

  /** Cancel improvement request and return to satisfaction prompt */
  cancelImprovementRequest(): void {
    this.showImprovementInput = false;
    this.improvementRequestText = '';
    this.showSatisfactionPrompt = true;
  }
}


