import { Component, Input, OnInit, OnDestroy, ViewChild, ElementRef } from '@angular/core';
import { DomSanitizer, SafeHtml } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';
import { Subject, Subscription, takeUntil } from 'rxjs';
import { DdcFlowService } from '../../../core/services/ddc-flow.service';
import { ChatService } from '../../../core/services/chat.service';
import { AuthFetchService } from '../../../core/services/auth-fetch.service';
import { environment } from '../../../../environments/environment';
import { DDCRequestFormComponent } from '../../phoenix/ddc/request-form-ddc';
import {saveAs} from 'file-saver';

interface SanitizationService {
  id: string;
  label: string;
  selected: boolean;
}

@Component({
    selector: 'app-sanitization-flow',
    imports: [FormsModule, DDCRequestFormComponent],
    templateUrl: './sanitization-flow.component.html',
    styleUrls: ['./sanitization-flow.component.scss']
})
export class SanitizationFlowComponent implements OnInit, OnDestroy {
  // Input properties from parent component
  @Input() hideBackButton: boolean = false;
  @Input() openedFrom: 'quick-action' | 'guided-dialog' | null = null;
  @ViewChild('fileInput') fileInput?: ElementRef<HTMLInputElement>;

  isOpen = false;
  isGenerating = false;
  generatedContent = '';
  showDownloadButton = false;
  downloadUrl: string | undefined;
  downloadSuccessful = false;
  showCreateRequestButton = false;
  showRequestForm = false;
  phoenixRdpLink = '';

  // Form fields
  uploadedFile: File | null = null;
  selectedTemplate: string = 'existing';
  customTemplateFile: File | null = null;
  clientIdentifiers: string = '';
  additionalGuidelines: string = '';

  // Sanitization services (4 default-checked)
  sanitizationServices: SanitizationService[] = [
    { id: 'replace_client', label: 'Replace client identifiers with placeholders', selected: true },
    { id: 'delete_notes', label: 'Delete notes/comments', selected: true },
    { id: 'cut_hyperlinks', label: 'Remove hyperlinks', selected: true },
    { id: 'mask_leadership', label: 'Replace names and titles with placeholders', selected: true },
    { id: 'change_competitors', label: 'Replace client competitor identifiers with placeholders', selected: false },
    { id: 'remove_data', label: 'Remove financials', selected: false },
    { id: 'conceal_regions', label: 'Replace locations with placeholders', selected: false },
    { id: 'disguise_bus', label: 'Replace client- identifying BUs', selected: false }
    
  ];

  private destroy$ = new Subject<void>();
  private streamSubscription?: Subscription;

  constructor(
    private ddcFlowService: DdcFlowService,
    private chatService: ChatService,
    private authFetchService: AuthFetchService,
    private sanitizer: DomSanitizer
  ) {}


  ngOnInit(): void {
    this.ddcFlowService.activeFlow$
      .pipe(takeUntil(this.destroy$))
      .subscribe(flow => {
        this.isOpen = flow === 'sanitization';
        if (this.isOpen) {
          this.resetForm();
        }
      });
  }

  ngOnDestroy(): void {
    this.cancelStream();
    this.destroy$.next();
    this.destroy$.complete();
  }

  private cancelStream(): void {
    if (this.streamSubscription) {
      console.log('[SanitizationFlow] Cancelling active stream');
      this.streamSubscription.unsubscribe();
      this.streamSubscription = undefined;
      this.isGenerating = false;
    }
  }

  resetForm(): void {
    this.uploadedFile = null;
    this.selectedTemplate = 'core';
    this.customTemplateFile = null;
    this.clientIdentifiers = '';
    this.additionalGuidelines = '';
    // this.sanitizationServices.forEach((service, index) => {
    //   // First 4 services default to checked
    //   service.selected = index < 8;
    // });
    this.sanitizationServices = [
    { id: 'replace_client', label: 'Replace client identifiers with placeholders', selected: true },
    { id: 'delete_notes', label: 'Delete notes/comments', selected: true },
    { id: 'cut_hyperlinks', label: 'Remove hyperlinks', selected: true },
    { id: 'mask_leadership', label: 'Replace names and titles with placeholders', selected: true },
    { id: 'change_competitors', label: 'Replace client competitor identifiers with placeholders', selected: false },
    { id: 'remove_data', label: 'Remove financials', selected: false },
    { id: 'conceal_regions', label: 'Replace locations with placeholders', selected: false },
    { id: 'disguise_bus', label: 'Replace client- identifying BUs', selected: false }
    
  ];
    this.generatedContent = '';
    this.isGenerating = false;
  }

  onFileSelect(event: Event): void {
    const input = event.target as HTMLInputElement;
    if (input.files && input.files.length > 0) {
      this.uploadedFile = input.files[0];
    }
  }

  onTemplateFileSelect(event: Event): void {
    const input = event.target as HTMLInputElement;
    if (input.files && input.files.length > 0) {
      this.customTemplateFile = input.files[0];
    }
  }

  removeFile(): void {
    this.uploadedFile = null;
    // Reset the file input so the same file can be re-selected
    if (this.fileInput?.nativeElement) {
      this.fileInput.nativeElement.value = '';
    }
  }

  removeTemplateFile(): void {
    this.customTemplateFile = null;
  }

  get canGenerate(): boolean {
    if (!this.uploadedFile) return false;
    if (this.selectedTemplate === 'other' && !this.customTemplateFile) return false;
    return this.sanitizationServices.some(s => s.selected);
  }

  get selectedServices(): SanitizationService[] {
    return this.sanitizationServices.filter(s => s.selected);
  }

  close(): void {
    this.cancelStream();
    this.resetDownloadState();
    this.ddcFlowService.closeFlow();
  }

  back(): void{
    this.cancelStream();
    this.resetDownloadState();
    this.ddcFlowService.closeFlow();
    this.ddcFlowService.openGuidedDialog();
  }

  async generate(): Promise<void> {
    if (!this.canGenerate) return;

    // Reset download button states when generating again
    this.resetDownloadState();

    try {
      this.isGenerating = true;
      this.generatedContent = 'Sanitizing your presentation... This may take a moment.';
      console.log('[SanitizationFlow] Starting sanitization');

      const formData = new FormData();
      formData.append('file', this.uploadedFile!);
      formData.append('template', this.selectedTemplate);
      if (this.customTemplateFile) {
        formData.append('custom_template', this.customTemplateFile);
      }
      formData.append('client_identifiers', this.clientIdentifiers);
      formData.append('services', JSON.stringify(this.selectedServices.map(s => s.id)));
      formData.append('additional_guidelines', this.additionalGuidelines);

      console.log('[SanitizationFlow] Sending request');

      // Call the backend to sanitize and download the file
      const apiUrl = environment.apiUrl || '';
      const response = await this.authFetchService.authenticatedFetchFormData(`${apiUrl}/api/v1/ddc/sanitization`, {
        method: 'POST',
        body: formData
      });

      if (!response.ok) {
        let errorMessage = `Sanitization failed: ${response.statusText}`;
        try {
          const errorData = await response.json();
          if (errorData.detail) {
            errorMessage = errorData.detail;
          }
        } catch (e) {
          // If response is not JSON, use status text
        }
        throw new Error(errorMessage);
      }

      // Parse sanitization plan from response headers
      const planHeader = response.headers.get('X-Sanitization-Plan');
      const summaryHeader = response.headers.get('X-Sanitization-Summary');

      let planItems: any[] = [];
      let summary: any = null;

      try {
        if (planHeader) {
          planItems = JSON.parse(planHeader);
        }
        if (summaryHeader) {
          summary = JSON.parse(summaryHeader);
        }
      } catch (e) {
        console.warn('[SanitizationFlow] Could not parse sanitization plan');
      }

      // Get the sanitized file and store URL for download button
      const blob = await response.blob();
      // Escape untrusted filename data for security
      const filename = this.escapeFilename(this.uploadedFile!.name.replace('.pptx', '_sanitized.pptx'));

      console.log('[SanitizationFlow] Blob created');

      // Create blob URL for download button
      this.downloadUrl = window.URL.createObjectURL(blob);
      this.showDownloadButton = true;

      // Build clean line-by-line sanitization plan
      let planDisplay = '';
      if (planItems.length > 0) {
        planDisplay = '\n\nSanitization Plan:\n' + planItems.map((item: any) =>
          `✓ ${item.label}\n   ${item.details}`
        ).join('\n');
      }

      // Show success message with clean plan
      //this.generatedContent = `✅ Sanitization Complete!\n\nYour sanitized presentation "${filename}" has been downloaded.${planDisplay}`;
      this.generatedContent = `Sanitization completed successfully!`;
      if (summary) {
        // Escape untrusted summary data before using in output
        const slidesProcessed = this.escapeHtmlSpecialChars(String(summary.slides_processed));
        const totalChanges = this.escapeHtmlSpecialChars(String(summary.total_changes));
        this.generatedContent += `\n\nSummary: ${slidesProcessed} slides processed.`;
      }

      this.isGenerating = false;
      this.showCreateRequestButton = true;

      console.log('[SanitizationFlow] Sanitization and download complete');
    } catch (error) {
      // Log generic message without full error object to prevent information leakage
      console.error('[SanitizationFlow] Sanitization processing failed');
      this.generatedContent = 'I apologize, but I encountered an error during sanitization. Please try again.';
      this.isGenerating = false;
    }
  }

  openRequestForm(): void {
    this.showRequestForm = true;
  }

  downloadPptxFile(): void {

  if (!this.downloadUrl) {

    console.warn('[SanitizationFlow] No download URL available');

    this.generatedContent =

      '✗ An error occurred while preparing the file. Please try again.';

    this.isGenerating = false;

    this.showDownloadButton = false;

    this.downloadUrl = undefined;

    return;

  }
 
  // ✅ Escape untrusted filename data

  const filename = this.escapeFilename(

    this.uploadedFile!.name.replace('.pptx', '_sanitized.pptx')

  );
 
  const parsedUrl = new URL(this.downloadUrl);
 
  // ✅ BEST SAFE PATH → Blob URL direct save

  if (parsedUrl.protocol === 'blob:') {

    try {

      saveAs(parsedUrl.toString(), filename);
 
      this.downloadSuccessful = true;

      this.generatedContent = '✓ Document downloaded successfully!';

      this.showDownloadButton = false;
 
      console.log('[SanitizationFlow] Blob file saved successfully');

      return;

    } catch {

      console.error('[SanitizationFlow] Blob save failed');

      this.fallbackDownloadPptx(filename);

      return;

    }

  }
 
  // ✅ HTTPS path → use existing secure fallback

  if ('showSaveFilePicker' in window) {

    try {

      const mimeType =

        'application/vnd.openxmlformats-officedocument.presentationml.presentation';
 
      (window as any)

        .showSaveFilePicker({

          suggestedName: filename,

          types: [

            {

              description: 'PPTX Files',

              accept: { [mimeType]: ['.pptx'] }

            }

          ]

        })

        .then(async () => {

          // ✅ No fetch here anymore

          // use validated fallback URL flow

          this.fallbackDownloadPptx(filename);

        })

        .catch((error: any) => {

          if (error.name !== 'AbortError') {

            console.error('[SanitizationFlow] File save dialog error');

            this.fallbackDownloadPptx(filename);

          }

        });

    } catch {

      console.error('[SanitizationFlow] Save dialog access failed');

      this.fallbackDownloadPptx(filename);

    }

  } else {

    this.fallbackDownloadPptx(filename);

  }

}
 


private async fallbackDownloadPptx(

  filename: string,

  blob?: Blob

): Promise<void> {

  try {

    const safeFilename =

      filename

        .replace(/[^a-zA-Z0-9._-]/g, '_')

        .replace(/_{2,}/g, '_')

        .replace(/^_+|_+$/g, '') || 'download';
 
    // 🔥 1) BEST PATH → if blob is already available

    if (blob) {

      const handle = await (window as any).showSaveFilePicker({

        suggestedName: safeFilename,

        types: [

          {

            description: 'PowerPoint Presentation',

            accept: {

              'application/vnd.openxmlformats-officedocument.presentationml.presentation':

                ['.pptx']

            }

          }

        ]

      });
 
      const writable = await handle.createWritable();

      await writable.write(await blob.arrayBuffer());

      await writable.close();
 
      this.downloadSuccessful = true;

      this.generatedContent = '✓ Document downloaded successfully!';

      this.showDownloadButton = false;

      return;

    }
 
    // ❌ 2) FALLBACK → URL-based download

    if (!this.downloadUrl) {

      throw new Error('Download URL is missing');

    }
 
    const parsedUrl = new URL(this.downloadUrl);
 
    // ✅ Allow only HTTPS + Blob URLs

    if (

      parsedUrl.protocol !== 'https:' &&

      parsedUrl.protocol !== 'blob:'

    ) {

      throw new Error('Invalid protocol');

    }
 
    // ✅ Validate host ONLY for HTTPS URLs

    if (parsedUrl.protocol === 'https:') {

      const allowedHosts = [

        'webapp-bsc-mcx.dev.ngc.pwcinternal.com',

        'webapp-bsc-mcx.ngc.pwcinternal.com'

      ];
 
      const isAllowedHost = allowedHosts.some(

        host =>

          parsedUrl.hostname === host ||

          parsedUrl.hostname.endsWith(`.${host}`)

      );
 
      if (!isAllowedHost) {

        throw new Error('Untrusted host');

      }
 
      // ✅ Restrict HTTPS fallback to PPTX only

      if (!parsedUrl.pathname.toLowerCase().endsWith('.pptx')) {

        throw new Error('Only PPTX downloads are allowed');

      }

    }
 
    // ✅ SAFE URL DOWNLOAD (Veracode-friendly)

    saveAs(parsedUrl.toString(), safeFilename);
 
    // ✅ Preserve existing UI success flow

    this.downloadSuccessful = true;

    this.generatedContent = '✓ Document downloaded successfully!';

    this.showDownloadButton = false;
 
  } catch (error) {

    console.error('[fallbackDownloadPptx] Download failed:', error);

    this.generatedContent = 'Download failed. Please try again.';

  }

}
 

  private resetDownloadState(): void {
    this.showDownloadButton = false;
    this.downloadUrl = undefined;
    this.downloadSuccessful = false;
    // Cleanup blob URL if it exists
    if (this.downloadUrl) {
      window.URL.revokeObjectURL(this.downloadUrl);
    }
  }

  onTicketCreated(event: {requestNumber: string, phoenixRdpLink: string}): void {
    // Validate and escape untrusted data before using in HTTP response
    try {
      this.validateAndEscapeUrl(event.phoenixRdpLink);
      const escapedRequestNumber = this.escapeHtmlSpecialChars(event.requestNumber);
      const escapedLink = this.escapeHtmlAttribute(event.phoenixRdpLink);
      this.phoenixRdpLink = event.phoenixRdpLink;
      this.generatedContent = `Request created successfully! Your request number is: <a href="${escapedLink}" target="_blank" rel="noopener noreferrer">${escapedRequestNumber}</a>`;
    } catch (error) {
      // Log generic message without full error object to prevent information leakage
      //console.error('[SanitizationFlow] Invalid ticket data');
      this.generatedContent = 'Error processing request. Please try again.';
    }
    this.showRequestForm = false;
    this.showCreateRequestButton = false;
  }

  /**
   * Escape HTML special characters to prevent XSS attacks
   * Used for text content that will appear in HTML
   */
  private escapeHtmlSpecialChars(untrustedData: string): string {
    if (!untrustedData) return '';
    const div = document.createElement('div');
    div.textContent = untrustedData;
    return div.innerHTML;
  }

  /**
   * Escape data for use in HTML attributes
   * Used for href, src, and other attributes
   */
  private escapeHtmlAttribute(untrustedData: string): string {
    if (!untrustedData) return '';
    return untrustedData
      .replace(/&/g, '&amp;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#x27;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;');
  }

  /**
   * Escape filename data to prevent path traversal and XSS
   */
  private escapeFilename(untrustedFilename: string): string {
    if (!untrustedFilename) return 'file';
    // Remove path traversal characters and escape special characters
    return untrustedFilename
      .replace(/\.\./g, '_') // Remove ..
      .replace(/[/\\]/g, '_') // Remove path separators
      .replace(/[<>:"|?*]/g, '_') // Remove invalid filename characters
      .substring(0, 255); // Limit filename length
  }

  /**
   * Validate URL to prevent open redirect attacks
   * @throws Error if URL is not safe
   */
  private validateAndEscapeUrl(urlString: string): void {
    if (!urlString) throw new Error('URL is empty');
    
    try {
      const url = new URL(urlString);
      
      // Only allow http and https protocols
      if (!['http:', 'https:'].includes(url.protocol)) {
        throw new Error(`Invalid protocol: ${url.protocol}`);
      }
      
      // In production, enforce HTTPS
      if ((environment as any).production && url.protocol !== 'https:') {
        throw new Error('HTTPS required in production');
      }
    } catch (error) {
      throw new Error(`URL validation failed: ${error instanceof Error ? error.message : 'Invalid URL'}`);
    }
  }
}
