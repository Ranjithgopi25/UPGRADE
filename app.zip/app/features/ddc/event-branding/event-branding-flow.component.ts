import { Component, Input, OnInit, OnDestroy, ViewChild, ElementRef } from '@angular/core';

import { FormsModule } from '@angular/forms';
import { DomSanitizer } from '@angular/platform-browser';
import { Subject, Subscription, takeUntil } from 'rxjs';
import { DdcFlowService } from '../../../core/services/ddc-flow.service';
import { ChatService } from '../../../core/services/chat.service';
import { AuthFetchService } from '../../../core/services/auth-fetch.service';
import { environment } from '../../../../environments/environment';
import { DDCRequestFormComponent } from '../../phoenix/ddc/request-form-ddc';
import {saveAs} from 'file-saver';

interface EventBrandingService {
  id: string;
  label: string;
  selected: boolean;
  isdisabled: boolean;
}

interface Template {
  value: string;
  label: string;
  category: string;
}

interface ImageTemplate {
  id: string;
  label: string;
  imageUrl: string;
  thumbnail: string;
  category?: string;
}

@Component({
    selector: 'app-event-branding-flow',
    imports: [FormsModule, DDCRequestFormComponent],
    templateUrl: './event-branding-flow.component.html',
    styleUrls: ['./event-branding-flow.component.scss']
})
export class EventBrandingFlowComponent implements OnInit, OnDestroy {
  // Input properties from parent component
  @Input() hideBackButton: boolean = false;
  @Input() openedFrom: 'quick-action' | 'guided-dialog' | null = null;
  @ViewChild('fileInput') fileInput?: ElementRef<HTMLInputElement>;

  isOpen = false;
  isGenerating = false;
  isDownloading = false;
  generatedContent = '';
  showDownloadButton = false;
  downloadUrl: string | undefined;
  downloadSuccessful = false;
  showCreateRequestButton = false;
  showRequestForm = false;
  excelDownloaded = false;
  phoenixRdpLink = '';
  selectedDownloadFormat: 'docx' | 'pptx' | 'jpeg' | 'png' = 'docx';

  // Form fields
  uploadedFile: File | null = null;
  selectedTemplate: string = '';
  customTemplateFile: File | null = null;
  clientIdentifiers: string = '';
  additionalGuidelines: string = '';
  eventName: string = '';
  maxBannerTitleCharacters: number = 35;
  bannerTitle: string = '';
  bannerTitleExceedsLimit: boolean = false;
  bannerSubtext: string = '';
  bannerHasPwcLogo: boolean = false;
  
  // Small poster specific fields
  maxPosterTitleWords: number = 20;
  maxPosterTitleCharacters: number = 60;
  posterTitle: string = '';
  posterTitleExceedsLimit: boolean = false;
  maxPosterSmallTextWords: number = 20;
  maxPosterSmallTextCharacters: number = 800;
  posterSmallText: string = '';
  posterSmallTextExceedsLimit: boolean = false;
  posterDate: string = '';
  posterFooterNotes: string = '';
  posterSubtitle: string = '';
  maxPosterSubtitleCharacters: number = 141;
  posterSubtitleExceedsLimit: boolean = false;
  posterExpandedText: string = '';
  maxPosterExpandedTextCharacters: number = 1550;
  posterExpandedTextExceedsLimit: boolean = false;
  maxPosterFooterNotesCharacters: number = 118;
  posterFooterNotesExceedsLimit: boolean = false;
  posterIncludeCopyright: boolean = false;
  posterSize: string = '18x24';

  // Event branding services (4 default-checked)
  eventbrandingServices: EventBrandingService[] = [
    { id: 'name-tag', label: 'Name tag', selected: false, isdisabled: false },
    { id: 'table-tent', label: 'Table tent', selected: false, isdisabled: false },
    { id: 'small-poster', label: 'Small poster', selected: false, isdisabled: false },
    { id: 'banner', label: 'Banner', selected: false, isdisabled: true },
  ];

  // Template mappings
  templates: Template[] = [
    { value: 'core', label: 'Name Tag 1', category: 'name-tag' },
    { value: 'financial', label: 'Name Tag 2', category: 'name-tag' },
    { value: 'consulting', label: 'Table Tent 1', category: 'table-tent' },
    { value: 'technology', label: 'Table Tent 2', category: 'table-tent' },
    { value: 'other', label: 'Banner 1', category: 'banner' },
    { value: 'existing', label: 'Banner 2', category: 'banner' }
  ];

  // Default image templates - shown when no service is selected
  defaultImageTemplates: ImageTemplate[] = [
    { id: 'img-default-1', label: 'Template 1', imageUrl: 'assets/images/Event%20Branding%20Templates/Sample.jpg', thumbnail: 'assets/images/Event%20Branding%20Templates/Sample.jpg', category: 'default' },
    { id: 'img-default-2', label: 'Template 2', imageUrl: 'assets/images/Event%20Branding%20Templates/Sample.jpg', thumbnail: 'assets/images/Event%20Branding%20Templates/Sample.jpg', category: 'default' },
    { id: 'img-default-3', label: 'Template 3', imageUrl: 'assets/images/Event%20Branding%20Templates/Sample.jpg', thumbnail: 'assets/images/Event%20Branding%20Templates/Sample.jpg', category: 'default' }
  ];

  // Image templates - organized by service category
  imageTemplates: ImageTemplate[] = [
    // Name Tag templates
    { id: 'img-name-tag-1', label: 'Name Tag 1', imageUrl: 'assets/images/Event%20Branding%20Templates/Name%20Tag%201.jpg', thumbnail: 'assets/images/Event%20Branding%20Templates/Name%20Tag%201.jpg', category: 'name-tag' },
    { id: 'img-name-tag-2', label: 'Name Tag 2', imageUrl: 'assets/images/Event%20Branding%20Templates/Name%20Tag%202.jpg', thumbnail: 'assets/images/Event%20Branding%20Templates/Name%20Tag%202.jpg', category: 'name-tag' },
    { id: 'img-name-tag-3', label: 'Name Tag 3', imageUrl: 'assets/images/Event%20Branding%20Templates/Name%20Tag%203.jpg', thumbnail: 'assets/images/Event%20Branding%20Templates/Name%20Tag%203.jpg', category: 'name-tag' },
    // Tent templates
    { id: 'img-table-tent-1', label: 'Table Tent 1', imageUrl: 'assets/images/Event%20Branding%20Templates/Table%20Tent%201.jpg', thumbnail: 'assets/images/Event%20Branding%20Templates/Table%20Tent%201.jpg', category: 'table-tent' },
    { id: 'img-table-tent-2', label: 'Table Tent 2', imageUrl: 'assets/images/Event%20Branding%20Templates/Table%20Tent%202.jpg', thumbnail: 'assets/images/Event%20Branding%20Templates/Table%20Tent%202.jpg', category: 'table-tent' },
    { id: 'img-table-tent-3', label: 'Table Tent 3', imageUrl: 'assets/images/Event%20Branding%20Templates/Table%20Tent%203.jpg', thumbnail: 'assets/images/Event%20Branding%20Templates/Table%20Tent%203.jpg', category: 'table-tent' },
    // Small Poster templates
    { id: 'img-small-poster-1', label: 'Small Poster 1', imageUrl: 'assets/images/Event%20Branding%20Templates/Small%20Poster%201.jpg', thumbnail: 'assets/images/Event%20Branding%20Templates/Small%20Poster%201.jpg', category: 'small-poster' },
    { id: 'img-small-poster-2', label: 'Small Poster 2', imageUrl: 'assets/images/Event%20Branding%20Templates/Small%20Poster%202.jpg', thumbnail: 'assets/images/Event%20Branding%20Templates/Small%20Poster%202.jpg', category: 'small-poster' },
    { id: 'img-small-poster-3', label: 'Small Poster 3', imageUrl: 'assets/images/Event%20Branding%20Templates/Small%20Poster%203.jpg', thumbnail: 'assets/images/Event%20Branding%20Templates/Small%20Poster%203.jpg', category: 'small-poster' },
    // Banner templates
    { id: 'img-banner-1', label: 'Banner 1', imageUrl: 'assets/images/Event%20Branding%20Templates/Banner%201.jpg', thumbnail: 'assets/images/Event%20Branding%20Templates/Banner%201.jpg', category: 'banner' },
    { id: 'img-banner-2', label: 'Banner 2', imageUrl: 'assets/images/Event%20Branding%20Templates/Banner%202.jpg', thumbnail: 'assets/images/Event%20Branding%20Templates/Banner%202.jpg', category: 'banner' },
    { id: 'img-banner-3', label: 'Banner 3', imageUrl: 'assets/images/Event%20Branding%20Templates/Banner%203.jpg', thumbnail: 'assets/images/Event%20Branding%20Templates/Banner%203.jpg', category: 'banner' },
    { id: 'img-banner-4', label: 'Banner 4', imageUrl: 'assets/images/Event%20Branding%20Templates/Banner%204.jpg', thumbnail: 'assets/images/Event%20Branding%20Templates/Banner%204.jpg', category: 'banner' },
    { id: 'img-banner-5', label: 'Banner 5', imageUrl: 'assets/images/Event%20Branding%20Templates/Banner%205.jpg', thumbnail: 'assets/images/Event%20Branding%20Templates/Banner%205.jpg', category: 'banner' },
    { id: 'img-banner-6', label: 'Banner 6', imageUrl: 'assets/images/Event%20Branding%20Templates/Banner%206.jpg', thumbnail: 'assets/images/Event%20Branding%20Templates/Banner%206.jpg', category: 'banner' },
    { id: 'img-banner-7', label: 'Banner 7', imageUrl: 'assets/images/Event%20Branding%20Templates/Banner%207.jpg', thumbnail: 'assets/images/Event%20Branding%20Templates/Banner%207.jpg', category: 'banner' },
    { id: 'img-banner-8', label: 'Banner 8', imageUrl: 'assets/images/Event%20Branding%20Templates/Banner%208.jpg', thumbnail: 'assets/images/Event%20Branding%20Templates/Banner%208.jpg', category: 'banner' },
    { id: 'img-banner-9', label: 'Banner 9', imageUrl: 'assets/images/Event%20Branding%20Templates/Banner%209.jpg', thumbnail: 'assets/images/Event%20Branding%20Templates/Banner%209.jpg', category: 'banner' }
  ];

  // Preview modal
  previewImageUrl: string = '';
  showPreviewModal: boolean = false;
  selectedImageTemplate: string = '';

  private destroy$ = new Subject<void>();
  private streamSubscription?: Subscription;

  constructor(
    private ddcFlowService: DdcFlowService,
    private chatService: ChatService,
    private authFetchService: AuthFetchService,
    private sanitizer: DomSanitizer
  ) {}


  ngOnInit(): void {
    this.ddcFlowService.activeFlow$
      .pipe(takeUntil(this.destroy$))
      .subscribe(flow => {
        this.isOpen = flow === 'event-branding';
        if (this.isOpen) {
          this.resetForm();
        }
      });
  }

  ngOnDestroy(): void {
    this.cancelStream();
    this.destroy$.next();
    this.destroy$.complete();
  }

  private cancelStream(): void {
    if (this.streamSubscription) {
      console.log('[EventBrandingFlow] Cancelling active stream');
      this.streamSubscription.unsubscribe();
      this.streamSubscription = undefined;
      this.isGenerating = false;
    }
  }

  resetForm(): void {
    this.uploadedFile = null;
    this.selectedTemplate = '';
    this.selectedImageTemplate = '';
    this.customTemplateFile = null;
    this.clientIdentifiers = '';
    this.additionalGuidelines = '';
    this.eventName = '';
    this.bannerTitle = '';
    this.bannerTitleExceedsLimit = false;
    this.bannerSubtext = '';
    this.bannerHasPwcLogo = false;
    this.posterTitle = '';
    this.posterTitleExceedsLimit = false;
    this.posterDate = '';
    this.posterFooterNotes = '';
    this.posterFooterNotesExceedsLimit = false;
    this.posterSmallText = '';
    this.posterSmallTextExceedsLimit = false;
    this.posterSubtitle = '';
    this.posterSubtitleExceedsLimit = false;
    this.posterExpandedText = '';
    this.posterExpandedTextExceedsLimit = false;
    this.posterIncludeCopyright = false;
    this.posterSize = '18x24';
    this.excelDownloaded = false;
    // this.eventbrandingServices.forEach((service, index) => {
    //   // First 4 services default to checked
    //   service.selected = index < 8;
    // });
    this.eventbrandingServices = [
      { id: 'name-tag', label: 'Name tag', selected: false, isdisabled: false },
      { id: 'table-tent', label: 'Table tent', selected: false, isdisabled: false },
      // { id: 'small-poster', label: 'Small poster', selected: false, isdisabled: false },
      // { id: 'banner', label: 'Banner', selected: false, isdisabled: false },
    ];
    this.generatedContent = '';
    this.isGenerating = false;
    this.showDownloadButton = false;
    this.downloadUrl = undefined;
    this.showCreateRequestButton = false;
    this.showRequestForm = false;
    this.selectedDownloadFormat = 'docx'; // Default format
  }

  onFileSelect(event: Event): void {
    const input = event.target as HTMLInputElement;
    if (input.files && input.files.length > 0) {
      this.uploadedFile = input.files[0];
    }
  }

  onTemplateFileSelect(event: Event): void {
    const input = event.target as HTMLInputElement;
    if (input.files && input.files.length > 0) {
      this.customTemplateFile = input.files[0];
    }
  }

  removeFile(): void {
    this.uploadedFile = null;
    // Reset the file input so the same file can be re-selected
    if (this.fileInput?.nativeElement) {
      this.fileInput.nativeElement.value = '';
    }
  }

  checkPosterTitleWordCount(): void {
    // Get the character limit based on selected template and poster size
    this.maxPosterTitleCharacters = this.getMaxPosterTitleCharacters();
    
    // Check character count instead of word count
    const charCount = this.posterTitle.length;
    this.posterTitleExceedsLimit = charCount > this.maxPosterTitleCharacters;
  }

  private getMaxPosterTitleCharacters(): number {
    // Character limits based on template and poster size
    // Smaller poster size = fewer characters, larger size = more characters
    const size = this.posterSize; // '18x24' or '24x36'
    const template = this.selectedImageTemplate;

    // Default to 60 characters if no template/size selected
    const isSmallSize = size === '18x24';

    // Character limits for each template
    const characterLimits: { [key: string]: { small: number; large: number } } = {
      'img-small-poster-1': { small: 44, large: 48 },
      'img-small-poster-2': { small: 39, large: 39 },
      'img-small-poster-3': { small: 38, large: 32 }
    };

    const limits = characterLimits[template as string];
    if (limits) {
      return isSmallSize ? limits.small : limits.large;
    }

    // Default limit
    return isSmallSize ? 40 : 60;
  }

  checkPosterSmallTextWordCount(): void {
    const wordCount = this.posterSmallText.trim().split(/\s+/).filter(word => word.length > 0).length;
    this.posterSmallTextExceedsLimit = wordCount > this.maxPosterSmallTextWords;
  }

  getMaxPosterSmallTextCharacters(): number {
    return 800;
  }

  checkPosterSmallTextCharacterCount(): void {
    const charCount = this.posterSmallText.length;
    this.maxPosterSmallTextCharacters = this.getMaxPosterSmallTextCharacters();
    this.posterSmallTextExceedsLimit = charCount > this.maxPosterSmallTextCharacters;
  }

  getMaxPosterFooterNotesCharacters(): number {
    const isSmallSize = this.posterSize === '18x24';
    return isSmallSize ? 118 : 100;
  }

  checkPosterFooterNotesCharacterCount(): void {
    const charCount = this.posterFooterNotes.length;
    this.maxPosterFooterNotesCharacters = this.getMaxPosterFooterNotesCharacters();
    this.posterFooterNotesExceedsLimit = charCount > this.maxPosterFooterNotesCharacters;
  }

  checkBannerTitleCharacterCount(): void {
    const charCount = this.bannerTitle.length;
    const maxChars = this.getMaxBannerTitleCharacters();
    this.bannerTitleExceedsLimit = charCount > maxChars;
    this.maxBannerTitleCharacters = maxChars;
  }

  getMaxBannerTitleCharacters(): number {
    // Character limits based on banner template
    const template = this.selectedImageTemplate;
    
    switch (template) {
      case 'img-banner-1':
      case 'img-banner-2':
      case 'img-banner-3':
      case 'img-banner-8':
      case 'img-banner-9':
        return 35;
      case 'img-banner-4':
      case 'img-banner-5':
      case 'img-banner-6':
      case 'img-banner-7':
        return 32;
      default:
        return 35; // Default fallback
    }
  }

  getMaxPosterSubtitleCharacters(): number {
    const isSmallSize = this.posterSize === '18x24';
    return isSmallSize ? 141 : 117;
  }

  checkPosterSubtitleCharacterCount(): void {
    const charCount = this.posterSubtitle.length;
    this.maxPosterSubtitleCharacters = this.getMaxPosterSubtitleCharacters();
    this.posterSubtitleExceedsLimit = charCount > this.maxPosterSubtitleCharacters;
  }

  getMaxPosterExpandedTextCharacters(): number {
    return 1550;
  }

  checkPosterExpandedTextCharacterCount(): void {
    const charCount = this.posterExpandedText.length;
    this.maxPosterExpandedTextCharacters = this.getMaxPosterExpandedTextCharacters();
    this.posterExpandedTextExceedsLimit = charCount > this.maxPosterExpandedTextCharacters;
  }

  removeTemplateFile(): void {
    this.customTemplateFile = null;
  }

  onServiceToggle(selectedService: EventBrandingService): void {
    // Reset template selection and clear all result/download states whenever any toggle changes
    this.selectedTemplate = '';
    this.selectedImageTemplate = '';
    this.uploadedFile = null;
    this.excelDownloaded = false;
    this.eventName = '';
    this.bannerTitle = '';
    this.bannerTitleExceedsLimit = false;
    this.bannerHasPwcLogo = false;
    this.bannerSubtext = '';
    this.posterTitle = '';
    this.posterTitleExceedsLimit = false;
    this.posterDate = '';
    this.posterFooterNotes = '';
    this.posterFooterNotesExceedsLimit = false;
    this.posterSmallText = '';
    this.posterSmallTextExceedsLimit = false;
    this.posterSubtitle = '';
    this.posterSubtitleExceedsLimit = false;
    this.posterExpandedText = '';
    this.posterExpandedTextExceedsLimit = false;
    this.posterIncludeCopyright = false;
    this.posterSize = '18x24';
    if (this.fileInput?.nativeElement) {
      this.fileInput.nativeElement.value = '';
    }
    this.generatedContent = '';
    this.showDownloadButton = false;
    this.downloadUrl = undefined;
    this.downloadSuccessful = false;
    this.showCreateRequestButton = false;
    this.showRequestForm = false;

    // If the selected service is being checked
    if (selectedService.selected) {
      // Deselect all other services
      this.eventbrandingServices.forEach(service => {
        if (service.id !== selectedService.id) {
          service.selected = false;
        }
      });
      // Set download format based on selected service
      this.setDownloadFormatByService(selectedService.id);
    }
  }

  private setDownloadFormatByService(serviceId: string): void {
    switch (serviceId) {
      case 'name-tag':
      case 'table-tent':
        this.selectedDownloadFormat = 'docx';
        break;
      case 'small-poster':
        this.selectedDownloadFormat = 'pptx';
        break;
      case 'banner':
        this.selectedDownloadFormat = 'png';
        break;
      default:
        this.selectedDownloadFormat = 'docx';
    }
    console.log('[EventBrandingFlow] Download format set to:', this.selectedDownloadFormat);
  }

  getFilteredTemplates(): Template[] {
    const selectedService = this.eventbrandingServices.find(s => s.selected);
    if (!selectedService) {
      return [];
    }
    return this.templates.filter(t => t.category === selectedService.id);
  }

  getFilteredImageTemplates(): ImageTemplate[] {
    const selectedService = this.eventbrandingServices.find(s => s.selected);
    // If no service is selected, show default templates
    if (!selectedService) {
      return this.defaultImageTemplates;
    }
    return this.imageTemplates.filter(t => t.category === selectedService.id);
  }

  openImagePreview(imageTemplate: ImageTemplate): void {
    this.previewImageUrl = imageTemplate.imageUrl;
    this.showPreviewModal = true;
  }

  isDefaultImageTemplate(imageTemplate: ImageTemplate): boolean {
    return this.defaultImageTemplates.some(t => t.id === imageTemplate.id);
  }

  closePreviewModal(): void {
    this.showPreviewModal = false;
    this.previewImageUrl = '';
  }

  selectImageTemplate(imageTemplate: ImageTemplate): void {
    // Prevent selection of default templates
    if (this.isDefaultImageTemplate(imageTemplate)) {
      return;
    }

    // Remove uploaded file and clear all result/download states when switching image template
    this.uploadedFile = null;
    if (this.fileInput?.nativeElement) {
      this.fileInput.nativeElement.value = '';
    }
    this.generatedContent = '';
    this.showDownloadButton = false;
    this.downloadUrl = undefined;
    this.downloadSuccessful = false;
    this.showCreateRequestButton = false;
    this.showRequestForm = false;
    this.excelDownloaded = false;
    this.eventName = '';
    this.bannerTitle = '';
    this.bannerTitleExceedsLimit = false;
    this.bannerHasPwcLogo = false;
    this.bannerSubtext = '';
    this.posterTitle = '';
    this.posterTitleExceedsLimit = false;
    this.posterDate = '';
    this.posterFooterNotes = '';
    this.posterFooterNotesExceedsLimit = false;
    this.posterSmallText = '';
    this.posterSmallTextExceedsLimit = false;
    this.posterSubtitle = '';
    this.posterSubtitleExceedsLimit = false;
    this.posterExpandedText = '';
    this.posterExpandedTextExceedsLimit = false;
    this.posterIncludeCopyright = false;
    this.posterSize = '18x24';

    // Toggle selection: if already selected, unselect it; otherwise select it
    if (this.selectedImageTemplate === imageTemplate.id) {
      this.selectedImageTemplate = '';
    } else {
      this.selectedImageTemplate = imageTemplate.id;
    }

    // Validate title with new character limits based on selected template
    if (this.isSmallPosterSelected) {
      this.checkPosterTitleWordCount();
    }
    
    // Validate banner title with new word limits based on selected banner
    if (this.isBannerSelected && this.bannerTitle) {
      this.checkBannerTitleCharacterCount();
    }
  }

  get downloadLabelText(): string {
    const selectedService = this.eventbrandingServices.find(s => s.selected);
    if (!selectedService) {
      return 'Please download the input Excel to fill all the relevant details';
    }
    return `Please download the ${selectedService.label.toLowerCase()} input Excel to fill all the relevant details`;
  }

  get generateButtonText(): string {
    const selectedService = this.eventbrandingServices.find(s => s.selected);
    if (!selectedService) {
      return this.isGenerating ? 'Generating...' : 'Generate';
    }
    const serviceName = selectedService.label;
    return this.isGenerating ? `Generating ${serviceName.toLowerCase()}...` : `Generate ${serviceName.toLowerCase()}`;
  }

  get downloadButtonText(): string {
    const selectedService = this.selectedServices[0];
    if (!selectedService) {
      return this.isDownloading ? 'Downloading...' : 'Download document';
    }
    const serviceName = selectedService.label;
    return this.isDownloading ? `Downloading ${serviceName.toLowerCase()}...` : `Download ${serviceName.toLowerCase()}`;
  }

  get isServiceSelected(): boolean {
    return !!this.selectedImageTemplate;
  }

  get canGenerate(): boolean {
    const selectedService = this.eventbrandingServices.find(s => s.selected);

    // For small-poster, check for poster title and template selection
    if (selectedService?.id === 'small-poster') {
      // Allow generation even if title exceeds character limit - just show warning

      if (!this.posterTitle || !this.selectedImageTemplate) {
        return false;
      }

      // Validate required fields based on selected template
      if (this.selectedImageTemplate === 'img-small-poster-2') {
        return !!this.posterSmallText;
      }

      if (this.selectedImageTemplate === 'img-small-poster-3') {
        return !!this.posterSubtitle && !!this.posterExpandedText;
      }

      return true;
    }

    // For banner, check for banner title and template selection
    if (selectedService?.id === 'banner') {
      if (!this.bannerTitle || !this.selectedImageTemplate) {
        return false;
      }
      return true;
    }

    // For other services, check if file is uploaded
    if (!this.uploadedFile) return false;
    
    // Check if template is selected
    // if (!this.selectedTemplate) return false;
    
    // Check if image template is selected
    if (!this.selectedImageTemplate) return false;
    
    // Check if at least one service is selected
    return true;
  }

  get selectedServices(): EventBrandingService[] {
    return this.eventbrandingServices.filter(s => s.selected);
  }

  get isNameTagSelected(): boolean {
    return this.eventbrandingServices.some(s => s.id === 'name-tag' && s.selected);
  }

  get isSmallPosterSelected(): boolean {
    return this.eventbrandingServices.some(s => s.id === 'small-poster' && s.selected);
  }

  get isBannerSelected(): boolean {
    return this.eventbrandingServices.some(s => s.id === 'banner' && s.selected);
  }

  close(): void {
    this.cancelStream();
    this.ddcFlowService.closeFlow();
  }

  back(): void{
    this.cancelStream();
    this.ddcFlowService.closeFlow();
    this.ddcFlowService.openGuidedDialog();
  }

  getImageTemplateId(label: string): string {
    // Convert label like "Name Tag 1" to "name_tag_01"
    // Convert label like "Table Tent 2" to "table_tent_02"
    // Convert label like "Banner 3" to "banner_03"
    
    // Extract the number from the label
    const match = label.match(/(\d+)$/);
    const number = match ? parseInt(match[1]) : 1;
    const paddedNumber = String(number).padStart(2, '0'); // Pad to 2 digits
    
    // Remove the number and convert to snake_case
    const baseLabel = label.replace(/\s*\d+\s*$/, '').trim();
    const snakeCase = baseLabel
      .toLowerCase()
      .replace(/\s+/g, '_');
    
    return `${snakeCase}_template_${paddedNumber}`;
  }

  getActionString(label: string): string {
    // Convert label like "Name tag" to "name_tag"
    // Convert label like "Table tent" to "table_tent"
    // Convert label like "Banner" to "banner"
    return label
      .toLowerCase()
      .replace(/\s+/g, '_');
  }

  createEventBrandingPayload(): FormData | null {
    if (!this.canGenerate) {
      console.error('[EventBrandingFlow] Cannot generate payload: missing required fields');
      return null;
    }

    const formData = new FormData();
    
    // Add actions (selected service label converted to snake_case string)
    const selectedService = this.selectedServices[0];
    if (selectedService) {
      const action = this.getActionString(selectedService.label);
      formData.append('action', action);
    }
    
    // Add document template (the selected template value)
    const documentTemplate = this.templates.find(t => t.value === this.selectedTemplate);
    if (documentTemplate) {
      formData.append('document_template', documentTemplate.label);
    }
    
    // Add image template (the selected image template label)
    const imageTemplate = this.imageTemplates.find(t => t.id === this.selectedImageTemplate);
    if (imageTemplate) {
      const imageTemplateId = this.getImageTemplateId(imageTemplate.label);
      formData.append('image_template_id', imageTemplateId);
    }
    
    // Add uploaded excel file (for non-small-poster services)
    if (this.uploadedFile) {
      formData.append('uploaded_excel', this.uploadedFile);
    }
    
    // Optional: Add additional metadata
    if (this.clientIdentifiers) {
      formData.append('client_identifiers', this.clientIdentifiers);
    }
    if (this.additionalGuidelines) {
      formData.append('additional_guidelines', this.additionalGuidelines);
    }
    if (this.eventName && (this.selectedImageTemplate === 'img-name-tag-1' || this.selectedImageTemplate === 'img-name-tag-2')) {
      formData.append('event_name', this.eventName);
    }
    
    // Add small poster specific fields
    if (this.isSmallPosterSelected) {
      if (this.posterTitle) {
        formData.append('poster_title', this.posterTitle);
      }
      if (this.posterDate) {
        formData.append('poster_date', this.posterDate);
      }
      if (this.posterFooterNotes) {
        formData.append('footer_notes', this.posterFooterNotes);
      }
      if (this.posterSmallText) {
        formData.append('poster_small_text', this.posterSmallText);
      }
      if (this.posterSubtitle) {
        formData.append('poster_subtitle', this.posterSubtitle);
      }
      if (this.posterExpandedText) {
        formData.append('poster_expanded_text', this.posterExpandedText);
      }
      if (this.posterIncludeCopyright) {
        formData.append('poster_include_copyright', String(this.posterIncludeCopyright));
      }
      if (this.posterSize) {
        formData.append('poster_size', this.posterSize);
      }
    }

    // Add banner specific fields
    if (this.isBannerSelected) {
      if (this.bannerTitle) {
        formData.append('banner_title', this.bannerTitle);
      }
      if (this.bannerSubtext) {
        formData.append('banner_subtext', this.bannerSubtext);
      }
      formData.append('banner_has_pwc_logo', this.bannerHasPwcLogo.toString());
    }
    
    console.log('[EventBrandingFlow] Payload created:', {
      action: selectedService?.label,
      image_template: imageTemplate?.label,
      uploaded_excel: this.uploadedFile?.name,
      poster_title: this.posterTitle,
      poster_date: this.posterDate,
      footer_notes: this.posterFooterNotes,
      poster_small_text: this.posterSmallText,
      poster_subtitle: this.posterSubtitle,
      poster_expanded_text: this.posterExpandedText,
      poster_include_copyright: this.posterIncludeCopyright,
      poster_size: this.posterSize,
      banner_title: this.bannerTitle,
      banner_subtext: this.bannerSubtext,
      banner_has_pwc_logo: this.bannerHasPwcLogo
    });
    
    return formData;
  }

  async generate(): Promise<void> {
    if (!this.canGenerate) return;

    try {
      this.isGenerating = true;
      this.generatedContent = 'Processing your event branding... This may take a moment.';
      // Hide request DDC support button when generating again
      this.showCreateRequestButton = false;
      this.showRequestForm = false;
      
      // Ensure download format is set based on selected service
      const selectedService = this.selectedServices[0];
      if (selectedService) {
        this.setDownloadFormatByService(selectedService.id);
      }
      
      console.log('[EventBrandingFlow] Additional Guidelines:', this.additionalGuidelines);

      const formData = this.createEventBrandingPayload();
      if (!formData) {
        throw new Error('Failed to create event branding payload');
      }

      // Store the payload for later re-download with proper Content-Disposition header
      this.lastEventBrandingPayload = formData;

      console.log('[EventBrandingFlow] Additional Guidelines:', this.additionalGuidelines);

      console.log('[EventBrandingFlow] Sending request with', this.selectedServices.length, 'services');

      // Call the backend to process event branding
      const apiUrl = environment.apiUrl || '';
      const response = await this.authFetchService.authenticatedFetchFormData(`${apiUrl}/api/v1/ddc/event_branding`, {
        method: 'POST',
        body: formData
      });

      if (!response.ok) {
        let errorMessage = `Event branding processing failed: ${response.statusText}`;
        try {
          const errorData = await response.json();
          if (errorData.detail) {
            // Handle nested error structure: { detail: { error: "message" } }
            if (typeof errorData.detail === 'object' && errorData.detail.error) {
              errorMessage = errorData.detail.error;
            } else if (typeof errorData.detail === 'string') {
              // Handle simple string detail: { detail: "message" }
              errorMessage = errorData.detail;
            }
          }
        } catch (e) {
          // If response is not JSON, use status text
        }
        throw new Error(errorMessage);
      }

      // Parse processing result from response headers
      const planHeader = response.headers.get('X-Processing-Plan');
      const summaryHeader = response.headers.get('X-Processing-Summary');
      const contentType = (response.headers.get('Content-Type') || '').toLowerCase();

      let planItems: any[] = [];
      let summary: any = null;

      try {
        if (planHeader) {
          planItems = JSON.parse(planHeader);
        }
        if (summaryHeader) {
          summary = JSON.parse(summaryHeader);
        }
      } catch (e) {
        console.warn('[EventBrandingFlow] Could not parse processing plan from headers', e);
      }

      // Handle both blob and URL responses
      let downloadUrl: string | undefined;
      
      if (contentType.includes('application/json')) {
        // Response is JSON - extract URL if present
        const json = await response.json();
        if (json.download_url) {
          downloadUrl = json.download_url;
        console.log('[EventBrandingFlow] Using download URL from response');
        } else {
          throw new Error('No download URL found in response');
        }
      } else {
        // Response is binary blob - create object URL
        const blob = await response.blob();
        downloadUrl = window.URL.createObjectURL(blob);
        console.log('[EventBrandingFlow] Created blob URL from binary response');
      }

      this.downloadUrl = downloadUrl;
      this.showDownloadButton = true;

      // Build clean line-by-line processing plan
      let planDisplay = '';
      if (planItems.length > 0) {
        planDisplay = '\n\nProcessing Plan:\n' + planItems.map((item: any) =>
          `✓ ${item.label}\n   ${item.details}`
        ).join('\n');
      }

      // Show success message with clean plan
      const serviceName = selectedService ? selectedService.label : 'Event branding';
      this.generatedContent = `✓ ${serviceName} generated successfully!`;
      if (summary) {
        this.generatedContent += `\n\nSummary: ${summary.items_processed} items processed, ${summary.total_changes} changes made.`;
      }

      this.isGenerating = false;

      console.log('[EventBrandingFlow] Event branding and download complete');
    } catch (error) {
      console.error('[EventBrandingFlow] Exception occurred');
      const errorMessage = error instanceof Error ? error.message : 'An unexpected error occurred. Please try again.';
      // Escape error message to prevent XSS attacks in [innerHTML] binding
      this.generatedContent = `✗ ${this.escapeHtml(errorMessage)}`;
      this.isGenerating = false;
    }
  }

  openRequestForm(): void {
    this.showRequestForm = true;
  }

  onTicketCreated(event: {requestNumber: string, phoenixRdpLink: string}): void {
    this.phoenixRdpLink = event.phoenixRdpLink;
    // Escape requestNumber to prevent XSS attacks via [innerHTML] binding
    const escapedNumber = this.escapeHtml(event.requestNumber);
    // URL in href attribute should still be validated for safe URLs (already done by Angular)
    this.generatedContent = `Request created successfully! Your request number is: <a href="${event.phoenixRdpLink}" target="_blank">${escapedNumber}</a>`;
    this.showRequestForm = false;
    this.showCreateRequestButton = false;
  }

  downloadExcelTemplate(): void {
    // Dynamically generate the file name based on the selected image template's label and category
    const imageTemplate = this.imageTemplates.find(t => t.id === this.selectedImageTemplate);
    if (!imageTemplate) {
      alert('No template file mapped for the selected template.');
      return;
    }

    // Extract base name and number from label (e.g., "Name Tag 1" -> base: "Name Tag", num: "01")
    const labelMatch = imageTemplate.label.match(/^(.*?)(\d+)$/);
    let baseName = '';
    let paddedNum = '';
    if (labelMatch) {
      baseName = labelMatch[1].trim();
      paddedNum = labelMatch[2].padStart(2, '0');
    } else {
      // fallback: use full label, no number
      baseName = imageTemplate.label.trim();
      paddedNum = '';
    }

    // Capitalize each word in baseName
    baseName = baseName.replace(/\w\S*/g, (txt) => txt.charAt(0).toUpperCase() + txt.substr(1).toLowerCase());

    // Remove any trailing spaces or dashes
    baseName = baseName.replace(/[-_]+$/, '').trim();

    // Compose file name
    const fileName = `${baseName}${paddedNum ? ' ' + paddedNum : ''}.xlsx`;
    const filePath = `assets/excel_template/${fileName}`;
    console.log('[EventBrandingFlow] Attempting to download file');

    try {
      // Show the file picker NOW while in user gesture context
      this.downloadExcelWithPicker(filePath, fileName);
    } catch (error) {
      console.error('[EventBrandingFlow] Error initiating template download:', error);
      alert('An error occurred while trying to download the file.');
    }
  }

  private async downloadExcelWithPicker(filePath: string, fileName: string): Promise<void> {
    try {
      // Show file picker NOW while still in user gesture context
      const fileHandle = await this.getFileHandleFromPicker(fileName, 'xlsx');

      // Fetch and write
      const response = await fetch(filePath);
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }
      
      const blob = await response.blob();
      await this.writeBlobToFileHandle(blob, fileHandle, fileName);
      this.excelDownloaded = true;
      console.log('[EventBrandingFlow] Template downloaded successfully');
    } catch (error: any) {
      // If user cancelled the picker, don't show error or fallback
      if (error.name === 'AbortError') {
        console.log('[EventBrandingFlow] Excel download cancelled by user');
        return;
      }
      // If API not supported, use fallback download
      if (error.message && error.message.includes('showSaveFilePicker')) {
        console.log('[EventBrandingFlow] File System Access API not available, using fallback');
        return this.downloadExcelDirect(filePath, fileName);
      }
      console.error('[EventBrandingFlow] Error downloading template:', error);
      alert('Failed to download the file. Please check the file path and try again.');
    }
  }

  private downloadExcelDirect(filePath: string, fileName: string): void {
    try {
      fetch(filePath)
        .then(response => {
          if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
          }
          return response.blob();
        })
        .then(blob => {
          // Use fallback download
          this.fallbackDownload(blob, fileName);
          this.excelDownloaded = true;
          console.log('[EventBrandingFlow] Template downloaded successfully');
        })
        .catch(error => {
          console.error('[EventBrandingFlow] Error downloading template');
          alert('Failed to download the file. Please check the file path and try again.');
        });
    } catch (error) {
      console.error('[EventBrandingFlow] Error initiating template download:', error);
      alert('An error occurred while trying to download the file.');
    }
  }

  // Store the event branding payload for re-downloading
  private lastEventBrandingPayload: FormData | null = null;

  downloadPptFile(): void {
    if (!this.downloadUrl && !this.lastEventBrandingPayload) {
      console.warn('[EventBrandingFlow] No download URL or payload available');
      this.generatedContent =
        '✗ An error occurred while preparing the file. Please try again.';
      this.isGenerating = false;
      this.showDownloadButton = false;
      this.downloadUrl = undefined;
      return;
    }

    try {
      // Set downloading state
      this.isDownloading = true;

      // Generate filename based on selected service and format
      const selectedService = this.selectedServices[0];
      const serviceNameSnakeCase = selectedService ? this.getActionString(selectedService.label) : 'event_branding';
      let filename = `generated_${serviceNameSnakeCase}.${this.selectedDownloadFormat}`;

      // If we have the payload, re-fetch from API to get the file
      if (this.lastEventBrandingPayload) {
        if (this.selectedDownloadFormat === 'png') {
          // Banner: format is uncertain (PNG if LibreOffice available, PPTX fallback).
          // Skip the file picker so we can detect the actual content-type first.
          this.downloadBannerFromApi(this.lastEventBrandingPayload, serviceNameSnakeCase);
        } else {
          // Show the picker NOW while we have user gesture context
          this.downloadFromApiWithPickerSync(this.lastEventBrandingPayload, filename, this.selectedDownloadFormat);
        }
      } else {
        // Fallback: use the stored URL
        this.downloadFromUrl(this.downloadUrl, filename);
      }

      // Mark download as successful (handled after download completes)
      console.log('[EventBrandingFlow] Download initiated with format:', this.selectedDownloadFormat);
    } catch (error) {
      console.error('[EventBrandingFlow] Error downloading file:', error);
      this.isDownloading = false;
      alert('Failed to download the file. Please try again.');
    }
  }

  private async downloadFromApiWithPickerSync(payload: FormData, filename: string, format: 'docx' | 'pptx' | 'jpeg' | 'png'): Promise<void> {
    try {
      // Show file picker NOW while still in user gesture context
      const fileHandle = await this.getFileHandleFromPicker(filename, format);
      if (!fileHandle) {
        console.log('[EventBrandingFlow] File picker cancelled or not supported');
        this.isDownloading = false;
        return;
      }

      // Continue with download
      await this.downloadFromApiWithHandle(payload, filename, format, fileHandle);
    } catch (error) {
      console.error('[EventBrandingFlow] Error in downloadFromApiWithPickerSync:', error);
      this.isDownloading = false;
    }
  }

  private async downloadBannerFromApi(payload: FormData, serviceNameSnakeCase: string): Promise<void> {
    try {
      // Fetch first to detect content type and get blob
      const apiUrl = environment.apiUrl || '';
      const response = await this.authFetchService.authenticatedFetchFormData(
        `${apiUrl}/api/v1/ddc/event_branding`,
        { method: 'POST', body: payload }
      );

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      const responseContentType = (response.headers.get('Content-Type') || '').toLowerCase();
      const blob = await response.blob();

      // Derive extension from actual response — PNG (LibreOffice) or PPTX (fallback)
      const ext = responseContentType.includes('presentationml.presentation') ? 'pptx' : 'png';
      const filename = `generated_${serviceNameSnakeCase}.${ext}`;

      // Show file picker NOW for user to select save location
      const fileHandle = await this.getFileHandleFromPicker(filename, ext as 'pptx' | 'png');
      if (!fileHandle) {
        console.log('[EventBrandingFlow] File picker cancelled by user');
        this.isDownloading = false;
        return;
      }

      // Write blob to selected file location
      await this.writeBlobToFileHandle(blob, fileHandle, filename);

      this.downloadSuccessful = true;
      this.generatedContent = '✓ Document downloaded successfully!';
      this.showDownloadButton = false;
      this.showCreateRequestButton = true;
      this.isDownloading = false;
    } catch (error: any) {
      console.error('[EventBrandingFlow] Error downloading banner:', error);
      if (error.name === 'AbortError') {
        console.log('[EventBrandingFlow] File picker cancelled by user');
        this.isDownloading = false;
        return;
      }
      this.isDownloading = false;
      alert('Failed to download the file. Please try again.');
    }
  }

  private async downloadFromApiWithHandle(payload: FormData, filename: string, format: 'docx' | 'pptx' | 'jpeg' | 'png', fileHandle: any): Promise<void> {
    const apiUrl = environment.apiUrl || '';
    
    try {
      // Create a copy of the payload and add the download format
      const formDataWithFormat = new FormData();
      
      // Copy existing form data
      payload.forEach((value, key) => {
        formDataWithFormat.append(key, value);
      });
      
      // Add the download format parameter
      formDataWithFormat.append('download_format', format);
      
      console.log('[EventBrandingFlow] Requesting download in format:', format);

      // Fetch the document from the API
      const response = await this.authFetchService.authenticatedFetchFormData(
        `${apiUrl}/api/v1/ddc/event_branding`,
        { method: 'POST', body: formDataWithFormat }
      );

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      const blob = await response.blob();

      await this.writeBlobToFileHandle(blob, fileHandle, filename);

      // Mark download as successful after download completes
      this.downloadSuccessful = true;
      this.generatedContent = '✓ Document downloaded successfully!';
      this.showDownloadButton = false;
      this.showCreateRequestButton = true;
      this.isDownloading = false;
    } catch (error) {
      console.error('[EventBrandingFlow] Error fetching document for download:', error);
      this.isDownloading = false;
      // Fallback to using the stored URL if fetch fails
      if (this.downloadUrl) {
        this.downloadFromUrl(this.downloadUrl, filename);
      } else {
        alert('Failed to download the file. Please try again.');
      }
    }
  }

  private async downloadFromApi(payload: FormData, filename: string, format: 'docx' | 'pptx' | 'jpeg' | 'png'): Promise<void> {
    const apiUrl = environment.apiUrl || '';
    
    try {
      // Get file handle FIRST while in user gesture context (before async operations)
      const fileHandle = await this.getFileHandleFromPicker(filename, format);
      if (!fileHandle) {
        console.log('[EventBrandingFlow] File picker cancelled by user');
        return;
      }

      // Create a copy of the payload and add the download format
      const formDataWithFormat = new FormData();
      
      // Copy existing form data
      payload.forEach((value, key) => {
        formDataWithFormat.append(key, value);
      });
      
      // Add the download format parameter
      formDataWithFormat.append('download_format', format);
      
      console.log('[EventBrandingFlow] Requesting download in format:', format);

      // Fetch the document from the API
      const response = await this.authFetchService.authenticatedFetchFormData(
        `${apiUrl}/api/v1/ddc/event_branding`,
        { method: 'POST', body: formDataWithFormat }
      );

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      const blob = await response.blob();
      
      // Write blob to file handle
      await this.writeBlobToFileHandle(blob, fileHandle, filename);
      
      // Mark download as successful after download completes
      this.downloadSuccessful = true;
      this.generatedContent = '✓ Document downloaded successfully!';
      this.showDownloadButton = false;
      this.showCreateRequestButton = true;
    } catch (error) {
      console.error('[EventBrandingFlow] Error fetching document for download:', error);
      // Fallback to using the stored URL if fetch fails
      if (this.downloadUrl) {
        this.downloadFromUrl(this.downloadUrl, filename);
      } else {
        alert('Failed to download the file. Please try again.');
      }
    }
  }

  private async getFileHandleFromPicker(filename: string, format: 'docx' | 'pptx' | 'jpeg' | 'png' | 'xlsx'): Promise<any> {
    // Check if File System Access API is available
    if (!('showSaveFilePicker' in window)) {
      console.log('[EventBrandingFlow] File System Access API not available');
      throw new Error('showSaveFilePicker not available');
    }

    try {
      const ext = filename.split('.').pop()?.toLowerCase() || '';
      const mimeType = this.getMimeTypeForFormat(format);
      
      console.log('[EventBrandingFlow] Showing save dialog');
      
      const handle = await (window as any).showSaveFilePicker({
        suggestedName: filename,
        types: [
          {
            description: `${ext.toUpperCase()} Files`,
            accept: { [mimeType]: [`.${ext}`] }
          }
        ]
      });
      
      return handle;
    } catch (error: any) {
      if (error.name === 'AbortError') {
        console.log('[EventBrandingFlow] Save dialog cancelled by user');
        // Re-throw AbortError so caller can handle cancellation
        throw error;
      }
      console.error('[EventBrandingFlow] Error showing save picker:', error);
      throw error;
    }
  }

  private async writeBlobToFileHandle(blob: Blob, fileHandle: any, filename: string): Promise<void> {
    try {
      const writable = await fileHandle.createWritable();
      
      // For large files, write in chunks to avoid memory issues
      const CHUNK_SIZE = 1024 * 1024; // 1MB chunks
      if (blob.size > CHUNK_SIZE) {
        console.log('[EventBrandingFlow] Writing large file in chunks');
        // let offset = 0;
        // while (offset < blob.size) {
        //   const chunkEnd = Math.min(offset + CHUNK_SIZE, blob.size);
        //   const chunk = blob.slice(offset, chunkEnd);
        //   await writable.write(chunk);
        //   offset = chunkEnd
        const safeBlob = new Blob([await blob.arrayBuffer()], {
  type: 'application/octet-stream'
});
 
const writable = await fileHandle.createWritable();
await writable.write(await safeBlob.arrayBuffer());
await writable.close();
        
      } else {
        // await writable.write(blob);
        const safeBlob = new Blob([await blob.arrayBuffer()], {
  type: 'application/octet-stream'
});
 
const writable = await fileHandle.createWritable();
await writable.write(await safeBlob.arrayBuffer());
      }
      
      await writable.close();
      console.log('[EventBrandingFlow] File saved successfully');
    } catch (error) {
      console.error('[EventBrandingFlow] Error writing to file handle:', error);
      throw error;
    }
  }

  /**
   * Escapes HTML special characters to prevent XSS attacks
   * Converts text input to safe HTML by using textContent and reading back innerHTML
   */
  private escapeHtml(text: string): string {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
  }

  private getMimeTypeForFormat(format: 'docx' | 'pptx' | 'jpeg' | 'png' | 'xlsx'): string {
    switch (format) {
      case 'docx':
        return 'application/vnd.openxmlformats-officedocument.wordprocessingml.document';
      case 'pptx':
        return 'application/vnd.openxmlformats-officedocument.presentationml.presentation';
      case 'xlsx':
        return 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet';
      case 'jpeg':
        return 'image/jpeg';
      case 'png':
        return 'image/png';
      default:
        return 'application/octet-stream';
    }
  }

private fallbackDownload(blob: Blob, filename: string): void {
  // ✅ Sanitize the filename
  const safeFilename = filename
   .replace(/[^a-zA-Z0-9._-]/g, '_')
   .replace(/_{2,}/g, '_')
   .replace(/^_+|_+$/g, '') || 'download';
  // ✅ Create a safe blob with correct MIME (optional, use blob.type if already safe)
  const safeBlob = new Blob([blob], { type: blob.type || 'application/octet-stream' });
  // ✅ Use FileSaver.js to trigger the download
  saveAs(safeBlob, safeFilename);
}

  // private downloadFromUrl(url: string | undefined, filename: string): void {
  //   if (!url) return;

  //   try {
  //     const link = document.createElement('a');
  //     link.href = url;
  //     link.download = filename;
  //     link.style.display = 'none';
  //     document.body.appendChild(link);
  //     link.click();

  //     // Clean up
  //     setTimeout(() => {
  //       document.body.removeChild(link);
  //       if (url.startsWith('blob:')) {
  //         window.URL.revokeObjectURL(url);
  //       }
  //     }, 100);
  //   } catch (error) {
  //     console.error('[EventBrandingFlow] Error using download URL:', error);
  //   }
  // }


private downloadFromUrl(

  url: string | undefined,

  filename: string

): void {

  if (!url) return;
 
  try {

    const parsedUrl = new URL(url);
 
    // ✅ Allow only HTTPS + Blob URLs

    if (

      parsedUrl.protocol !== 'https:' &&

      parsedUrl.protocol !== 'blob:'

    ) {

      throw new Error('Invalid protocol');

    }
 
    // ✅ Validate host only for HTTPS

    if (parsedUrl.protocol === 'https:') {

      const allowedHosts = [

        'webapp-bsc-mcx.dev.ngc.pwcinternal.com',

        'webapp-bsc-mcx.ngc.pwcinternal.com'

      ];
 
      const isAllowedHost = allowedHosts.some(

        host =>

          parsedUrl.hostname === host ||

          parsedUrl.hostname.endsWith(`.${host}`)

      );
 
      if (!isAllowedHost) {

        throw new Error('Untrusted host');

      }

    }
 
    // ✅ Safe filename cleanup

    const safeFilename =

      filename

        .replace(/[^a-zA-Z0-9._-]/g, '_')

        .replace(/_{2,}/g, '_')

        .replace(/^_+|_+$/g, '') || 'download';
 
    // ✅ SAFE URL DOWNLOAD

    saveAs(parsedUrl.toString(), safeFilename);
 
    // ✅ Cleanup blob URLs after save

    if (parsedUrl.protocol === 'blob:') {

      setTimeout(() => {

        window.URL.revokeObjectURL(parsedUrl.toString());

      }, 1000);

    }
 
  } catch (error) {

    console.error(

      '[EventBrandingFlow] Error using secure download URL:',

      error

    );

  }

}

 
}
