import { Component, Input, OnInit, OnDestroy, ViewChild, ElementRef } from '@angular/core';
import { DomSanitizer, SafeHtml } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';
import { firstValueFrom, Subject, Subscription, takeUntil } from 'rxjs';
import { DdcFlowService } from '../../../core/services/ddc-flow.service';
import { ChatService } from '../../../core/services/chat.service';
import { FileUploadComponent } from '../../../shared/ui/components/file-upload/file-upload.component';
import { DDCRequestFormComponent } from '../../phoenix/ddc/request-form-ddc';
import { AuthFetchService } from '../../../core/services/auth-fetch.service';
import {saveAs} from 'file-saver';

@Component({
    selector: 'app-slide-creation-flow',
    imports: [FormsModule, FileUploadComponent, DDCRequestFormComponent],
    templateUrl: './slide-creation-flow.component.html',
    styleUrls: ['./slide-creation-flow.component.scss']
})
export class SlideCreationFlowComponent implements OnInit, OnDestroy {
  readonly templateOptions: Array<{ name: string; id: string }> = [
    { name: 'PwC 2025 brand template', id: 'YGw8kjq05qPFKRUpe2cOjY' },
    { name: 'Strategy & brand template', id: 'oHVzxOde3Ie3J7Avpuo2kr' }
  ];

  // Input properties from parent component
  @Input() hideBackButton: boolean = false;
  @Input() openedFrom: 'quick-action' | 'guided-dialog' | null = null;
  @ViewChild('outlineFileUpload') outlineFileUpload?: FileUploadComponent;
  @ViewChild('chartDataFileUpload') chartDataFileUpload?: FileUploadComponent;
  
  isOpen = false;
  isGenerating = false;
  generatedContent = '';
  showDownloadButton = true;
  showDownloadButton1 = false;
  downloadUrl : string | undefined;
  showCreateRequestButton = false;
  showRequestForm = false;
  
  // File uploads
  uploadedFile: File | null = null;
  selectedTemplate = this.templateOptions[0].id;
  customTemplateFile: File | null = null;
  chartDataFile: File | null = null;
  outlineUploadError = false;
  chartDataUploadError = false;
  
  // Additional fields
  additionalGuidelines = '';

  private destroy$ = new Subject<void>();
  private streamSubscription?: Subscription;

  constructor(
    private ddcFlowService: DdcFlowService,
    private chatService: ChatService,
    private authFetchService: AuthFetchService,
    private sanitizer: DomSanitizer
  ) {}

  ngOnInit(): void {
    this.ddcFlowService.activeFlow$
      .pipe(takeUntil(this.destroy$))
      .subscribe(flow => {
        this.isOpen = flow === 'slide-creation';
        if (this.isOpen) {
          this.resetForm();
        }
      });
  }

  ngOnDestroy(): void {
    this.cancelStream();
    this.destroy$.next();
    this.destroy$.complete();
  }

  private cancelStream(): void {
    if (this.streamSubscription) {
      console.log('[SlideCreationFlow] Cancelling active stream');
      this.streamSubscription.unsubscribe();
      this.streamSubscription = undefined;
      this.isGenerating = false;
    }
  }

  resetForm(): void {
    this.uploadedFile = null;
    this.selectedTemplate = this.templateOptions[0].id;
    this.customTemplateFile = null;
    this.chartDataFile = null;
    this.additionalGuidelines = '';
    this.generatedContent = '';
    this.isGenerating = false;
    this.outlineUploadError = false;
    this.chartDataUploadError = false;
  }

  onFileSelected(file: File): void {
    // Validate file format for outline upload
    const acceptedFormats = ['.doc', '.docx', '.pdf'];
    
    const fileExtension = file.name.substring(file.name.lastIndexOf('.')).toLowerCase();
    const isValidFormat = acceptedFormats.includes(fileExtension);
    
    if (!isValidFormat) {
      console.warn(`[SlideCreationFlow] Invalid file format: ${file.name}. Accepted formats: .doc, .docx, .pdf`);
      this.outlineUploadError = true;
      // Reset the file upload component to prevent invalid file from being stored
      if (this.outlineFileUpload) {
        this.outlineFileUpload.reset();
      }
      return;
    }
    
    this.outlineUploadError = false;
    this.uploadedFile = file;
  }

  onFileRemoved(): void {
    this.uploadedFile = null;
    this.outlineUploadError = false;
  }

  onTemplateFileSelected(file: File): void {
    this.customTemplateFile = file;
  }

  onChartDataSelected(file: File): void {
    // Validate file format - only .xlsx allowed
    const acceptedFormats = ['.xlsx'];
    const fileExtension = file.name.substring(file.name.lastIndexOf('.')).toLowerCase();
    const isValidFormat = acceptedFormats.includes(fileExtension);
    
    if (!isValidFormat) {
      console.warn(`[SlideCreationFlow] Invalid chart data file format: ${file.name}. Accepted formats: .xlsx`);
      this.chartDataUploadError = true;
      // Reset the file upload component to prevent invalid file from being stored
      if (this.chartDataFileUpload) {
        this.chartDataFileUpload.reset();
      }
      return;
    }
    
    this.chartDataUploadError = false;
    this.chartDataFile = file;
  }

  get needsCustomTemplate(): boolean {
    return this.selectedTemplate === 'client-specific' || this.selectedTemplate === 'other';
  }

  onTemplateChange(): void {
    if (!this.needsCustomTemplate) {
      this.customTemplateFile = null;
    }
  }

  get canGenerate(): boolean {
    if (!this.uploadedFile) return false;
    //if (!this.selectedTemplate.trim()) return false;
    //if (this.needsCustomTemplate && !this.customTemplateFile) return false;
    return true;
    //return this.additionalGuidelines.trim().length > 0;;
    /*
    return (
    (this.additionalGuidelines?.trim().length > 0) ||
    (this.uploadedFile !== null)
  );
  */
  }

  close(): void {
    this.cancelStream();
    this.ddcFlowService.closeFlow();
  }

  back(): void{
    this.cancelStream();
    this.ddcFlowService.closeFlow();
    this.ddcFlowService.openGuidedDialog();
  }

  async generate(): Promise<void> {
    if (!this.uploadedFile) {
      console.error('No file uploaded');
      return;
    }

    // if (!this.additionalGuidelines || this.additionalGuidelines.trim().length === 0) {
    // console.error('[SlideCreationFlow] additionalGuidelines is required');
    // return;
  //}
    this.cancelStream(); // ensure no active stream
    this.isGenerating = true;
    this.generatedContent = '';

    try {
      const formData = new FormData();
      if (this.uploadedFile) {
      formData.append('file', this.uploadedFile);
    }

    const selectedTemplateOption = this.templateOptions.find(option => option.id === this.selectedTemplate);
    if (selectedTemplateOption) {
      formData.append('template_name', selectedTemplateOption.name);
      formData.append('template_id', selectedTemplateOption.id);
      // Preserve legacy field for backward compatibility while backend transitions.
      // formData.append('template', selectedTemplateOption.name);
    }
      //formData.append('file', this.uploadedFile);
      //formData.append('template', this.selectedTemplate);
      
      if (this.customTemplateFile) {
        formData.append('custom_template_file', this.customTemplateFile);
      }
      
      if (this.chartDataFile) {
        formData.append('chart_data_file', this.chartDataFile);
      }

      if (this.additionalGuidelines=="") {
        formData.append('additional_guidelines','Follow the guidelines while creating the presentation');
      }
      else{
        formData.append('additional_guidelines',this.additionalGuidelines);
      }
      //formData.append('additional_guidelines', this.additionalGuidelines);

      console.log('[SlideCreationFlow] Sending request:', {
        //fileName: this.uploadedFile.name,
        fileName: this.uploadedFile?.name ?? null,
        templateName: selectedTemplateOption?.name || null,
        templateId: selectedTemplateOption?.id || null,
        hasCustomTemplate: !!this.customTemplateFile,
        hasChartData: !!this.chartDataFile,
        hasGuidelines: !!this.additionalGuidelines
      });
      /*
      this.streamSubscription = this.chatService.streamDdcSlideCreation(formData).subscribe({
        next: (chunk: string) => {
          this.generatedContent += chunk;
        },
        error: (error: Error) => {
          console.error('[SlideCreationFlow] Error:', error);
          this.generatedContent = 'I apologize, but I encountered an error creating the slides. Please try again.';
          this.isGenerating = false;
          this.streamSubscription = undefined;
        },
        complete: () => {
          console.log('[SlideCreationFlow] Generation complete');
          this.isGenerating = false;
          this.streamSubscription = undefined;
        }
      });
      */
      //const response: any = await this.chatService.createDdcSlide(formData).toPromise();
        const response: any = await firstValueFrom(this.chatService.createDdcSlide(formData));
      if (response?.status === 'success' && response?.download_url) {
        this.generatedContent = `Slide(s) generated successfully!`;
        this.showDownloadButton = true;
        // Validate URL to prevent XSS via malicious download_url from backend response
        try {
          this.validateAndEscapeUrl(response.download_url);
          this.downloadUrl = response.download_url;
          console.log('[SlideCreationFlow] Download URL validated:', response.download_url);
        } catch (error) {
          console.error('[SlideCreationFlow] Invalid download URL:', error);
          this.generatedContent = '✗ Error: Invalid download URL received from server. Please try again.';
          this.downloadUrl = undefined;
          this.showDownloadButton = false;
        }
      } else {
        this.generatedContent = '✗ Slide generation failed. Please try again.';
        this.downloadUrl = undefined;
        this.showDownloadButton = false;
        console.error('[SlideCreationFlow] Unexpected response:', response);
      }

    } catch (error) {
      console.error('[SlideCreationFlow] Exception:', error);
      this.generatedContent =
      '✗ An error occurred while generating the slides. Please try again.';
      this.isGenerating = false;
      this.showDownloadButton = false;
      this.downloadUrl = undefined;
    }finally {
    this.isGenerating = false; // ensure spinner stops
  }
  }

  downloadProcessedFile(): void {
    if (!this.downloadUrl) {
      console.warn('[SlideCreationFlow] No download URL available');
      this.generatedContent =
      '✗ An error occurred while generating the slides. Please try again.';
      this.isGenerating = false;
      this.showDownloadButton = false;
      this.downloadUrl = undefined;
      return;
    }

    // Use save dialog instead of direct download to Downloads folder
    fetch(this.downloadUrl)
    .then(response => response.blob())
    .then(blob => {
      return this.downloadBlobWithSaveDialog(blob, 'Generated_Presentation.pptx');
    })
    .finally(() => {
      this.showDownloadButton = false;
      // this.generatedContent = "You may request ddc support by clicking on the button below"
      this.showCreateRequestButton = true;
    })
    .catch(err => console.error('Download error:', err));
  }

  private async downloadBlobWithSaveDialog(blob: Blob, filename: string): Promise<void> {
    // Check if File System Access API is available (Chrome, Edge, Firefox with flag)
    if ('showSaveFilePicker' in window) {
      try {
        const ext = filename.split('.').pop()?.toLowerCase() || '';
        let mimeType = blob.type || 'application/octet-stream';
        
        // Map extensions to proper MIME types
        if (!blob.type || blob.type === 'application/octet-stream') {
          switch (ext) {
            case 'pptx':
              mimeType = 'application/vnd.openxmlformats-officedocument.presentationml.presentation';
              break;
            case 'docx':
              mimeType = 'application/vnd.openxmlformats-officedocument.wordprocessingml.document';
              break;
            case 'pdf':
              mimeType = 'application/pdf';
              break;
          }
        }
        
        const handle = await (window as any).showSaveFilePicker({
          suggestedName: filename,
          types: [
            {
              description: `${ext.toUpperCase()} Files`,
              accept: { [mimeType]: [`.${ext}`] }
            }
          ]
        });
        const safeBlob = new Blob([await blob.arrayBuffer()], {
  type: 'application/octet-stream'
});
 
const writable = await handle.createWritable();
await writable.write(await safeBlob.arrayBuffer());
await writable.close();
      } catch (error: any) {
        if (error.name !== 'AbortError') {
          console.error('Error saving file with dialog:', error);
          // Fallback to direct download if dialog fails
          this.fallbackDownload(blob, filename);
        }
      }
    } else {
      // Fallback for browsers without File System Access API
      this.fallbackDownload(blob, filename);
    }
  }

  private fallbackDownload(blob: Blob, filename: string): void {
  // ✅ Sanitize the filename
  const safeFilename = filename
    .replace(/[^a-zA-Z0-9._-]/g, '_')
    .replace(/_{2,}/g, '_')
    .replace(/^_+|_+$/g, '') || 'download';

  // ✅ Create a safe blob with correct MIME (optional, use blob.type if already safe)
  const safeBlob = new Blob([blob], { type: blob.type || 'application/octet-stream' });

  // ✅ Use FileSaver.js to trigger the download
  saveAs(safeBlob, safeFilename);
}

  openRequestForm() {
  this.showRequestForm = true;
}

phoenixRdpLink = '';

onTicketCreated(event: {
  requestNumber: string;
  phoenixRdpLink: string;
}): void {
  // Validate and escape untrusted data before using in HTTP response
  try {
    this.validateAndEscapeUrl(event.phoenixRdpLink);
    const escapedRequestNumber = this.escapeHtmlSpecialChars(event.requestNumber);
    const escapedLink = this.escapeHtmlAttribute(event.phoenixRdpLink);
    this.phoenixRdpLink = event.phoenixRdpLink;
    console.log('Ticket created:', event.requestNumber);
    this.generatedContent = `Request created successfully! Your request number is: <a href="${escapedLink}" target="_blank" rel="noopener noreferrer">${escapedRequestNumber}</a>`;
  } catch (error) {
    console.error('[SlideCreationFlow] Invalid ticket data:', error);
    this.generatedContent = 'Error processing request. Please try again.';
  }
  this.showRequestForm = false;
  this.showCreateRequestButton = false;
}

/**
 * Escape HTML special characters to prevent XSS attacks
 */
private escapeHtmlSpecialChars(untrustedData: string): string {
  if (!untrustedData) return '';
  const div = document.createElement('div');
  div.textContent = untrustedData;
  return div.innerHTML;
}

/**
 * Escape data for use in HTML attributes
 */
private escapeHtmlAttribute(untrustedData: string): string {
  if (!untrustedData) return '';
  return untrustedData
    .replace(/&/g, '&amp;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#x27;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;');
}

/**
 * Validate URL to prevent open redirect attacks
 */
private validateAndEscapeUrl(urlString: string): void {
  if (!urlString) throw new Error('URL is empty');
  
  try {
    const url = new URL(urlString);
    
    if (!['http:', 'https:'].includes(url.protocol)) {
      throw new Error(`Invalid protocol: ${url.protocol}`);
    }
  } catch (error) {
    throw new Error(`URL validation failed: ${error instanceof Error ? error.message : 'Invalid URL'}`);
  }
}
}
