import { Component, Input, OnInit, OnDestroy, ViewChild } from '@angular/core';
import { DomSanitizer, SafeHtml } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';
import { firstValueFrom, Subject, Subscription, takeUntil } from 'rxjs';
import { DdcFlowService } from '../../../core/services/ddc-flow.service';
import { ChatService } from '../../../core/services/chat.service';
import { FileUploadComponent } from '../../../shared/ui/components/file-upload/file-upload.component';
import { DDCRequestFormComponent } from '../../phoenix/ddc/request-form-ddc';
import { AuthFetchService } from '../../../core/services/auth-fetch.service';
import { environment } from '../../../../environments/environment';
import {saveAs} from 'file-saver';

@Component({
    selector: 'app-slide-creation-prompt-flow',
    imports: [FormsModule, FileUploadComponent, DDCRequestFormComponent],
    templateUrl: './slide-creation-prompt-flow.component.html',
    styleUrls: ['./slide-creation-prompt-flow.component.scss']
})
export class SlideCreationPromptFlowComponent implements OnInit, OnDestroy {
  // Input properties from parent component
  @Input() hideBackButton: boolean = false;
  @Input() openedFrom: 'quick-action' | 'guided-dialog' | null = null;
  @ViewChild('scopeOfWorkUpload') scopeOfWorkUpload?: FileUploadComponent;
  @ViewChild('supportingDocUpload') supportingDocUpload?: FileUploadComponent;
  @ViewChild('sowTemplateUpload') sowTemplateUpload?: FileUploadComponent;

  isOpen = false;
  isGenerating = false;
  generatedContent = '';
  showDownloadButton = true;
  showDownloadButton1 = false;
  downloadUrl : string | undefined;
  showCreateRequestButton = false;
  showRequestForm = false;

  // File uploads
  scopeOfWorkFile: File | null = null;
  supportingDocFile: File | null = null;
  sowTemplateFile: File | null = null;

  // Upload error flags
  scopeOfWorkUploadError = false;
  supportingDocUploadError = false;
  sowTemplateUploadError = false;

  // Extracted text from uploads
  scopeOfWorkExtractedText = '';
  supportingDocExtractedText = '';
  isExtractingScopeOfWork = false;
  isExtractingSupportingDoc = false;

  // Text fields
  prid = '';
  flexId = '';

  // Toggle
  lookupInIcertis = false;

  private destroy$ = new Subject<void>();
  private streamSubscription?: Subscription;

  constructor(
    private ddcFlowService: DdcFlowService,
    private chatService: ChatService,
    private authFetchService: AuthFetchService,
    private sanitizer: DomSanitizer
  ) {}

  ngOnInit(): void {
    this.ddcFlowService.activeFlow$
      .pipe(takeUntil(this.destroy$))
      .subscribe(flow => {
        this.isOpen = flow === 'slide-creation-prompt';
        if (this.isOpen) {
          this.resetForm();
        }
      });
  }

  ngOnDestroy(): void {
    this.cancelStream();
    this.destroy$.next();
    this.destroy$.complete();
  }

  private cancelStream(): void {
    if (this.streamSubscription) {
      console.log('[SlideCreationPromptFlow] Cancelling active stream');
      this.streamSubscription.unsubscribe();
      this.streamSubscription = undefined;
      this.isGenerating = false;
    }
  }

  resetForm(): void {
    this.scopeOfWorkFile = null;
    this.supportingDocFile = null;
    this.sowTemplateFile = null;
    this.prid = '';
    this.flexId = '';
    this.lookupInIcertis = false;
    this.generatedContent = '';
    this.isGenerating = false;
    this.scopeOfWorkUploadError = false;
    this.supportingDocUploadError = false;
    this.sowTemplateUploadError = false;
    this.scopeOfWorkExtractedText = '';
    this.supportingDocExtractedText = '';
    this.isExtractingScopeOfWork = false;
    this.isExtractingSupportingDoc = false;
  }

  // --- Extract text from file via /api/v1/export/extract-text ---
  private async extractTextFromFile(file: File): Promise<string> {
    const apiUrl = (window as any)._env?.apiUrl || environment.apiUrl || '';
    const endpoint = `${apiUrl}/api/v1/export/extract-text`;

    const formData = new FormData();
    formData.append('file', file);

    const response = await this.authFetchService.authenticatedFetchFormData(endpoint, {
      method: 'POST',
      body: formData
    });

    if (!response.ok) {
      throw new Error(`Extract-text failed: ${response.status}`);
    }

    const data = await response.json();
    return data.text || '';
  }

  // --- Scope of Work ---
  onScopeOfWorkSelected(file: File): void {
    const acceptedFormats = ['.doc', '.docx', '.pdf', '.pptx', '.xlsx'];
    const fileExtension = file.name.substring(file.name.lastIndexOf('.')).toLowerCase();

    if (!acceptedFormats.includes(fileExtension)) {
      console.warn(`[SlideCreationPromptFlow] Invalid scope of work file format: ${file.name}`);
      this.scopeOfWorkUploadError = true;
      if (this.scopeOfWorkUpload) {
        this.scopeOfWorkUpload.reset();
      }
      return;
    }

    this.scopeOfWorkUploadError = false;
    this.scopeOfWorkFile = file;
    this.isExtractingScopeOfWork = true;
    this.scopeOfWorkExtractedText = '';

    this.extractTextFromFile(file)
      .then(text => {
        this.scopeOfWorkExtractedText = text;
        console.log(`[SlideCreationPromptFlow] Scope of work text extracted (${text.length} chars)`);
      })
      .catch(err => {
        console.error('[SlideCreationPromptFlow] Failed to extract scope of work text:', err);
        this.scopeOfWorkExtractedText = '';
      })
      .finally(() => {
        this.isExtractingScopeOfWork = false;
      });
  }

  onScopeOfWorkRemoved(): void {
    this.scopeOfWorkFile = null;
    this.scopeOfWorkUploadError = false;
    this.scopeOfWorkExtractedText = '';
    this.isExtractingScopeOfWork = false;
  }

  // --- Supporting Document ---
  onSupportingDocSelected(file: File): void {
    const acceptedFormats = ['.doc', '.docx', '.pdf', '.pptx'];
    const fileExtension = file.name.substring(file.name.lastIndexOf('.')).toLowerCase();

    if (!acceptedFormats.includes(fileExtension)) {
      console.warn(`[SlideCreationPromptFlow] Invalid supporting doc file format: ${file.name}`);
      this.supportingDocUploadError = true;
      if (this.supportingDocUpload) {
        this.supportingDocUpload.reset();
      }
      return;
    }

    this.supportingDocUploadError = false;
    this.supportingDocFile = file;
    this.isExtractingSupportingDoc = true;
    this.supportingDocExtractedText = '';

    this.extractTextFromFile(file)
      .then(text => {
        this.supportingDocExtractedText = text;
        console.log(`[SlideCreationPromptFlow] Supporting doc text extracted (${text.length} chars)`);
      })
      .catch(err => {
        console.error('[SlideCreationPromptFlow] Failed to extract supporting doc text:', err);
        this.supportingDocExtractedText = '';
      })
      .finally(() => {
        this.isExtractingSupportingDoc = false;
      });
  }

  onSupportingDocRemoved(): void {
    this.supportingDocFile = null;
    this.supportingDocUploadError = false;
    this.supportingDocExtractedText = '';
    this.isExtractingSupportingDoc = false;
  }

  // --- SOW Template ---
  onSowTemplateSelected(file: File): void {
    const acceptedFormats = ['.doc', '.docx', '.pdf', '.pptx'];
    const fileExtension = file.name.substring(file.name.lastIndexOf('.')).toLowerCase();

    if (!acceptedFormats.includes(fileExtension)) {
      console.warn(`[SlideCreationPromptFlow] Invalid SOW template file format: ${file.name}`);
      this.sowTemplateUploadError = true;
      if (this.sowTemplateUpload) {
        this.sowTemplateUpload.reset();
      }
      return;
    }

    this.sowTemplateUploadError = false;
    this.sowTemplateFile = file;
  }

  onSowTemplateRemoved(): void {
    this.sowTemplateFile = null;
    this.sowTemplateUploadError = false;
  }

  get canGenerate(): boolean {
    if (!this.scopeOfWorkFile) return false;
    if (!this.prid.trim()) return false;
    if (!this.flexId.trim()) return false;
    if (this.isExtractingScopeOfWork || this.isExtractingSupportingDoc) return false;
    return true;
  }

  close(): void {
    this.cancelStream();
    this.ddcFlowService.closeFlow();
  }

  back(): void{
    this.cancelStream();
    this.ddcFlowService.closeFlow();
    this.ddcFlowService.openGuidedDialog();
  }

  async generate(): Promise<void> {
    if (!this.scopeOfWorkFile) {
      console.error('[SlideCreationPromptFlow] No scope of work file uploaded');
      return;
    }

    if (!this.prid.trim() || !this.flexId.trim()) {
      console.error('[SlideCreationPromptFlow] PRID and Flex ID are required');
      return;
    }

    this.cancelStream();
    this.isGenerating = true;
    this.generatedContent = '';

    try {
      const formData = new FormData();
      formData.append('scope_of_work_file', this.scopeOfWorkFile);
      formData.append('scope_of_work_text', this.scopeOfWorkExtractedText);

      if (this.supportingDocFile) {
        formData.append('supporting_document_file', this.supportingDocFile);
        formData.append('supporting_document_text', this.supportingDocExtractedText);
      }

      formData.append('prid', this.prid.trim());
      formData.append('flex_id', this.flexId.trim());

      if (this.sowTemplateFile) {
        formData.append('sow_template', this.sowTemplateFile);
      }

      formData.append('lookup_in_icertis', String(this.lookupInIcertis));

      console.log('[SlideCreationPromptFlow] Sending request:', {
        scopeOfWorkFileName: this.scopeOfWorkFile.name,
        scopeOfWorkTextLength: this.scopeOfWorkExtractedText.length,
        hasSupportingDoc: !!this.supportingDocFile,
        supportingDocTextLength: this.supportingDocExtractedText.length,
        prid: this.prid.trim(),
        flexId: this.flexId.trim(),
        hasSowTemplate: !!this.sowTemplateFile,
        lookupInIcertis: this.lookupInIcertis
      });

      const response: any = await firstValueFrom(this.chatService.createDdcSow(formData));
      if (response?.status === 'success' && response?.download_url) {
        this.generatedContent = `Draft contract generated successfully!`;
        this.showDownloadButton = true;
        try {
          this.validateAndEscapeUrl(response.download_url);
          this.downloadUrl = response.download_url;
          console.log('[SlideCreationPromptFlow] Download URL generated');
        } catch (error) {
          console.error('[SlideCreationPromptFlow] Invalid download URL');
          this.generatedContent = 'Error: Invalid download URL received from server. Please try again.';
          this.downloadUrl = undefined;
          this.showDownloadButton = false;
        }
      } else {
        this.generatedContent = 'Draft contract generation failed. Please try again.';
        this.downloadUrl = undefined;
        this.showDownloadButton = false;
        console.error('[SlideCreationPromptFlow] Unexpected response format');
      }

    } catch (error) {
      console.error('[SlideCreationPromptFlow] Exception occurred');
      this.generatedContent =
      'An error occurred while generating the draft contract. Please try again.';
      this.isGenerating = false;
      this.showDownloadButton = false;
      this.downloadUrl = undefined;
    } finally {
      this.isGenerating = false;
    }
  }

  downloadProcessedFile(): void {
    if (!this.downloadUrl) {
      console.warn('[SlideCreationPromptFlow] No download URL available');
      this.generatedContent =
      'An error occurred while generating the draft contract. Please try again.';
      this.isGenerating = false;
      this.showDownloadButton = false;
      this.downloadUrl = undefined;
      return;
    }

    fetch(this.downloadUrl)
    .then(response => response.blob())
    .then(blob => {
      return this.downloadBlobWithSaveDialog(blob, 'Generated_Draft_Contract.docx');
    })
    .finally(() => {
      this.showDownloadButton = false;
      this.showCreateRequestButton = true;
    })
    .catch(err => console.error('[SlideCreationPromptFlow] Download error'));
  }

  private async downloadBlobWithSaveDialog(blob: Blob, filename: string): Promise<void> {
    if ('showSaveFilePicker' in window) {
      try {
        const ext = filename.split('.').pop()?.toLowerCase() || '';
        let mimeType = blob.type || 'application/octet-stream';

        if (!blob.type || blob.type === 'application/octet-stream') {
          switch (ext) {
            case 'pptx':
              mimeType = 'application/vnd.openxmlformats-officedocument.presentationml.presentation';
              break;
            case 'docx':
              mimeType = 'application/vnd.openxmlformats-officedocument.wordprocessingml.document';
              break;
            case 'pdf':
              mimeType = 'application/pdf';
              break;
          }
        }

        const handle = await (window as any).showSaveFilePicker({
          suggestedName: filename,
          types: [
            {
              description: `${ext.toUpperCase()} Files`,
              accept: { [mimeType]: [`.${ext}`] }
            }
          ]
        });

        const safeBlob = new Blob([await blob.arrayBuffer()], {
          type: 'application/octet-stream'
        });

        const writable = await handle.createWritable();
        await writable.write(await safeBlob.arrayBuffer());
        await writable.close();
      } catch (error: any) {
        if (error.name !== 'AbortError') {
          console.error('[SlideCreationPromptFlow] Error saving file');
          this.fallbackDownload(blob, filename);
        }
      }
    } else {
      this.fallbackDownload(blob, filename);
    }
  }

  private fallbackDownload(blob: Blob, filename: string): void {
    const safeFilename = filename
      .replace(/[^a-zA-Z0-9._-]/g, '_')
      .replace(/_{2,}/g, '_')
      .replace(/^_+|_+$/g, '') || 'download';
    const safeBlob = new Blob([blob], { type: blob.type || 'application/octet-stream' });
    saveAs(safeBlob, safeFilename);
  }

  openRequestForm() {
    this.showRequestForm = true;
  }

  phoenixRdpLink = '';

  onTicketCreated(event: {
    requestNumber: string;
    phoenixRdpLink: string;
  }): void {
    try {
      this.validateAndEscapeUrl(event.phoenixRdpLink);
      const escapedRequestNumber = this.escapeHtmlSpecialChars(event.requestNumber);
      const escapedLink = this.escapeHtmlAttribute(event.phoenixRdpLink);
      this.phoenixRdpLink = event.phoenixRdpLink;
      console.log('[SlideCreationPromptFlow] Ticket created');
      this.generatedContent = `Request created successfully! Your request number is: <a href="${escapedLink}" target="_blank" rel="noopener noreferrer">${escapedRequestNumber}</a>`;
    } catch (error) {
      console.error('[SlideCreationPromptFlow] Invalid ticket data');
      this.generatedContent = 'Error processing request. Please try again.';
    }
    this.showRequestForm = false;
    this.showCreateRequestButton = false;
  }

  private escapeHtmlSpecialChars(untrustedData: string): string {
    if (!untrustedData) return '';
    const div = document.createElement('div');
    div.textContent = untrustedData;
    return div.innerHTML;
  }

  private escapeHtmlAttribute(untrustedData: string): string {
    if (!untrustedData) return '';
    return untrustedData
      .replace(/&/g, '&amp;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#x27;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;');
  }

  private validateAndEscapeUrl(urlString: string): void {
    if (!urlString) throw new Error('URL is empty');

    try {
      const url = new URL(urlString);

      if (!['http:', 'https:'].includes(url.protocol)) {
        throw new Error(`Invalid protocol: ${url.protocol}`);
      }
    } catch (error) {
      throw new Error(`URL validation failed: ${error instanceof Error ? error.message : 'Invalid URL'}`);
    }
  }
}
