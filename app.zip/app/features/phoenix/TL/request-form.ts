import { Component, EventEmitter, inject, OnInit, Output, Input, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { CurrentUserService } from '../../../core/services/current-user.service';
import { take } from 'rxjs';
import { firstValueFrom } from 'rxjs';
import { FileUploadComponent } from '../../../shared/ui/components/file-upload/file-upload.component';
import { ChatService } from '../../../core/services/chat.service';

@Component({
  selector: 'app-tl-request-form',
  standalone: true,  
  imports: [
    CommonModule,
    ReactiveFormsModule,
    FileUploadComponent 
  ],
  templateUrl: './request-form.html',
  styleUrls: ['./request-form.scss']
})


export class TlRequestFormComponent implements OnInit {

  @Input() documentText!: string;
  @Input() documentTitle!: string;

  @Output() close = new EventEmitter<void>();
  //@ViewChild('fileUploadComponent') fileUploadComponent!: FileUploadComponent;

  private _fileUploadComponent!: FileUploadComponent;
  private pendingWordFile: File | null = null;
  
  @ViewChild('fileUploadComponent')
  set fileUpload(comp: FileUploadComponent) {
  if (comp) {
    this._fileUploadComponent = comp;

    if (this.pendingWordFile) {
      comp.addFile(this.pendingWordFile);
      this.pendingWordFile = null;
    }
  }
}

  private currentUserService = inject(CurrentUserService);

  form!: FormGroup;
  supportingFiles: File[] = [];
  isGenerating = false;
  submitErrorMessage: string | null = null;
  isLoading = true; 


  //"691e34c5f186e4dd0add04f4",
  requestConfig: any = {
  "source": "69244907b6aaf264b9629e14",
  "requestor": "",
  "requestName": "",
  "configId": "6967bc7ec21b20782c9606e7",
  "configName": "Thought Leadership - Article Ideation and Review",
  "requestTeamMembers": {
    "roleOptions": [
      "Engagement Team Primary",
      "Engagement Team Member",
      "Engagement Partner",
      "Engagement Manager",
      "Engagement Director"
    ],
    "teamMembers": [
      {
        "guidOrEmail": "",
        "role": ""
      }
    ]
  },
  "integrationComponents": [
    {
      "name": "WBS Code",
      "value": "",
      "required": true
    }
  ],
  "fieldComponents": [
    {
      "name": "What is the content type? (Perspective, Case study, Research etc.)",
      "required": false,
      "value": "",
      "options": [
        "Perspective",
        "Case study",
        "Research",
        "Others"
      ]
    },
    {
      "name": "Provide a brief description of the topic and objective of the publication.",
      "required": false,
      "value": ""
    },
    {
      "name": "On which platform(s) will the content be published?",
      "required": false,
      "value": ""
    },
    {
      "name": "Who is the target audience?",
      "required": false,
      "value": ""
    },
    {
      "name": "Does the content support an existing strategic initiative? If so, which?",
      "required": false,
      "value": ""
    }
  ],
  "activities": [
    {
      "activityName": "Network of Experts",
      "selected": "Yes",
      "options": [
        "Yes",
        "No"
      ],
      "fieldComponents": []
    },
    {
      "activityName": "Editor",
      "selected": "Yes",
      "options": [
        "Yes",
        "No"
      ],
      "fieldComponents": []
    },
    {
      "activityName": "Partner In Charge",
      "selected": "Yes",
      "options": [
        "Yes",
        "No"
      ],
      "fieldComponents": []
    },
    {
      "activityName": "MCX Approver",
      "selected": "Yes",
      "options": [
        "Yes",
        "No"
      ],
      "fieldComponents": []
    },
    {
      "activityName": "R&I / OGC",
      "selected": "Yes",
      "options": [
        "Yes",
        "No"
      ],
      "fieldComponents": []
    }
  ]
};
//requestConfig: any = {};

  constructor(
    private fb: FormBuilder,
    private chatService: ChatService
) {}

//private service: RequestService,

  async ngOnInit(): Promise<void> {   
    
    try {
    await this.getConfigDetails();
     this.buildForm();
    if (this.documentText && this.documentTitle) {
    //const wordFile = await this.createWordFile();
    this.pendingWordFile = await this.createWordFile();
    //console.log(wordFile)
    //this.fileUploadComponent?.addFile(wordFile);
    
  }
  this.form.valueChanges.subscribe(() => {
    this.submitErrorMessage = null;
  });
  } finally {
    this.isLoading = false;
  }
   
  }

async getConfigDetails(): Promise<void> {
    
    const config = await firstValueFrom(
      this.chatService.getPhoenixRequestConfigTl()
    );

    this.requestConfig = config;

}

  private buildForm(): void {
    
    const group: any = {
      requestName: ['', Validators.required]
    };

    const integrationComponents = this.requestConfig?.integrationComponents ?? [];

    integrationComponents.forEach((field: any, index: number) => {
      group[`integration_${index}`] = [
        '',
        field.required ? [Validators.required] : []
      ];
    });

    const fieldComponents = this.requestConfig?.fieldComponents ?? [];

    fieldComponents.forEach((field: any, index: number) => {
      group[`field_${index}`] = [
        '',
        //[Validators.required] //all fieldComponents must be required
        field.required ? [Validators.required] : []
      ];
    });

    this.form = this.fb.group(group);  
  }

@Output() ticketCreated = new EventEmitter<{
  requestNumber: string;
  phoenixRdpLink: string;
}>();



onFilesSelected_multiple_notUsed(event: Event): void {
  const input = event.target as HTMLInputElement;

  if (!input.files || input.files.length === 0) {
    this.supportingFiles = [];
    return;
  }

  this.supportingFiles = Array.from(input.files);
}
onFileSelected(file: File): void {
    this.supportingFiles.push(file);
    
  }

async createWordFile(): Promise<File> {
const blob: Blob = await firstValueFrom(
  this.chatService.exportToWord({
    content: this.documentText,
    title: this.documentTitle,
    content_type: 'article'
  })
);

const fileName = `${this.documentTitle}.docx`;

return new File(
  [blob],
  fileName,
  {
    type: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
    lastModified: Date.now()
  }
);


}


normalizeText(text: string): string {
  return text
    .replace(/[^\x20-\x7E\n]/g, '') // Remove non-ASCII printable chars (smart quotes, em dashes, etc.)
    .replace(/^#+\s+/gm, '')         // Remove markdown headers (e.g. ##, ###) only at start of lines
    .replace(/\s{2,}/g, ' ')         // Collapse multiple spaces into one
    .replace(/\n{2,}/g, '\n\n')     // Ensure paragraph breaks stay as double newlines
    .trim();
}

async submit(): Promise<void> {
    this.isGenerating = true;
  if (this.form.invalid) {
    this.form.markAllAsTouched();
    return;
  }

  try {
    
    //Get current user
    const user = await firstValueFrom(this.currentUserService.user$);
    
    this.requestConfig.requestor = (user?.email || '').toLowerCase().replace('@dev365.', '@');

    //Map form values into JSON
    this.requestConfig.requestName = this.form.value.requestName;

    const integrationComponents = this.requestConfig?.integrationComponents ?? [];
    integrationComponents.forEach((field: any, index: number) => {
      const formValue = this.form.value[`integration_${index}`];
      //field.value = this.form.value[`integration_${index}`];

            if (
          field.name?.includes('Who is the sponsoring partner') &&
          field.subFields?.length
        ) {
          const emailField = field.subFields.find(
            (sf: any) => sf.name === 'Email'
          );

          if (emailField) {
            emailField.value = formValue;
          }
        } else {
          field.value = formValue;
        }

      //field.value = this.form.get(`integration_${index}`)?.value
    });

    const fieldComponents = this.requestConfig?.fieldComponents ?? [];
    fieldComponents.forEach((field: any, index: number) => {
      field.value = this.form.value[`field_${index}`];
      //field.value = this.form.get(`field_${index}`)?.value
    });

    console.log('FINAL REQUEST JSON:', this.requestConfig);

    //Send to API (placeholder)
    // const response = await firstValueFrom(this.service.createRequest(this.requestConfig));
   // const response = await firstValueFrom(this.service.createRequest(this.requestConfig, this.supportingFiles));
    
    const formData = new FormData();
   formData.append('request', JSON.stringify(this.requestConfig));

      this.supportingFiles.forEach(file => {
        formData.append('files', file); // backend expects "files"
      });

      /*
      console.log('--- FormData ---');
      formData.forEach((value, key) => {
  console.log(key, value);
        });
        */

    const response: any = await firstValueFrom(this.chatService.createPhoenixRequest(formData));

    
    if (response.requestId === "0"){ 
      this.isGenerating = false;
      this.submitErrorMessage = response.errorMessage || 'Unable to submit request. Request creation failed with the error: '+ response.errorMessage;
    return;
}

else{
   // Emit real values from API
    this.ticketCreated.emit({
      requestNumber: response.requestNumber,
      phoenixRdpLink: response.phoenixRdpLink
    });

    this.isGenerating = false;

    //Close form
    this.close.emit();
  }

  } catch (error) {
    console.error('Error submitting request: ', error);
  }
}

  cancel(): void {
    this.close.emit();
  }
}
