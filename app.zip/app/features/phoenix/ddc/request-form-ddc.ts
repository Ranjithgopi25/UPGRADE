import { Component, EventEmitter, inject, OnInit, Output } from '@angular/core';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { firstValueFrom } from 'rxjs';
import { CurrentUserService } from '../../../core/services/current-user.service';
import { FileUploadComponent } from '../../../shared/ui/components/file-upload/file-upload.component';
import { ChatService } from '../../../core/services/chat.service';

@Component({
  selector: 'app-ddc-request-form',
  standalone: true,
  imports: [CommonModule, FileUploadComponent, ReactiveFormsModule],
  templateUrl: './request-form-ddc.html',
  styleUrls: ['./request-form-ddc.scss']
})
export class DDCRequestFormComponent implements OnInit {
  @Output() close = new EventEmitter<void>();
  @Output() ticketCreated = new EventEmitter<{ requestNumber: string; phoenixRdpLink: string }>();

  private currentUserService = inject(CurrentUserService);
  private fb: FormBuilder = inject(FormBuilder);
  private chatService = inject(ChatService);

  form!: FormGroup;
  supportingFiles: File[] = [];
  isGenerating = false;
  submitErrorMessage: string | null = null;
  minDateTime!: string;
  requestConfig: any = {
  "source": "69244907b6aaf264b9629e14",
  "requestor": "",
  "requestName": "",
  "configId": "699d3e6cbb74382d2c68d985",
  "configName": "Doc Studio - ThinkSpace",
  "requestTeamMembers": {
    "roleOptions": [
      "Engagement Team Primary",
      "Engagement Team Member",
      "Engagement Partner",
      "Engagement Manager",
      "Engagement Director"
    ],
    "teamMembers": [
      {
        "guidOrEmail": "",
        "role": ""
      }
    ]
  },
  "integrationComponents": [
    {
      "name": "Provide WBS code to be charged for this request",
      "type": "WBS Code(IFS)",
      "value": "",
      "required": true,
      "subFields": [
        {
          "name": "SEC/Non-SEC Designation",
          "required": true,
          "value": "Yes",
          "options": [
            "Yes",
            "No"
          ]
        }
      ]
    }
  ],
  "fieldComponents": [
    {
      "name": "Is this request for internal or external content?",
      "fieldType": "Dropdown",
      "required": true,
      "value": "",
      "options": [
        "Internal",
        "External"
      ]
    },
    {
      "name": "When does this request need to be completed?",
      "fieldType": "Date Time field",
      "required": true,
      "value": ""
    },
    {
      "name": "What is the final desired output type?",
      "fieldType": "Dropdown",
      "required": true,
      "value": "",
      "options": [
        "Word doc",
        "PPT"
      ]
    },
    {
      "name": "Provide detailed instructions for support required (incl. if output for client or internal purposes)",
      "fieldType": "Text area(5000)",
      "required": true,
      "value": ""
    },
    {
      "name": "Specific branding is required for this document",
      "fieldType": "Check box",
      "required": true,
      "value": [],
      "options": [
        "Yes",
        "No"
      ]
    },
    {
      "name": "I confirm due diligence for IP (and brand usage, if applicable) has been performed.",
      "fieldType": "Check list",
      "required": true,
      "value": [],
      "options": [
        "Yes, I confirm"
      ]
    }
  ]
};

  ngOnInit(): void {
    this.buildForm();
    this.form.valueChanges.subscribe(() => {
      this.submitErrorMessage = null;
    });
    // Add 24 hours
    const now = new Date();
    now.setHours(now.getHours() + 24);
    this.minDateTime = this.formatDateTimeLocal(now);
  }

  private formatDateTimeLocal(date: Date): string {
  const pad = (n: number) => n.toString().padStart(2, '0');

  return `${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(date.getDate())}T${pad(date.getHours())}:${pad(date.getMinutes())}`;
}

  async buildForm(): Promise<void> {
    
    this.form = this.fb.group({
      contentType: ['', Validators.required],
      completionDate: ['', Validators.required],
      outputType: ['', Validators.required],
      instructions: ['', Validators.required],
      specificBranding: [false],
      wbsCode: ['', Validators.required],
      dueDiligenceConfirm: [false, Validators.requiredTrue]
    });

    await this.getConfigDetails();
  }

  async getConfigDetails(): Promise<void> {
    try{
    const config = await firstValueFrom(this.chatService.getPhoenixRequestConfigDdc());
    this.requestConfig = config;
    } catch (error: any) {
      console.error('Error fetching DDC config:', error);
    }
  }


  onFileSelected(file: File): void {
    this.supportingFiles.push(file);
  }

  async submit(): Promise<void> {
    if (this.form.invalid) {
      this.form.markAllAsTouched();
      return;
    }

    this.isGenerating = true;

    try {
      const user = await firstValueFrom(this.currentUserService.user$);
      
      // Format completionDate to ISO 8601 UTC format (2026-02-18T09:38:00.000Z)
      let formattedCompletionDate = '';
      const completionDateValue = this.form.value.completionDate;
      
      if (completionDateValue) {
        // If value is a string like "2026-02-18T12:41", ensure it has full ISO format
        const dateStr = typeof completionDateValue === 'string' ? completionDateValue : '';
        if (dateStr.includes('T')) {
          // Has time component, ensure it's complete with seconds and milliseconds
          const completionDateObj = new Date(dateStr);
          formattedCompletionDate = completionDateObj.toISOString();
        } else {
          // Date only, create a UTC date at midnight
          const completionDateObj = new Date(dateStr + 'T00:00:00.000Z');
          formattedCompletionDate = completionDateObj.toISOString();
        }
      }
      
      const requestData = {
        contentType: this.form.value.contentType,
        completionDate: formattedCompletionDate,
        outputType: this.form.value.outputType,
        instructions: this.form.value.instructions,
        specificBranding: this.form.value.specificBranding ? 'Yes' : 'No',
        wbsCode: this.form.value.wbsCode,
        dueDiligenceConfirm: this.form.value.dueDiligenceConfirm ? 'Yes' : 'No',
        requestor: (user?.email || '').toLowerCase().replace('@dev365.', '@')
      };

      const baseJson = this.requestConfig;    

      const finalPayload = {
        ...baseJson,   // your big JSON object
        requestor: requestData.requestor,

        integrationComponents: [
          {
            ...baseJson.integrationComponents[0],
            value: requestData.wbsCode
          }
        ],

        fieldComponents: baseJson.fieldComponents.map((field: { name: any; }) => {
          switch (field.name) {

            case "Is this request for internal or external content?":
              return { ...field, value: requestData.contentType };

            case "When does this request need to be completed?":
              return { ...field, value: requestData.completionDate };

            case "What is the final desired output type?":
              return { ...field, value: requestData.outputType };

            case "Provide detailed instructions for support required (incl. if output for client or internal purposes)":
              return { ...field, value: requestData.instructions };

            case "Specific branding is required for this document":
              return { 
                ...field, 
                value: [requestData.specificBranding]  // checkbox expects array
              };

            case "I confirm due diligence for IP (and brand usage, if applicable) has been performed.":
              return { 
                ...field, 
                value: requestData.dueDiligenceConfirm === 'Yes'
                  ? ["Yes, I confirm"]
                  : []
              };

            default:
              return field;
          }
        })
      };

      console.log('DDC Request Data:', finalPayload);

      const formData = new FormData();
      formData.append('request', JSON.stringify(finalPayload));

      this.supportingFiles.forEach(file => {
        formData.append('files', file);
      });

      const response: any = await firstValueFrom(
        this.chatService.createPhoenixRequest(formData)
      );

      if (response.requestId === "0") {
        this.isGenerating = false;
        this.submitErrorMessage = response.errorMessage || 'Unable to submit request. Request creation failed.';
        return;
      }

      console.log('API RESPONSE:', response.requestNumber, response.phoenixRdpLink);

      this.ticketCreated.emit({
        requestNumber: response.requestNumber,
        phoenixRdpLink: response.phoenixRdpLink
      });

      this.isGenerating = false;
      this.close.emit();
    } catch (error: any) {
      console.error('Error submitting request:', error);
      this.isGenerating = false;
      this.submitErrorMessage = 'An error occurred while submitting your request. Please try again.';
    }
  }

  cancel(): void {
    this.close.emit();
  }
}


