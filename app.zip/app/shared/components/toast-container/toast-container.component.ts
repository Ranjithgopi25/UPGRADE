import { Component, OnInit, OnDestroy, ChangeDetectorRef } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ToastService, Toast } from '../../../core/services/toast.service';

@Component({
  selector: 'app-toast-container',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div class="toast-container">
      @for (toast of toasts; track toast.id) {
        <div 
          class="toast"
          [class]="'toast-' + toast.type"
          [@toastAnimation]="'enter'"
        >
          <div class="toast-content">
            @switch (toast.type) {
              @case ('success') {
                <svg class="toast-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                  <polyline points="20 6 9 17 4 12"></polyline>
                </svg>
              }
              @case ('error') {
                <svg class="toast-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                  <circle cx="12" cy="12" r="10"></circle>
                  <line x1="15" y1="9" x2="9" y2="15"></line>
                  <line x1="9" y1="9" x2="15" y2="15"></line>
                </svg>
              }
              @case ('warning') {
                <svg class="toast-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                  <path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3.05h16.94a2 2 0 0 0 1.71-3.05L13.71 3.86a2 2 0 0 0-3.42 0z"></path>
                  <line x1="12" y1="9" x2="12" y2="13"></line>
                  <line x1="12" y1="17" x2="12.01" y2="17"></line>
                </svg>
              }
              @case ('info') {
                <svg class="toast-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                  <circle cx="12" cy="12" r="10"></circle>
                  <line x1="12" y1="16" x2="12" y2="12"></line>
                  <line x1="12" y1="8" x2="12.01" y2="8"></line>
                </svg>
              }
            }
            <span class="toast-message">{{ toast.message }}</span>
          </div>
          <button 
            class="toast-close"
            (click)="dismiss(toast.id)"
            aria-label="Close notification"
          >
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <line x1="18" y1="6" x2="6" y2="18"></line>
              <line x1="6" y1="6" x2="18" y2="18"></line>
            </svg>
          </button>
        </div>
      }
    </div>
  `,
  styles: [`
    .toast-container {
      position: fixed;
      bottom: 24px;
      right: 24px;
      z-index: 9999;
      display: flex;
      flex-direction: column;
      gap: 12px;
      max-width: 400px;
      pointer-events: none;

      @media (max-width: 768px) {
        bottom: 16px;
        right: 16px;
        left: 16px;
        max-width: 100%;
      }
    }

    .toast {
      display: flex;
      align-items: center;
      justify-content: space-between;
      padding: 12px 16px;
      border-radius: 0px;
      font-size: 0.875rem;
      font-weight: 500;
      box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
      animation: slideInToast 0.3s ease-out;
      pointer-events: auto;
      gap: 12px;

      &.toast-success {
        background-color: #d1fae5;
        color: #065f46;
        border-left: 4px solid #10b981;
      }

      &.toast-error {
        background-color: #fee2e2;
        color: #7f1d1d;
        border-left: 4px solid #ef4444;
      }

      &.toast-warning {
        background-color: #fef3c7;
        color: #78350f;
        border-left: 4px solid #f59e0b;
      }

      &.toast-info {
        background-color: #dbeafe;
        color: #0c2d6b;
        border-left: 4px solid #3b82f6;
      }
    }

    .toast-content {
      display: flex;
      align-items: center;
      gap: 12px;
      flex: 1;
    }

    .toast-icon {
      width: 20px;
      height: 20px;
      flex-shrink: 0;
      stroke-linecap: round;
      stroke-linejoin: round;
    }

    .toast-message {
      line-height: 1.5;
    }

    .toast-close {
      display: flex;
      align-items: center;
      justify-content: center;
      width: 24px;
      height: 24px;
      padding: 0;
      background: transparent;
      border: none;
      cursor: pointer;
      color: inherit;
      opacity: 0.7;
      transition: opacity 0.2s ease;
      flex-shrink: 0;

      &:hover {
        opacity: 1;
      }

      svg {
        width: 16px;
        height: 16px;
      }
    }

    @keyframes slideInToast {
      from {
        transform: translateX(400px);
        opacity: 0;
      }
      to {
        transform: translateX(0);
        opacity: 1;
      }
    }
  `]
})
export class ToastContainerComponent implements OnInit {
  toasts: Toast[] = [];

  constructor(private toastService: ToastService, private cdr: ChangeDetectorRef) {}

  ngOnInit(): void {
    this.toastService.getToasts().subscribe((toasts: Toast[]) => {
      this.toasts = toasts;
      this.cdr.detectChanges();
    });
  }

  dismiss(id: string): void {
    this.toastService.dismiss(id);
  }
}
