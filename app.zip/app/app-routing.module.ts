import { NgModule } from '@angular/core';
import { PreloadAllModules, RouterModule, Routes } from '@angular/router';
import { AuthGuard } from '@rco/angular-auth-extensions';
import { TokenComponent } from './auth/token.component/token.component';
import { environment } from '../environments/environment';

const guard = environment.useAuth ? [AuthGuard] : undefined;

const routes: Routes = [
  {
    path: '',
    canActivate: guard,
    loadChildren: () =>
      import('./dashboard/dashboard.module').then((m) => m.DashboardModule),
  },
  {
    path: 'dashboard',
    canActivate: guard,
    loadChildren: () =>
      import('./dashboard/dashboard.module').then((m) => m.DashboardModule),
  },
  {
    path: 'profile',
    canActivate: guard,
    loadChildren: () =>
      import('./profile/profile.module').then((m) => m.ProfileModule),
  },
  {
    path: 'people',
    canActivate: guard,
    loadChildren: () =>
      import('./people/people.module').then(
        (m) => m.PeopleModule
      ),
  },

  {
    path: 'logout',
    loadChildren: () =>
      import('./auth/logout/logout.module').then((m) => m.LogoutModule),
  },
  {
    path: 'login/token',
    component: TokenComponent,
  },
];

@NgModule({
  imports: [
    RouterModule.forRoot(routes, {
      preloadingStrategy: PreloadAllModules,
    }),
  ],
  exports: [RouterModule],
})
export class AppRoutingModule {}
