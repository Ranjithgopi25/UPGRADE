import { Injectable, Injector, inject } from '@angular/core';
import { MsalService, MsalBroadcastService } from '@azure/msal-angular';
import { AuthenticationResult, InteractionStatus } from '@azure/msal-browser';
import { Observable, of, fromEvent, merge, firstValueFrom } from 'rxjs';
import { debounceTime } from 'rxjs/operators';
import { environment } from '../../environments/environment';
import { ChatService } from '../core/services/chat.service';

const ENABLE_AUTH = environment.useAuth;
const INACTIVITY_TIMEOUT = 2 * 60 * 60 * 1000; // 120 minutes in milliseconds
const MAX_SESSION_LENGTH = 2 * 60 * 60 * 1000; // 2 hour in milliseconds
@Injectable({
  providedIn: 'root'
})
export class AuthService {
private injector = inject(Injector);
  private msalService: MsalService | null = null;
  private msalBroadcastService: MsalBroadcastService | null = null;
  private chatService: ChatService | null = null;
  
  private inactivityTimer: any;
  private sessionStartTime: number | null = null;
  private maxSessionTimer: any;
  private statusLogTimer: any;
  
  // Global token storage
  public accessToken: string | null = null;

  // Cache user profile to avoid redundant API calls
  private userProfileCache: any = null;

  // Store module access from profile for display in chat component
  private moduleAccessForDisplay = {
    docStudio: true,
    marketIntelligence: true,
    cortex: true
  };


  constructor() {
    if (ENABLE_AUTH) {
        this.msalService = this.injector.get(MsalService);
        this.msalBroadcastService = this.injector.get(MsalBroadcastService);
        this.chatService = this.injector.get(ChatService);
        
        // Structured logging for easy sharing/debugging
        console.group('🔐 [AuthService] MSAL Services Initialized');
        console.log('MsalService:', this.msalService);
        console.log('MsalBroadcastService:', this.msalBroadcastService);
        
        // Key properties for troubleshooting (copyable format)
        const debugInfo = {
          timestamp: new Date().toISOString(),
          msalServiceExists: !!this.msalService,
          msalBroadcastServiceExists: !!this.msalBroadcastService,
          activeAccount: this.msalService?.instance?.getActiveAccount?.() || null,
          allAccountsCount: this.msalService?.instance?.getAllAccounts?.()?.length || 0,
          configuration: {
            clientId: (this.msalService?.instance as any)?.config?.auth?.clientId || 'N/A',
            authority: (this.msalService?.instance as any)?.config?.auth?.authority || 'N/A'
          }
        };
        console.log('📋 Debug Info (copy-friendly):', JSON.stringify(debugInfo, null, 2));
        console.groupEnd();

        
    this.msalService.handleRedirectObservable().subscribe({
      next: (result: AuthenticationResult) => {
        if (result) {
          ////console.log('Login successful:', result);
          this.msalService?.instance.setActiveAccount(result.account);
          this.startSessionTimers();
        }
      },
      error: (error) => console.error('[Auth] Login error')
    });

    // Check if user is already logged in and start timers
    if (this.isLoggedIn()) {
      this.startSessionTimers();
    }
  }
}

  private startSessionTimers() {
    // Clear any existing timers
    this.clearTimers();

    // Set session start time
    const storedStartTime = sessionStorage.getItem('sessionStartTime');
    if (storedStartTime) {
      this.sessionStartTime = parseInt(storedStartTime, 10);
      
      // Check if max session time has already elapsed
      const elapsedTime = Date.now() - this.sessionStartTime;
      console.log('[Session] Resuming session. Elapsed time:', Math.floor(elapsedTime / 1000 / 60), 'minutes');
      
      if (elapsedTime >= MAX_SESSION_LENGTH) {
        console.log('[Session] Maximum session length exceeded on resume');
        //this.logoutDueToTimeout('Maximum session length exceeded');
        //this.triggerSessionExpiredDialog();
        return;
      }
      
      // Set timer for remaining session time
      const remainingTime = MAX_SESSION_LENGTH - elapsedTime;
      console.log('[Session] Maximum session will expire in:', Math.floor(remainingTime / 1000 / 60), 'minutes');
      this.maxSessionTimer = setTimeout(() => {
        //this.logoutDueToTimeout('Maximum session length exceeded');
        //this.triggerSessionExpiredDialog();
      }, remainingTime);
    } else {
      this.sessionStartTime = Date.now();
      sessionStorage.setItem('sessionStartTime', this.sessionStartTime.toString());
      console.log('[Session] New session started. Will expire in 1 hour');
      
      // Set max session timer for 24 hours
      this.maxSessionTimer = setTimeout(() => {
        //this.logoutDueToTimeout('Maximum session length exceeded');
        //this.triggerSessionExpiredDialog();
      }, MAX_SESSION_LENGTH);
    }

    // Set up activity listeners for inactivity timeout
    this.setupInactivityTimer();
    
    // Start periodic status logging
    this.startStatusLogging();
  }

  private startStatusLogging() {
    // Log status every minute
    this.statusLogTimer = setInterval(() => {
      if (this.sessionStartTime) {
        const elapsedTime = Date.now() - this.sessionStartTime;
        const elapsedMinutes = Math.floor(elapsedTime / 1000 / 60);
        const remainingSessionMinutes = Math.floor((MAX_SESSION_LENGTH - elapsedTime) / 1000 / 60);
        
        //console.log('[Session Status] Session active for:', elapsedMinutes, 'minutes | Remaining time:', remainingSessionMinutes, 'minutes');
      }
    }, 60000); // Log every 60 seconds
  }

  private setupInactivityTimer() {
    //console.log('[Session] Setting up inactivity monitoring. Timeout:', INACTIVITY_TIMEOUT / 1000 / 60, 'minutes');
    
    // Listen to user activity events
    const activityEvents$ = merge(
      fromEvent(document, 'mousedown'),
      fromEvent(document, 'keydown'),
      fromEvent(document, 'scroll'),
      fromEvent(document, 'touchstart'),
      fromEvent(document, 'click')
    );

    // Reset inactivity timer on any activity
    activityEvents$.pipe(
      debounceTime(1000) // Debounce to avoid too many resets
    ).subscribe(() => {
      //console.log('[Session] User activity detected - resetting inactivity timer');
      this.resetInactivityTimer();
    });

    // Start initial inactivity timer
    this.resetInactivityTimer();
  }

  private resetInactivityTimer() {
    // Clear existing timer
    if (this.inactivityTimer) {
      clearTimeout(this.inactivityTimer);
    }

    const timeoutMinutes = INACTIVITY_TIMEOUT / 1000 / 60;
    console.log('[Session] Inactivity timer set - will logout in', timeoutMinutes, 'minutes if no activity');

    // Set new timer
    this.inactivityTimer = setTimeout(() => {
      console.log('[Session] Inactivity timeout reached - logging out');
      //this.triggerSessionExpiredDialog();
      //this.logoutDueToTimeout('Session expired due to inactivity');
    }, INACTIVITY_TIMEOUT);
  }

  private clearTimers() {
    if (this.inactivityTimer) {
      clearTimeout(this.inactivityTimer);
      this.inactivityTimer = null;
      console.log('[Session] Inactivity timer cleared');
    }
    
    if (this.maxSessionTimer) {
      clearTimeout(this.maxSessionTimer);
      this.maxSessionTimer = null;
      console.log('[Session] Maximum session timer cleared');
    }

    if (this.statusLogTimer) {
      clearInterval(this.statusLogTimer);
      this.statusLogTimer = null;
      console.log('[Session] Status logging stopped');
    }
  }

  private logoutDueToTimeout(reason: string) {
    console.log('[Session] Auto logout triggered:', reason);
    
    // Clear session storage
    sessionStorage.removeItem('sessionStartTime');
    
    // Perform logout
    this.logout();
  }

  isLoggedIn(): boolean {
    if (!ENABLE_AUTH) return true;
    return this.msalService?.instance.getActiveAccount() != null;
  }

  getUserInfo() {
    if (!ENABLE_AUTH) {
      // Return mock user info when auth disabled
      return {
        name: 'Sayantan',
        email: 'sayantan.d.das@dev365.pwc.com',
        id: 'dev-123'
      };
    }
    const activeAccount = this.msalService?.instance.getActiveAccount(
    );
    if (activeAccount) {
      console.log('Active account:', activeAccount);
      return {
        name: activeAccount.name || activeAccount.username,
        email: activeAccount.username,
        // id: activeAccount.localAccountId
      };
    }
    return null;
  }

  /**
   * Helper function to fetch user profile
   * Uses cache to avoid redundant API calls
   * PUBLIC method so other services can use the cached profile
   * @returns user profile object or null if unable to fetch
   */
  async getUserProfile(): Promise<any> {
    // Return cached profile if available (FAST PATH - no API call)
    if (this.userProfileCache) {
      console.log('[Auth] ⚡ Returning cached user profile (zero API calls)');
      return this.userProfileCache;
    }

    try {
      const userInfo = this.getUserInfo();
      if (!userInfo?.email) {
        console.log('[Auth] User not authenticated - unable to fetch profile');
        return null;
      }

      console.log('[Auth] 🔄 Fetching user profile from API for first time...');
      const startTime = performance.now();
      const cleanEmail = userInfo.email.replace('@dev365.', '@');
      const response: any = await firstValueFrom(this.chatService!.getUserProfile(cleanEmail));
      const apiTime = performance.now() - startTime;
      
      // Cache the profile for subsequent calls
      this.userProfileCache = response;
      console.log(`[Auth] ✅ User profile cached (API took ${apiTime.toFixed(0)}ms)`);
      
      return response as any;
    } catch (error) {
      console.error('[Auth] Error fetching user profile:', error);
      return null;
    }
  }

  /**
   * Set module access from user profile (called by app component)
   * @param moduleAccess Object with docStudio, marketIntelligence, cortex flags
   */
  setModuleAccess(moduleAccess: { docStudio: boolean; marketIntelligence: boolean; cortex: boolean }): void {
    this.moduleAccessForDisplay = moduleAccess;
    console.log('[Auth] 📋 Module access set for display:', moduleAccess);
  }

  /**
   * Get module access for displaying in chat component
   * @returns Module access flags previously set from user profile
   */
  getModuleAccessForDisplay(): { docStudio: boolean; marketIntelligence: boolean; cortex: boolean } {
    return this.moduleAccessForDisplay;
  }

  login() {
    if (!ENABLE_AUTH) {
      //console.log('Authentication disabled - skipping login');
      return;
    }
    this.msalService?.loginRedirect({
      //scopes: ['openid','profile']
      scopes: ['User.Read openid profile email']
    });
  }

  logout() {
    if (!ENABLE_AUTH) {
      //console.log('Authentication disabled - skipping logout');
      return;
    }
    
    console.log('[Session] Logout initiated - clearing all timers and session data');
    
    // Clear timers and session data
    this.clearTimers();
    sessionStorage.removeItem('sessionStartTime');
    this.sessionStartTime = null;
    
    // Clear cache
    this.userProfileCache = null;
    console.log('[Auth] User profile cache cleared');
    
    this.msalService?.logoutRedirect();
  }

  getLoginStatus(): Observable<InteractionStatus> {
    if (!ENABLE_AUTH) {
      return of('None' as InteractionStatus);
    }
    return this.msalBroadcastService?.inProgress$ || of('None' as InteractionStatus);
  }

  // Get access token for API calls
  async getAccessToken(): Promise<string | null> {
    if (!ENABLE_AUTH) return 'mock-token';
    try {
      const response = await this.msalService?.instance.acquireTokenSilent({
        //scopes: ['openid','profile'],
        scopes: ['User.Read'],
        account: this.msalService.instance.getActiveAccount()!
      });
      this.accessToken = response?.accessToken || null;
     //console.log('Access token : ' , this.accessToken);
      return response?.idToken||null;
    } catch (error) {
      //console.error('Error getting access token:', error);
      return null;
    }
  }

  private triggerSessionExpiredDialog() {
    // Create a custom modal for session expiry
    const dialog = document.createElement('div');
    dialog.style.position = 'fixed';
    dialog.style.top = '0';
    dialog.style.left = '0';
    dialog.style.width = '100vw';
    dialog.style.height = '100vh';
    dialog.style.background = 'rgba(0,0,0,0.5)';
    dialog.style.display = 'flex';
    dialog.style.alignItems = 'flex-start';
    dialog.style.justifyContent = 'center';
    dialog.style.zIndex = '9999';
    dialog.style.overflow = 'auto';

    const box = document.createElement('div');
    box.style.background = '#fff';
    box.style.position = 'relative';
    box.style.top = '3vh';
      box.style.padding = '2rem 2rem 1rem 2rem'; // reduce bottom padding only
    box.style.borderRadius = '8px';
    box.style.boxShadow = '0 2px 16px rgba(0,0,0,0.2)';
    box.style.display = 'flex';
    box.style.flexDirection = 'column';
    box.style.width = 'calc(100% - 4rem)';
    box.style.maxWidth = '600px';
    box.style.minWidth = '280px';
    box.style.fontFamily = 'Helvetica Neue, Helvetica, Arial, sans-serif';
    box.style.boxSizing = 'border-box';

    const header = document.createElement('div');
    header.textContent = 'Your session has expired.';
    header.style.fontWeight = 'normal';
    header.style.fontSize = 'clamp(1.25rem, 5vw, 1.5rem)';
    header.style.marginBottom = '1rem';
    header.style.textAlign = 'left';
    header.style.fontFamily = 'Helvetica Neue, Helvetica, Arial, sans-serif';
    header.style.color = '#333';

    const message = document.createElement('div');
    message.textContent = 'Your login session has expired. Kindly login again.';
      message.style.marginBottom = '0.7rem';
    message.style.fontSize = 'clamp(0.875rem, 4vw, 1rem)';
    message.style.textAlign = 'left';
    message.style.fontFamily = 'Helvetica Neue, Helvetica, Arial, sans-serif';
    message.style.color = '#555';

    // Add a horizontal line after the message and before the Login button
    const line = document.createElement('hr');
    line.style.border = 'none';
    line.style.borderTop = '1px solid #e0e0e0';
      line.style.margin = '0 0 0.7rem 0';
    line.style.width = '100%';

    // Button container for proper alignment
    const buttonContainer = document.createElement('div');
    buttonContainer.style.display = 'flex';
    buttonContainer.style.justifyContent = 'flex-end';
    buttonContainer.style.gap = '1rem';
    buttonContainer.style.marginBottom = '0';
    buttonContainer.style.paddingBottom = '0';
    // Reduce the gap between button and bottom border
    buttonContainer.style.marginTop = '0';
    buttonContainer.style.marginBlockEnd = '0';

    const button = document.createElement('button');
    button.textContent = 'Login';
    button.style.background = '#FD5108';
    button.style.color = '#fff';
    button.style.border = 'none';
    button.style.padding = '0.6rem 1.5rem';
    button.style.fontSize = 'clamp(0.875rem, 3vw, 1rem)';
    button.style.borderRadius = '4px';
    button.style.cursor = 'pointer';
    button.style.fontFamily = 'Helvetica Neue, Helvetica, Arial, sans-serif';
    button.style.whiteSpace = 'nowrap';
    button.style.transition = 'background-color 0.2s ease';
    button.onclick = () => {
      sessionStorage.removeItem('sessionExpired');
      window.removeEventListener('beforeunload', forceLogoutOnReload);
      window.removeEventListener('pageshow', forceLogoutOnReload);
      document.body.removeChild(dialog);
      this.logout();
    };

    // Add hover effect
    button.addEventListener('mouseover', () => {
      button.style.backgroundColor = '#B83E02';
    });
    button.addEventListener('mouseout', () => {
      button.style.backgroundColor = '#FD5108';
    });

    box.appendChild(header);
    box.appendChild(message);
    box.appendChild(line);
    buttonContainer.appendChild(button);
    box.appendChild(buttonContainer);
    dialog.appendChild(box);
    document.body.appendChild(dialog);

    // Set a flag in sessionStorage to indicate session expired popup is active
    sessionStorage.setItem('sessionExpired', 'true');

    // Add event listener to handle reload or navigation
    const forceLogoutOnReload = () => {
      if (sessionStorage.getItem('sessionExpired') === 'true') {
        sessionStorage.removeItem('sessionExpired');
        this.logout();
      }
    };
    window.addEventListener('beforeunload', forceLogoutOnReload);
    window.addEventListener('pageshow', forceLogoutOnReload);
  }
}