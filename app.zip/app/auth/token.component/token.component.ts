import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
    selector: 'app-token',
    template: '<p>Authentication Succeeded</p>',
    standalone: false
})
export class TokenComponent implements OnInit {
  constructor(private nav: Router) {}

  ngOnInit(): void {
    this.nav.navigate(['dashboard']);
  }
}
