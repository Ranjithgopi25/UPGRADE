import { CommonModule } from '@angular/common';
import { NgModule, Optional, SkipSelf } from '@angular/core';
import {
  AuthExtensionModule,
  AuthExtensionModuleConfig,
  IDLE_TIMEOUT_CONFIG,
  ObfuscatedStorage,
} from '@rco/angular-auth-extensions';
import { OAuthModule, OAuthStorage } from 'angular-oauth2-oidc';
import { environment } from '../../environments/environment';
import { OauthAdapterService } from './oauth-adapter.service';

const apiUrl = `${environment.apiUrl}`;
const moduleConfig: AuthExtensionModuleConfig = {
  protectedUrls: [apiUrl],
};

export function storageFactory(): any {
  return new ObfuscatedStorage(sessionStorage);
}

@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    OAuthModule.forRoot(),
    AuthExtensionModule.forRoot({
      authService: OauthAdapterService,
      moduleConfig: moduleConfig,
    }),
  ],
  exports: [AuthExtensionModule, OAuthModule],
  providers: [
    {
      provide: IDLE_TIMEOUT_CONFIG,
      useValue: {
        timeout: 20 * 60, // 20 * 60 seconds for overall timeout
      },
    },
    { provide: OAuthStorage, useFactory: storageFactory },
  ],
})
export class OauthAdapterModule {
  constructor(@Optional() @SkipSelf() parentModule: OauthAdapterModule) {
    if (parentModule) {
      throw new Error(
        'OauthAdapterModule is already loaded. Import it in the AppModule only'
      );
    }
  }
}
