import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import {
  AuthAdapterService,
  AuthIdleTimeoutService,
} from '@rco/angular-auth-extensions';
import { AuthConfig, OAuthService } from 'angular-oauth2-oidc';
import { BehaviorSubject, Observable, concat, defer, of } from 'rxjs';
import { catchError, filter, switchMap, tap } from 'rxjs/operators';
import { environment } from '../../environments/environment';
import { HttpClient, HttpHeaders } from '@angular/common/http';

@Injectable({
  providedIn: 'root',
})
export class OauthAdapterService implements AuthAdapterService {
  authConfig!: AuthConfig;

  get timeout$(): Observable<boolean> {
    return this.idleTimeoutService.onTimeout();
  }

  private isAuthenticatedSubject$ = new BehaviorSubject<boolean>(false);
  public isAuthenticated$ = this.isAuthenticatedSubject$.asObservable();

  private isDoneLoadingSubject$ = new BehaviorSubject<boolean>(false);
  public isDoneLoading$ = this.isDoneLoadingSubject$.asObservable();

  // checkIsAuth is needed for AuthGuard - @rco/angular-auth-extensions
  checkIsAuth$ = this.isDoneLoading$.pipe(
    filter((isDone) => isDone),
    switchMap(() => this.isAuthenticated$)
  );

  constructor(
    private readonly idleTimeoutService: AuthIdleTimeoutService,
    private readonly oauthService: OAuthService,
    private readonly router: Router,
    private httpClient: HttpClient
  ) {
    this.initialSetup();
  }

  public initialSetup() {
    this.isAuthenticatedSubject$.next(this.oauthService.hasValidAccessToken());
    this.oauthService.timeoutFactor = 0.95;
    this.oauthService.setupAutomaticSilentRefresh();
    this.listenToIdleEvents();
  }

  login(targetUrl?: string) {
    this.oauthService.initLoginFlow(targetUrl || this.router.url);
    return of();
  }

  //expects observable output
  getToken() {
    const token = this.oauthService.getIdToken();
    return of(token);
  }

  getIdentityClaims() {
    return this.oauthService.getIdentityClaims();
  }

  async runInitialLoginSequence(): Promise<void> {
    this.authConfig = this.getAuthConfig();
    this.oauthService.configure(this.authConfig); // Configurations for angular-oauth2-oidc
    try {
      await this.oauthService.loadDiscoveryDocumentAndTryLogin();
      this.isDoneLoadingSubject$.next(true);
      if(this.oauthService.hasValidIdToken()) {
        if(this.oauthService?.state != null && this.oauthService?.state?.trim() !== '') {
          const url = this.oauthService.state;
          this.router.navigateByUrl(decodeURIComponent(url));
        }
      }
    } catch (error: any) {
      console.error(error);
    }
  }

  getAuthConfig(): AuthConfig {
    return {
      issuer: environment.issuer,
      clientId: environment.clientId,
      scope: environment.scope,
      responseType: environment.responseType,
      redirectUri: environment.redirectUrl,
      postLogoutRedirectUri: environment.postLogoutRedirectUri,
      strictDiscoveryDocumentValidation: false,
      skipIssuerCheck: true
    };
  }

  logout() {
    this.idleTimeoutService.stop();
    return this.processLogout();
  }

  private listenToIdleEvents() {
    this.idleTimeoutService.start();
    this.idleTimeoutService.onTimeout().subscribe(response => {
      if (response) {
        this.logout().subscribe(() => console.info('Logout completed'));
      }
    });
  }

  private processLogout() {
    const revokeToken$ = this.httpClient.post(`${environment.apiUrl}${environment.revokeTokenEndpoint}`, {})
      .pipe(catchError((err) => {
        console.error('Revoking token failed for improper logout', err);
        return of(false);
      }));

    const logout$ = defer(() => {
      // Change from true to false to fully log out of Entra ID, which will also sign you out of all active Entra ID applications.
      this.oauthService.logOut(true);
      // Redirect to the logout route to clear local state and navigate to the login page.
      window.location.href = this.router.serializeUrl(
              this.router.createUrlTree(['/logout'])
            );
      return of(true);
    });

    return concat(
      revokeToken$,
      logout$);
  }
}
