import { environment } from 'src/environments/environment';
import { OauthAdapterService } from './oauth-adapter.service';

export function appInitFactory(oAuthAdapterService: OauthAdapterService
  ) {
  return async () => {
    await loadSettings().catch(err => console.error(err));


    if (environment.useAuth) {
      await oAuthAdapterService.runInitialLoginSequence();
    }
  }
}



export async function loadSettings() {
  environment.redirectUrl = `${window.location.origin}/login/token`;
  environment.postLogoutRedirectUri = `${window.location.origin}/logout`;
  const response = await fetch(environment.settingsUrl);

  if (!response.ok) {
    console.error(response);
    return;
  }

  const result = await response.json();

  environment.issuer = result.authority;
  environment.clientId = result.clientId;
  environment.scope = result.scope;
  environment.useAuth = result.useAuth;
  environment.revokeTokenEndpoint = result.revokeTokenEndpoint;
  environment.datadogApplicationId = result.datadogApplicationId;
  environment.datadogClientToken = result.datadogClientToken;
}

