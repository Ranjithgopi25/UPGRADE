from datetime import datetime, timezone
import json
import logging

from langgraph.graph import StateGraph, END
from langchain_core.messages import HumanMessage

from app.core.deps import get_llm_client_agent

from .schema import ContractDraftState
from .prompt import build_sow_generation_prompt
from .validation import (
    extract_document_text,
    ask_llm_to_extract_fields,
    validate_extracted_fields,
    load_field_mapping,
)

logger = logging.getLogger(__name__)

llm = get_llm_client_agent()


# ============================================================
# HELPER: resolve active contract type from toggle dict
# ============================================================

def _get_active_contract_type(contract_type_dict: dict) -> str:
    """Return the contract type key that is True (e.g. 'SOW')."""
    type_map = {
        "statement_of_work": "SOW",
        "engagement_letter": "Engagement Letter",
        "master_services_agreement": "MSA",
        "non_disclosure_agreement": "NDA",
        "product_license_agreement": "Product License Agreement",
    }
    for key, active in contract_type_dict.items():
        if active:
            return type_map.get(key, key.upper())
    return "SOW"


# ============================================================
# NODE: EXTRACT_DOCUMENT
# ============================================================

def extract_document_node(state: ContractDraftState):
    """Read the uploaded document and extract text content."""
    file_path = state.document_upload.get("file_path", "")
    logger.info("[EXTRACT_DOCUMENT] Extracting text from %s", file_path)

    document_text = extract_document_text(file_path)

    return {
        "document_text": document_text,
    }


# ============================================================
# NODE: LLM_FIELD_EXTRACTION
# ============================================================

async def llm_field_extraction_node(state: ContractDraftState):
    """Use LLM to extract structured fields from document text."""
    logger.info("[LLM_FIELD_EXTRACTION] Extracting fields via LLM")

    mapping = load_field_mapping()
    field_definitions = mapping.get("field_definitions", [])

    extracted = await ask_llm_to_extract_fields(state.document_text, field_definitions)

    logger.info("[LLM_FIELD_EXTRACTION] Extracted %d fields", len(extracted))
    return {
        "extracted_fields": extracted,
    }


# ============================================================
# NODE: VALIDATE_FIELDS
# ============================================================

def validate_fields_node(state: ContractDraftState):
    """Validate extracted fields against field_mapping.json required fields."""
    logger.info("[VALIDATE_FIELDS] Validating extracted fields")

    mapping = load_field_mapping()
    field_definitions = mapping.get("field_definitions", [])

    result = validate_extracted_fields(state.extracted_fields, field_definitions)

    return {
        "validation_passed": result["valid"],
        "missing_fields": result["missing_fields"],
    }


# ============================================================
# NODE: DRAFT_GENERATION
# ============================================================

async def draft_generation_node(state: ContractDraftState):
    """Use LLM to generate SOW contract draft from extracted fields."""
    active_type = _get_active_contract_type(state.contract_type)

    logger.info("[DRAFT_GENERATION] Generating %s draft", active_type)

    prompt = build_sow_generation_prompt(
        extracted_fields=state.extracted_fields,
        contract_type=active_type,
    )

    response = await llm.ainvoke([HumanMessage(content=prompt)])
    draft_text = response.content if hasattr(response, "content") else str(response)

    return {
        "draft_content": draft_text,
    }


# ============================================================
# NODE: ASSEMBLE_RESPONSE
# ============================================================

def assemble_response_node(state: ContractDraftState):
    """Build the final response JSON."""
    logger.info("[ASSEMBLE_RESPONSE] Building final response")

    active_type = _get_active_contract_type(state.contract_type)
    ef = state.extracted_fields
    generated_at = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")

    response = {
        "status": "draft_generated",
        "generated_at": generated_at,
        "contract_type": active_type,
        "prid": state.prid,
        "flex_id": state.flex_id,
        "extracted_fields": ef,
        "draft_content": state.draft_content,
    }

    return {
        "final_response": response,
    }


# ============================================================
# CONDITIONAL ROUTERS
# ============================================================

def _entry_router(state: ContractDraftState) -> str:
    """Skip extraction if fields are already provided (resume flow)."""
    if state.validation_passed and state.extracted_fields:
        return "DRAFT_GENERATION"
    return "EXTRACT_DOCUMENT"


def _validation_router(state: ContractDraftState) -> str:
    """Route based on whether validation passed."""
    if state.validation_passed:
        return "DRAFT_GENERATION"
    return END


# ============================================================
# BUILD GRAPH (single graph for both initial and resume flows)
# ============================================================

def build_contract_draft_graph():
    graph = StateGraph(ContractDraftState)

    graph.add_node("EXTRACT_DOCUMENT", extract_document_node)
    graph.add_node("LLM_FIELD_EXTRACTION", llm_field_extraction_node)
    graph.add_node("VALIDATE_FIELDS", validate_fields_node)
    graph.add_node("DRAFT_GENERATION", draft_generation_node)
    graph.add_node("ASSEMBLE_RESPONSE", assemble_response_node)

    # Entry: route based on whether we already have validated fields
    graph.set_conditional_entry_point(_entry_router)

    # Extraction flow
    graph.add_edge("EXTRACT_DOCUMENT", "LLM_FIELD_EXTRACTION")
    graph.add_edge("LLM_FIELD_EXTRACTION", "VALIDATE_FIELDS")
    graph.add_conditional_edges("VALIDATE_FIELDS", _validation_router)

    # Draft generation flow
    graph.add_edge("DRAFT_GENERATION", "ASSEMBLE_RESPONSE")
    graph.add_edge("ASSEMBLE_RESPONSE", END)

    return graph.compile()


# ============================================================
# PUBLIC API
# ============================================================

async def run_contract_draft_graph(input_data: dict) -> dict:
    """Step 1: Extract document, extract fields via LLM, validate.
    Returns missing fields if validation fails, or the generated draft if all fields are present."""
    graph = build_contract_draft_graph()

    initial_state = ContractDraftState(
        contract_type=input_data.get("contract_type", {}),
        document_upload=input_data.get("document_upload", {}),
        supporting_document=input_data.get("supporting_document", {}),
        prid=input_data.get("prid", ""),
        flex_id=input_data.get("flex_id", ""),
        template=input_data.get("template", {}),
        lookup_in_icertis=input_data.get("lookup_in_icertis", False),
    )

    result = await graph.ainvoke(initial_state)

    if not result.get("validation_passed", False):
        return {
            "status": "validation_requirement_to_fulfill",
            "message": "Required fields are missing. Please provide the following fields.",
            "missing_fields": result.get("missing_fields", []),
            "extracted_fields": result.get("extracted_fields", {}),
        }

    return result.get("final_response", {})


async def resume_contract_draft_graph(input_data: dict) -> dict:
    """Step 2: User provides the missing fields. Merge into extracted_fields,
    re-validate, and proceed to draft generation using the same graph."""

    extracted_fields = input_data.get("extracted_fields", {})
    user_filled_fields = input_data.get("user_filled_fields", {})

    # Merge user-provided values into extracted fields
    extracted_fields.update(user_filled_fields)

    # Re-validate before invoking graph
    mapping = load_field_mapping()
    field_definitions = mapping.get("field_definitions", [])
    validation = validate_extracted_fields(extracted_fields, field_definitions)

    if not validation["valid"]:
        return {
            "status": "validation_requirement_to_fulfill",
            "message": "Required fields are still missing. Please provide the following fields.",
            "missing_fields": validation["missing_fields"],
            "extracted_fields": extracted_fields,
        }

    # Validation passed — same graph, but entry router skips to DRAFT_GENERATION
    graph = build_contract_draft_graph()

    initial_state = ContractDraftState(
        contract_type=input_data.get("contract_type", {}),
        prid=input_data.get("prid", ""),
        flex_id=input_data.get("flex_id", ""),
        extracted_fields=extracted_fields,
        validation_passed=True,
    )

    result = await graph.ainvoke(initial_state)
    return result.get("final_response", {})


# ============================================================
# CLI ENTRY POINT
# ============================================================

if __name__ == "__main__":
    import asyncio
    import os

    demo_path = os.path.join(os.path.dirname(__file__), "Draft.json")
    with open(demo_path, "r") as f:
        input_data = json.load(f)

    print("Running contract draft graph...\n")
    response = asyncio.run(run_contract_draft_graph(input_data))

    while response.get("status") == "validation_requirement_to_fulfill":
        missing = response.get("missing_fields", [])
        extracted = response.get("extracted_fields", {})

        print(f"\nMISSING REQUIRED FIELDS ({len(missing)}):")
        user_filled = {}
        for field in missing:
            label = field.get("label", field["field_key"])
            opts = field.get("options")
            prompt = f"  {label}"
            if opts:
                prompt += f" [{', '.join(opts)}]"
            value = input(f"{prompt}: ").strip()

            ftype = field.get("type", "text")
            if ftype == "number":
                try:
                    value = float(value) if "." in value else int(value)
                except ValueError:
                    pass
            elif ftype == "boolean":
                value = value.lower() in ("true", "yes", "1", "y")

            user_filled[field["field_key"]] = value

        extracted.update(user_filled)
        print("\nGenerating SOW draft...")

        response = asyncio.run(resume_contract_draft_graph({
            "contract_type": input_data.get("contract_type", {}),
            "prid": input_data.get("prid", ""),
            "flex_id": input_data.get("flex_id", ""),
            "extracted_fields": extracted,
            "user_filled_fields": user_filled,
        }))

    if response.get("status") == "draft_generated":
        print(f"\nContract: {response.get('contract_type')} | "
              f"PRID: {response.get('prid')} | Flex: {response.get('flex_id')}")
        print(response.get("draft_content", ""))
    else:
        print(json.dumps(response, indent=2))
